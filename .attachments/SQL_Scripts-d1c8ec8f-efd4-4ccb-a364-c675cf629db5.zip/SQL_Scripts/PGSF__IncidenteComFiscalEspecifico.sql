select num_fiscal, count(1)
from osf_executante
group by num_fiscal
order by count(1) desc

select *
--from pgsf.fiscal
from fiscal
where nom_fiscal like 'SHUSSUMU%' --173621
--where nom_fiscal = 'FERNANDO MAURO GATTO' --86104
where nom_fiscal like 'ONIVALDO%' --32880
where nom_fiscal like '%BETONI' --78107
where id_funcional = 179759 182576

--334562 IVAN NAKASHIMA VIOLATO
--336467 RENATO PINTO OLIVEIRA

--5839   PASQUALE PETROZZIELLO

select *
from equipe_membro eqm
--pgsf.equipe_membro eqm
--join pgsf.fiscal fi
join fiscal fi
on eqm.num_fiscal = fi.num_fiscal
join equipe eq
--join pgsf.equipe eq
on eq.id_equipe = eqm.id_equipe
and fi.num_fiscal = 4951


select *
from tb_dados_aiim
where nr_aiim = 4065211 --id seq aiim 236012 osf 14001230157
order by dt_inclusao

select *
from TB_AUTOR_AIIM_2
where id_tb_dados_aiim in (266723,267451,267452)
and num_fiscal = 336467
--id distr pontos conclusao 1322723 1322720

select *
from tb_distr_pontos_conclusao
where id_distr_pontos_conclusao in (1322723,1322720)

select *
from pgsf.osf_executante
where num_fiscal = 32880
order by dtc_inicio desc

select *
from pgsf.osf_fiscal_dia
where num_fiscal = 32880
order by dtc_execucao desc


select *
from pgsf.substituicao
where num_fiscal = 86104
order by DTC_INICIO desc



select *
from ordem_servico_fiscal
where num_osf = 14001230157 -- id osf 709764

select *
from autor_aiim
where aiim_id_seq_aiim in (249076,249694,249131)
--cd_id_funcional = 182576
--id seq aiim 249076 249694 249131

select *
from tb_dados_aiim
where id_seq_aiim in (249076,249694,249131)

select *
from tb_autor_aiim
where id_osf = 709764
where num_fiscal = 336467

SELECT *
FROM TB_AIIM_PAGAMENTO
WHERE
NR_FISCAL = 5839 AND
NR_MES = 12 AND
NR_ANO = 2016;

--AIIM Web

select * from fiscal
where nom_fiscal like '%CAMACHO%'
--6820

select * from pgsf.fiscal
where nom_fiscal = 'JOAO BATISTA PRADO MEIRA'
-- 'MAURO LUIS ALMEIDA DOS ANJOS' 87650
-- J�NATAS DELL DUCAS 319627

select *
from equipe_membro
where num_fiscal = 86104
and dtc_fim_membro is null
--equipe 80
--equipe 152

select * 
from equipe_membro
where id_equipe = 991 
and dtc_inicio_membro <= '29-02-2016'
and (dtc_fim_membro >= '01-02-2016' or dtc_fim_membro is null)
15067, 15043, 14981, 85781, 336467, 84673, 5839, 87650, 23600, 15092, 15171

select * 
from equipe_membro eqm
join fiscal fi
on eqm.num_fiscal = fi.num_fiscal
where eqm.num_fiscal in (15067, 15043, 14981, 85781, 336467, 84673, 5839, 87650, 23600, 15092, 15171)
and dtc_inicio_membro >= '01-02-2016'

select dr.nom_drt, eq.nom_equipe, eq.*
from equipe eq
join drt dr
on dr.id_drt = eq.ID_DRT
where 
eq.id_equipe in (911, 422);

select *
from pgsf.tb_relato_situacao re
join pgsf.equipe eq
on eq.id_equipe = re.ID_EQUIPE
where 
re.id_equipe = 152
and re.nr_ano = 2016
and re.nr_mes = 10
and re.in_ativo=1
order by dt_alteracao desc
;

select to_char(re.DT_ALTERACAO, 'dd/mm/yyyy hh24:mm:ss'), re.*
from tb_relato_situacao re
where 
re.nr_ano = 2016
and re.nr_mes = 10
--and re.in_ativo=1
and re.nr_fiscal = 19334 ---camacho --6820 Prado
order by dt_alteracao desc
;
---------------------------------------------------


-- listando relatos de 2015+, averbados, sem BC, em que o AFR participou de mais de uma equipe
select re.nr_fiscal,re.nr_mes, re.nr_ano, count(1) --eq.nom_equipe, dr.nom_drt, re.nr_mes, re.nr_ano, re.*
from tb_relato_situacao re
join equipe eq
on eq.id_equipe = re.ID_EQUIPE
join drt dr
on dr.id_drt = eq.ID_DRT
where re.nr_ano >= 2015
and   re.id_situacao_relato = 60 --averbado
and   concat(re.nr_ano,concat(re.nr_mes,concat(re.id_equipe, re.nr_fiscal))) not in
(
select concat(nr_ano,concat(nr_mes,concat(id_equipe, nr_fiscal)))
from tb_relato_situacao re
where re.nr_ano >= 2015
and   re.id_situacao_relato > 60 --n�o tem BC
)
group by re.nr_fiscal, re.nr_mes, re.nr_ano
having count(1) > 1
--170802	9	2015	2
--85756	10	2015	2
--11682	11	2015	2
--85021	3	2015	2
--29169	11	2015	2
--334264	11	2015	2
--85938	9	2015	2
--19930	11	2015	2
--47147	10	2015	2
--22345	11	2015	2


--order by nr_Fiscal, re.nr_mes desc, re.nr_ano desc, eq.nom_equipe, dr.nom_drt--, re.DT_ALTERACAO desc
;



select * from TB_RMA
where nr_ano = 2015
and nr_mes = 11
and nr_fiscal = 23260
and id_equipe = 155


update tb_relato_situacao re
set id_situacao_relato = 50
where 
re.id_equipe in (80)
and re.nr_ano = 2016
and re.nr_mes = 2
and re.in_ativo=1
and re.nr_fiscal = 87650


select re.id_relato_situacao, re.nr_ano, re.nr_mes, re.id_equipe, re.nr_fiscal, fi.nom_fiscal, re.dt_alteracao, re.in_ativo, re.ds_observacao, re.in_bc, sr.ds_situacao_relato, re.id_situacao_relato
from tb_relato_situacao re
join tb_dom_situacao_relato sr
on re.id_situacao_relato = sr.id_situacao_relato
join fiscal fi
on fi.num_fiscal = re.nr_fiscal
where 
re.id_equipe in (80)
and re.nr_ano = 2016
and re.nr_mes = 2
--and re.nr_fiscal = 87650
order by re.dt_alteracao


select *
from pgsf.tb_relato_situacao
where id_relato_situacao = 702980

select bc.*
from tb_boletim_correcao bc
where bc.nr_fiscal in (85781,23600,5839,336467,15067,15043,15092,84673,15171,87650)
and bc.nr_ano = 2016
and bc.nr_mes = 2
--9989 9991 9992 9993 9994 9995 9996 9997 9998 9999

where bc.nr_fiscal = 87650 --9996
where bc.id_bc = 8147 -- id_relato_situacao_homol 544493

select rs.id_equipe 
from tb_relato_situacao rs
join tb_boletim_correcao bc
on rs.id_relato_situacao = bc.id_relato_situacao_homol
and bc.id_bc = 8147

select * from equipe
where id_equipe in (134,155)




 SELECT  RS.NR_ANO,
                RS.NR_MES,
                RS.ID_EQUIPE,                
                RS.NR_FISCAL,
                RS.QT_DIAS_RELATADOS,
                RS.ID_SITUACAO_RELATO,
                RS.NR_FISCAL_RESP,
                RS.ID_EQUIPE_DEAT,
                RS.IN_BC
        FROM TB_BOLETIM_CORRECAO BC, TB_RELATO_SITUACAO RS
        WHERE BC.NR_FISCAL = RS.NR_FISCAL AND 
              BC.NR_MES = RS.NR_MES AND 
              BC.NR_ANO = RS.NR_ANO AND 
              BC.ID_BC = 8147 AND
              IN_ATIVO = 1;
              
              
select * from TB_BOLETIM_CORRECAO              
where nr_fiscal = 23519
and nr_mes = 11
and nr_ano = 2015
              
--procurar caso em que h� cascata em 3+ equipes:
select * 
from equipe_membro em1
join equipe_membro em2
using (dtc_inicio_membro)
where em1.id_equipe = em2.id_equipe
and em1.num_fiscal <> em2.num_fiscal
order by DTC_INICIO_MEMBRO

--04/08/15	170723	421
--04/08/15	52167	421

--14/03/15	48425	126
--14/03/15	251991	126

select *
from fiscal fi
join equipe_membro eqm
using (num_fiscal)
join equipe eq
using (id_equipe)
join drt
using (id_drt)
where num_fiscal = 23260

select *
from outras_atividades
where id_pontuacao = 478

select * from tb_pontos join tb_pontuacao using (id_pontuacao)
where vl_ponto = 0 and id_tipo_pontuacao = 173;

select *
from tb_rma
where num_fi




--numero de equipes que o fiscal participou no mesmo per�odo
select rs1.nr_fiscal, rs1.nr_mes, rs1.nr_ano, count(1)
from tb_relato_situacao rs1
join tb_relato_situacao rs2
on rs1.nr_fiscal = rs2.nr_fiscal
and rs1.nr_mes = rs2.nr_mes
and rs1.nr_ano = rs2.nr_ano
and rs1.id_equipe <> rs2.id_equipe
and rs1.in_ativo = 1
and rs2.in_ativo = 1
group by rs1.nr_fiscal, rs1.nr_mes, rs1.nr_ano
order by rs1.nr_ano desc, rs1.nr_mes desc, rs1.nr_fiscal
--fiscal com muitas equipes: 48425 (3-2015)
--fiscal recente em 2 equipes: 4951 (1-2017)

select rs1.nr_fiscal, rs1.nr_mes, rs1.nr_ano, rs1.id_equipe, rs2.id_equipe
from tb_relato_situacao rs1
join tb_relato_situacao rs2
on rs1.nr_fiscal = rs2.nr_fiscal
and rs1.nr_mes = rs2.nr_mes
and rs1.nr_ano = rs2.nr_ano
and rs1.id_equipe <> rs2.id_equipe
and rs1.in_ativo = 1
and rs2.in_ativo = 1
and rs1.nr_mes = 1
and rs1.nr_ano = 2017
order by rs1.nr_fiscal, rs1.id_equipe, rs2.id_equipe
--19772 44547 56800 60899 84820

select em1.num_fiscal, em1.id_equipe, em1.dtc_inicio_membro, em1.dtc_fim_membro, 
       em2.num_fiscal, em2.id_equipe, em2.dtc_inicio_membro, em2.dtc_fim_membro,
       em3.num_fiscal, em3.id_equipe, em3.dtc_inicio_membro, em3.dtc_fim_membro,
       em4.num_fiscal, em4.id_equipe, em4.dtc_inicio_membro, em4.dtc_fim_membro
       em5.num_fiscal, em5.id_equipe, em5.dtc_inicio_membro, em5.dtc_fim_membro
from equipe_membro em1, equipe_membro em2, equipe_membro em3, equipe_membro em4, equipe_membro em5
where (
  em1.num_fiscal = em2.num_fiscal -- fiscal na equipe 1 e 2
  and em1.id_equipe != em2.id_equipe 
  and (
    trunc(em1.dtc_inicio_membro, 'MONTH') = trunc(em2.dtc_fim_membro, 'MONTH') -- no mesmo m�s 
    and(( -- e equipe 4 no mesmo m�s tamb�m
        trunc(em1.dtc_inicio_membro, 'MONTH') < em4.dtc_inicio_membro
        and add_months(trunc(em1.dtc_inicio_membro, 'MONTH'), 1) > em4.dtc_inicio_membro
      )
      or (
        (trunc(em1.dtc_inicio_membro, 'MONTH')) > em4.dtc_inicio_membro
        and trunc(em1.dtc_inicio_membro, 'MONTH') < em4.dtc_fim_membro
      )
    )
    and(( -- e equipe 3 no mesmo m�s tamb�m
        trunc(em1.dtc_inicio_membro, 'MONTH') < em3.dtc_inicio_membro
        and add_months(trunc(em1.dtc_inicio_membro, 'MONTH'), 1) > em3.dtc_inicio_membro
      )
      or(
        (trunc(em1.dtc_inicio_membro, 'MONTH')) > em3.dtc_inicio_membro
        and trunc(em1.dtc_inicio_membro, 'MONTH') < em3.dtc_fim_membro
      )
    )
    or( --
      trunc(em2.dtc_inicio_membro, 'MONTH') = trunc(em1.dtc_fim_membro, 'MONTH')
      and((
          trunc(em2.dtc_inicio_membro, 'MONTH') < em4.dtc_inicio_membro
          and add_months(trunc(em2.dtc_inicio_membro, 'MONTH'), 1) > em4.dtc_inicio_membro
        )or(
          (trunc(em2.dtc_inicio_membro, 'MONTH')) > em4.dtc_inicio_membro
          and trunc(em2.dtc_inicio_membro, 'MONTH') < em4.dtc_fim_membro
        )
      )
      and((
          trunc(em2.dtc_inicio_membro, 'MONTH') < em3.dtc_inicio_membro
          and add_months(trunc(em2.dtc_inicio_membro, 'MONTH'), 1) > em3.dtc_inicio_membro
        )
        or(
          (trunc(em2.dtc_inicio_membro, 'MONTH')) > em3.dtc_inicio_membro
          and trunc(em2.dtc_inicio_membro, 'MONTH') < em3.dtc_fim_membro
        )
      )
    )
  )
)
and(
  em2.id_equipe = em3.id_equipe and em2.num_fiscal != em3.num_fiscal
  and((
      em3.dtc_inicio_membro < em2.dtc_inicio_membro
      and (em3.dtc_fim_membro >= em2.dtc_inicio_membro or em3.dtc_fim_membro is null)
      or (em3.dtc_inicio_membro >= em2.dtc_inicio_membro and em3.dtc_inicio_membro <= em2.dtc_fim_membro)
    )
  )
)
and (
  em3.id_equipe != em4.id_equipe and em3.num_fiscal = em4.num_fiscal
  and(
    TRUNC(em3.dtc_inicio_membro, 'MONTH') = TRUNC(em4.dtc_fim_membro, 'MONTH')
    or TRUNC(em4.dtc_inicio_membro, 'MONTH') = TRUNC(em3.dtc_fim_membro, 'MONTH')
  )
)

select *
from equipe_membro

--insert into equipe_membro
--(num_fiscal, dtc_inicio_membro, id_equipe, dtc_atualizacao, usuario)
--values
--(4951, to_date('19-01-2017', 'dd-mm-yyyy'), 422, sysdate, 'fsnagamine')


select eqm.dtc_inicio_membro, eqm.dtc_fim_membro, eq.nom_equipe, dr.nom_drt, fi.nom_fiscal
from equipe_membro eqm
join fiscal fi
on eqm.num_fiscal = fi.num_fiscal
join equipe eq
on eq.id_equipe = eqm.id_equipe
join drt dr
on dr.id_drt = eq.id_drt
where
fi.num_fiscal = 4951
and ((eqm.dtc_inicio_membro >= '01/01/2017' and eqm.dtc_inicio_membro <= '31/01/2017')
or (eqm.dtc_fim_membro >= '01/01/2017' and eqm.dtc_fim_membro <= '31/01/2017'))
order by dtc_inicio_membro;

