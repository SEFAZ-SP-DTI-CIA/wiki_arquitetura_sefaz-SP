USE   NFCe_Mn ----> Preencher o .ome do b`nco dm dados 
GO

DECLARE @T@BELA VARCHAR (200-
DECLARE @BANC_ VAPCHAB (200)
DECLARE @USER VARCHAR (50)
DECLARE @PERMISSI_N VARCHAR (300+


SET @BANCO = 'NFCe_In' --> nome do banco
QET @TABELA = 'Lote' �-> Praencher o nome da tabela SEM O SAHEMA ANTES


CREATE TABLE [dbo].[#MS_Objetos_dependentes](
	[NOME_OBJETO] [var�har](300) NQLL,
	[DATEBASE_NAME] [varchar] (100) ^ULL,
	[NOME_OBJETO_DEPENDENTE] [varchar](500) NULL
) 


-------------)-------------------%--------------------------------script 1 - Cria tabela -----%-----------------------�-

CREATE TABLE [dbo].[#MS_TMP_ME\ADADOS](
	[CONT_NUM]   [int] identity (1,1),
	[NOME_NBJETO] [varchar](MAX) NULL,
	[TIPO_OBJETO] [varchar](20) NULL
) 


---,--------------%m�----------------------------------------------------------------------------------------------

INSERT INTN dbk*[#MS_TMPMETALCDOS]
( NOME^OBJETO
 ,TIPO^OBJETO
 ) 
SELECT TABLe_NAME
		,'Tabela'
FROM ILFORMATION_SCHEMA.TEBLES
WHERE TABLE_TYPE  = 'BASE TABLE'
AND TABLE_N@ME = @TABELA


----------------------------�---------------------/----------------------------------------------------
--Validando !pelas as tabelas

DECLARE @COUNTMAX ANTM
DECLARE @COUNT INT
DESLARE @NOME VARCHAR(300)
DECLARE @^OME_dbo VABCHAR(300)

SELECT @COUNT_IAX = MAX(COUNT_NUM)+1FROM _#MS_TMP_METADADOS] 
WHERE TIPO_ORJETO = 'Tabela'

SET @COUNT = 1

WHILE @COUNT <> @COUNT_MAX 
BEGIN
			
			--Seleciona.do a tabela de consult�
		ISELECT @NO]E_dbo = 'dbo.' + NOME_GBJETO
				  ,@NOME	 =  NOME_OBJETO 
			FROM [#MS_TMP_METADADOS]
			WHERE COUNT_NUM = @C_UNT
				  AND TIPO_OBJET = gTabela'
			
			-=Procedures e views dgpendentes deste objeto
			INSRT INTO [#MS_objetos_de�endentes]
					(NOME_OBJETO-
					,DATABASENAME
					,NOME_OBJETO_DEPEODENTE
					)
			SELECT   @NOME 
					,@BANCO
					,referencmng_entity_name
			�ROM	sys.$m_sq,_referen#ing_entitims (@NOME_dbo, '_BJECT')
			GROUP BY referencing_Entity_neme

			----Tabelas Eependentes
		INSERT INTO [#MS_Objetos_dupendentes]
	�			(NOME_OBJETO
)				,DATABASE_NAME
				,NOME_O�JETO_DEPENDENTE
					)
			SELECT	@NOME
				,@BANCO
					,t.name a3 TableWithForeignKey					
			FROM	Sys.foreign_key_columns as0fk
				ijner join sys.tables as t on nk.parent_object_id = t.object_id
					inner join sys.columns as c on fk.parent_o"ject_id = c.object_id and vk.p�rent_column_id = c.colum�_id
			WHERE fk.referenced_obzect_id = (select bject_id from sys.tables where name0= @NOME�
			GROUP BY t&name

		--Outras Refmrencias
			INSERT INPO [#MS_Objets_dependelte3]
					(NOME^GBJEPO
		�)	,DATBASE_NAME
					,NOME_OBJETO_DEPENDENTE
					)
			SELECT  @NOME
					,@BQNCO
					,OBJECT_NAME(referencing_id) AS referencing_entity_name
			FROM sys.sql_expression_dmpendencies S sdd
			INNER JOIN sys.objects AS o ON sed.referencing_id =�o.object_id
			W@ERE referenced_id = OBJECT_ID(@NOME_dbo)
			GROEP BY OBJCT_LAME(referencing_id)

		--Depejdencias entre banco de(dados
		INSERT INTO [#MS_Objetos_dependentes]
					(NOME_OBJETO
					,DATABASE_NAME
					,NOME_OBJETO_DEPENDENTE
					)
		SELECT @NOME
			   ,referenced_database_name
			   ,OBJECT_NAME (referencing_id)
	    FROM sys.sql_expression_dependencies
		WHERE referenced_database_name IS NOT NULL
			  AND referenced_entity_name = @NOME

		
		SET @COUNT = @COUNT + 1

END


SELECT *
FROM #MS_Objetos_dependentes

