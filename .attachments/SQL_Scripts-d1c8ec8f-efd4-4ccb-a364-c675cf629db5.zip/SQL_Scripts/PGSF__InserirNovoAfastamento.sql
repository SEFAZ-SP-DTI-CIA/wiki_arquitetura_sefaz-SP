-- Incidentes Relacionados a essa ocorr�ncia (lista n�o exaustiva):
-- INC000001804628

select * 
from fiscal 
where 
nom_fiscal like '%FOSSARI' --50869
--nom_fiscal = 'GILBERTO NEVES PIMENTA' --95841
--where nom_fiscal like '%CAVAZZA%' --248293
--where nom_fiscal = 'FERNANDO MAURO GATTO' --86104
--where nom_fiscal like 'ONIVALDO%' --32880
--where nom_fiscal like '%BETONI' --78107
--nom_fiscal like '%BEVEVINO%' --44092
--nom_fiscal like '%DEL NERO%' --170498

select max(id_pontuacao) from pgsf.tb_pontuacao --613
select max(id_pontuacao) from tb_pontuacao --613

select *
from TB_DOM_PONTUACAO_AFASTAMENTO
where id_pontuacao = 615
--where id_pontuacao = 614
or id_pontuacao = 436

--max id_pontos = 412
--SELECT to_char(DT_INICIO_VIGENCIA,'DD/MM/YYYY HH24:MI:SS')
SELECT id_pontuacao_grupo --max(id_pontuacao) --614
FROM TB_PONTUACAO
where id_pontuacao = 615
--where id_pontuacao = 614
--or id_pontuacao = 436
--order by id_pontuacao
;
select *--max(id_pontos) --413
from tb_pontos
where id_pontuacao = 615
--where id_pontuacao = 614
--or id_pontuacao = 436

SELECT *
FROM OUTRAS_ATIVIDADES
WHERE ID_PONTUACAO = 614
and num_fiscal = 44092

delete OUTRAS_ATIVIDADES
WHERE ID_PONTUACAO = 614
and num_fiscal = 86104
and num_fiscal = 44092

select *
from tb_dom_tipo_pontuacao
where id_tipo_pontuacao = 173

SELECT *
FROM OUTRAS_ATIVIDADES
where id_pontuacao=614
and num_fiscal=95841

delete OUTRAS_ATIVIDADES
where id_pontuacao=614
and num_fiscal=95841

SELECT tp.DS_PONTUACAO, oa.*
FROM pgsf.OUTRAS_ATIVIDADES oa
JOIN pgsf.TB_PONTUACAO tp
ON oa.ID_PONTUACAO = tp.ID_PONTUACAO
--WHERE DS_PONTUACAO like '%F�RIAS%'
WHERE NUM_FISCAL = 86888
--AND oa.ID_PONTUACAO = 436 --f�rias
--AND oa.ID_PONTUACAO = 428 --lic.premio
AND DTC_EXECUCAO >= to_date('01/12/2016', 'dd/mm/yyyy')
AND DTC_EXECUCAO <= to_date('31/12/2016', 'dd/mm/yyyy');




ALTER TRIGGER TR_PONTUACAO_BI DISABLE;
INSERT INTO TB_PONTUACAO (ID_PONTUACAO, ID_TIPO_CALCULO, ID_TIPO_PONTUACAO, CD_PONTUACAO, DS_PONTUACAO, IN_NECESSITA_AUTORIZACAO, IN_DIVISIVEL, IN_FORA_HORARIO_EXPEDIENTE, IN_DIA_NAO_UTIL, IN_DIA_UTIL, IN_SOBREPOR_GRUPO, IN_EXECUCAO, IN_COORDENADOR, DT_INICIO_VIGENCIA, DT_FIM_VIGENCIA, ID_USUARIO_ALTERACAO, DT_ALTERACAO, DS_PONTUACAO_SUMARIO)
VALUES ('614', '1', '173', 'SP - s/ pont', 'Revezamento Natal e Ano Novo', '0', '0', '0', '1', '1', '0', '1', '0', TO_DATE('19/12/2016', 'DD/MM/YYYY'), TO_DATE('30/12/2016 23:59:59', 'DD/MM/YYYY HH24:MI:SS'), 'fsnagamine', SYSDATE, 'Revezamento Natal e Ano Novo');
ALTER TRIGGER TR_PONTUACAO_BI ENABLE;

INSERT INTO TB_DOM_PONTUACAO_AFASTAMENTO (ID_PONTUACAO, COD_FREQ, TIPO_FREQ)
VALUES ('614', '211', 'NORMAL');

ALTER TRIGGER TR_PONTOS_BI DISABLE;
INSERT INTO TB_PONTOS (ID_PONTOS, ID_PONTUACAO, VL_PONTO, DT_INICIO_VIGENCIA, DT_FIM_VIGENCIA, ID_USUARIO_ALTERACAO, DT_ALTERACAO)
VALUES ('413','614', '0',  TO_DATE('19/12/2016', 'DD/MM/YYYY'), TO_DATE('30/12/2016 23:59:59', 'DD/MM/YYYY HH24:MI:SS'), 'fsnagamine', SYSDATE);
ALTER TRIGGER TR_PONTOS_BI ENABLE;

update TB_PONTOS
set DT_INICIO_VIGENCIA = TO_DATE('19/12/2016', 'DD/MM/YYYY'), DT_FIM_VIGENCIA = TO_DATE('31/12/2016', 'DD/MM/YYYY')
where id_pontuacao = 614;
update TB_PONTUACAO
set DT_INICIO_VIGENCIA = TO_DATE('19/12/2016', 'DD/MM/YYYY'), DT_FIM_VIGENCIA = TO_DATE('31/12/2016', 'DD/MM/YYYY')
where id_pontuacao = 614;

update TB_PONTOS
set DT_INICIO_VIGENCIA = TO_DATE('31/12/9999', 'DD/MM/YYYY'), DT_FIM_VIGENCIA = TO_DATE('31/12/9999', 'DD/MM/YYYY')
where id_pontuacao = 614;
update TB_PONTUACAO
set DT_INICIO_VIGENCIA = TO_DATE('31/12/9999', 'DD/MM/YYYY'), DT_FIM_VIGENCIA = TO_DATE('31/12/9999', 'DD/MM/YYYY')
where id_pontuacao = 614;

--------------------------------------------------------------------------------
ALTER TRIGGER TR_PONTUACAO_BI DISABLE;
INSERT INTO TB_PONTUACAO (ID_PONTUACAO, ID_TIPO_CALCULO, ID_TIPO_PONTUACAO, CD_PONTUACAO, DS_PONTUACAO, IN_NECESSITA_AUTORIZACAO, IN_DIVISIVEL, IN_FORA_HORARIO_EXPEDIENTE, IN_DIA_NAO_UTIL, IN_DIA_UTIL, IN_SOBREPOR_GRUPO, IN_EXECUCAO, IN_COORDENADOR, DT_INICIO_VIGENCIA, DT_FIM_VIGENCIA, ID_USUARIO_ALTERACAO, DT_ALTERACAO, DS_PONTUACAO_SUMARIO)
VALUES ('615', '1', '10', '1.9', 'Pontua��o de teste', '1', '0', '1', '1', '1', '0', '1', '0', TO_DATE('01/12/2016', 'DD/MM/YYYY'), TO_DATE('30/12/2016 23:59:59', 'DD/MM/YYYY HH24:MI:SS'), 'fsnagamine', SYSDATE, 'Pontua��o Teste');
ALTER TRIGGER TR_PONTUACAO_BI ENABLE;

ALTER TRIGGER TR_PONTOS_BI DISABLE;
INSERT INTO TB_PONTOS (ID_PONTOS, ID_PONTUACAO, VL_PONTO, DT_INICIO_VIGENCIA, DT_FIM_VIGENCIA, ID_USUARIO_ALTERACAO, DT_ALTERACAO)
VALUES ('415','615', '135',  TO_DATE('01/12/2016', 'DD/MM/YYYY'), TO_DATE('30/12/2016 23:59:59', 'DD/MM/YYYY HH24:MI:SS'), 'fsnagamine', SYSDATE);
ALTER TRIGGER TR_PONTOS_BI ENABLE;

insert into tb_pontuacao_tipo_osf (id_pontuacao_tipo_osf, id_tipo_osf, id_pontuacao, dt_inicio_vigencia, dt_fim_vigencia, id_usuario_alteracao, dt_alteracao)
values ('63', '8', '615' ,TO_DATE('01/12/2016', 'DD/MM/YYYY'), TO_DATE('30/12/2016', 'DD/MM/YYYY'), 'fsnagamine', sysdate)

insert into tb_pontuacao_relacionamento (id_pontuacao, id_relacionamento)
values (615, 1)


update TB_PONTUACAO
set DT_FIM_VIGENCIA = TO_DATE('31/12/2016', 'DD/MM/YYYY')
--set DT_FIM_VIGENCIA = TO_DATE('31/01/2017', 'DD/MM/YYYY')
where id_pontuacao = 615;
update TB_PONTOS
set DT_FIM_VIGENCIA = TO_DATE('31/12/2016', 'DD/MM/YYYY')
--set DT_FIM_VIGENCIA = TO_DATE('31/01/2017', 'DD/MM/YYYY')
where id_pontuacao = 615;
update tb_pontuacao_tipo_osf
set DT_FIM_VIGENCIA = TO_DATE('31/12/2016', 'DD/MM/YYYY')
--set dt_fim_vigencia = TO_DATE('31/01/2017', 'DD/MM/YYYY')
--set id_tipo_osf = 5
where id_pontuacao = 615;


select *
from tb_dom_tipo_pontuacao

select * --max = 62
from tb_pontuacao_tipo_osf
where id_pontuacao = 36

select *
from tb_dom_tipo_osf

select *
from tb_pontuacao_relacionamento
where id_pontuacao = 36

select column_name
from all_tab_cols
where table_name = 'TB_PONTUACAO'