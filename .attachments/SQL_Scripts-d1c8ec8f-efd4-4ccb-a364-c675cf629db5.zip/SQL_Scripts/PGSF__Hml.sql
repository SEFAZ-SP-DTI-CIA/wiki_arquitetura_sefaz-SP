select *
from tb_relato_situacao
join tb_dom_situacao_relato
using(id_situacao_relato)
where id_situacao_relato = 40
order by dt_alteracao desc

select "ID_SITUACAO_RELATO", "ID_RELATO_SITUACAO", "NR_ANO", "NR_MES", "ID_EQUIPE", "NR_FISCAL", "QT_DIAS_RELATADOS", TO_CHAR(DT_ALTERACAO,'DD/MM/YYYY HH24:MI:SS'), "ID_USUARIO", "NR_FISCAL_RESP", "IN_ATIVO", "ID_EQUIPE_DEAT", "DS_OBSERVACAO", "IN_BC", "IN_HOMOLOG_RMA", "DS_SITUACAO_RELATO" 
from tb_relato_situacao
join tb_dom_situacao_relato
using(id_situacao_relato)
where nr_ano = 2018
and nr_mes = 1
and id_equipe = 871
and in_ativo = 1
order by dt_alteracao desc
40	516956	2018	1	871	60589	10	25/10/2019 15:34:18	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516955	2018	1	871	45291	21	25/10/2019 15:34:17	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516954	2018	1	871	322262	20	25/10/2019 15:34:17	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516952	2018	1	871	43750	9	25/10/2019 15:34:16	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516953	2018	1	871	44493	21	25/10/2019 15:34:16	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516950	2018	1	871	43520	10	25/10/2019 15:34:15	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516951	2018	1	871	81088	21	25/10/2019 15:34:15	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH
40	516949	2018	1	871	44432	21	25/10/2019 15:34:14	fsnagamine	319561	1			0	1	Pronto para ser enviado ao RH



select *
from tb_relato_situacao
join tb_dom_situacao_relato
using(id_situacao_relato)
where nr_ano = 2015
and nr_mes = 3
and id_equipe = 357
order by dt_alteracao desc

select *
from fiscal 
join equipe_membro
using(num_fiscal)
where id_equipe = 368
and dtc_fim_membro is null

select *
from fiscal 
join equipe_membro
using(num_fiscal)
where nom_fiscal like 'ATALIBA%'75581 --'ALICE MITICO%'75933

select * from tb_rma
where nr_ano = 2015
and nr_mes = 3
and nr_fiscal = 75581--75933--95191
89243	95191	2015	6	0	3756	479717	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81148	75933	2015	3	0	3505	431654	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor --ALICE MITICO TAMIYA

select * from tb_rma
where nr_ano = 2015
and nr_mes = 3
and id_equipe = 357
--368 2015-03
81148	75933	2015	3	0	3505	431654	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81149	24070	2015	3	0	1350	431655	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81150	85744	2015	3	0	3382	431656	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81151	84260	2015	3	1350	1753	431657	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81152	94927	2015	3	1170	2953	431658	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81153	75659	2015	3	0	1045	431659	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81154	95142	2015	3	1710	2599	431660	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81155	87224	2015	3	450	1779	431661	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81156	247793	2015	3	0	1515	431662	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81157	336674	2015	3	0	2533	431663	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81158	335578	2015	3	0	3365	431664	368	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
--357 2015-03
81199	75969	2015	3	1440	945	431718	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81200	334550	2015	3	0	4572	431719	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81201	71939	2015	3	0	3438	431720	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81202	95191	2015	3	0	4919	431721	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81203	88113	2015	3	0	0	431722	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81204	85896	2015	3	0	3561	431723	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81205	336078	2015	3	0	4724	431724	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81206	336492	2015	3	1080	1170	431725	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81207	87637	2015	3	0	3298	431726	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81208	75726	2015	3	0	3249	431727	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor
81198	75581	2015	3	540	2534	431717	357	DELEGACIA REGIONAL TRIBUT�RIA DE ARA�ATUBA-DRT-9	Inspetor

select *
from tb_dom_situacao_relato

select *
from equipe
where id_equipe = 368

select *
from drt
where id_drt = 8




-------------------------------------------

select * from TB_RELATO_SITUACAO order by DT_ALTERACAO desc

select *
from equipe_membro
where num_fiscal = 71599
order by dtc_inicio_membro


update equipe_membro
set dtc_fim_membro = TO_DATE('08/08/2019','DD/MM/YYYY'),dtc_atualizacao = SYSDATE, usuario = 'dlchen'
where num_fiscal = 71599 and dtc_inicio_membro = TO_DATE('06/08/2019','DD/MM/YYYY')

insert into equipe_membro(num_fiscal, id_equipe, dtc_inicio_membro, dtc_atualizacao, usuario)
values(71599, 1, TO_DATE('12/08/2019','DD/MM/YYYY'), SYSDATE, 'dlchen')