select * from tb_dados_aiim where DT_IDENT_HIP_NAO_LAVRATURA is not null and to_date(DT_PRIM_NOTIF_ENV_DEC) = last_day(DT_PRIM_NOTIF_ENV_DEC)
order by DT_PRIM_NOTIF_ENV_DEC desc;

update tb_dados_aiim  
set dt_prim_notif_env_dec = to_date('29/02/2016 00:00:00','dd/mm/yyyy hh24:mi:ss')
where nr_aiim = 4072610
;
update tb_dados_aiim  
set DT_IDENT_HIP_NAO_LAVRATURA = to_date('29/02/2016 00:00:00','dd/mm/yyyy hh24:mi:ss')
where nr_aiim = 4072610
;

select nr_aiim, to_char(dt_prim_notif_env_dec, 'dd/mm/yyyy hh24:mi:ss'), to_char(dt_ident_hip_nao_lavratura, 'dd/mm/yyyy hh24:mi:ss')  from tb_dados_aiim 
where nr_aiim = 4073769

select nr_aiim, to_char(dt_prim_notif_env_dec, 'dd/mm/yyyy hh24:mi:ss'), to_char(dt_ident_hip_nao_lavratura, 'dd/mm/yyyy hh24:mi:ss')  from tb_dados_aiim where nr_aiim in
---------------------------------------------------Consulta   - Homolog    - RA        - Aprovacao
(4073769, --(s� aparece quando recalcula)          2.891      - 2.702      - 2891,0000 - 2.891
4072610,  --(aparece sempre, data de meia noite) : 3.296      - 3.377	     - 3296,0000 - 3.296
-- ap�s modificar data para depois das 00:00       3.296      - 3.107      - 3107,0000 - 3.107
4072593,  --(data de meia noite)                   7.155,1636 - 2.861	     - 7155,1636 - 7.155,1636
--                                                              7.155,1636	
4068567,  --(data de meia noite)                   7.523,9367 - 7.331,7311 - 
4067613,  --(data de meia noite)
4068735,  --(data de meia noite)
4064932,  --(data de meia noite)
4064248,  --(data de meia noite)
4064195,  --(data de meia noite)
4063806)  --(data de meia noite)
;

select * from tb_dados_aiim where nr_aiim = 
4073769
--4072610
--4072593
--4068567
order by dt_inclusao

--select * from tb_deducao_aiim
--where nr_aiim = 
--4073769

select * from AUTOR_AIIM
where aiim_id_seq_aiim = 
--247835
--247857
--247748
241643

select * 
from equipe e
join equipe_membro em
using (id_equipe)
join fiscal f
on f.num_fiscal = em.num_fiscal
where f.id_funcional = 
165700 -- num 171820
--155123 --num 51254
--159074
--164719
order by em.dtc_fim_membro
