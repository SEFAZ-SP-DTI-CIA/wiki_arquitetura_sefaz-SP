USE CTe_Out
GO

SELECT c.*, cm.*, cc.*
  FROM       [CTe_Out].[CTeAdmin].[Contribuinte]      c  (NOLOCK)
  
  INNER JOIN [CTe_Out].[CTeAdmin].[ContribuinteModal] cm (NOLOCK)
    ON c.pKey = cm.pKeyContribuinte
  
  INNER JOIN [CCC].[ccc].[Contribuinte] cc
    ON FORMAT(cc.InscMF, 'd14') = c.CNPJ
   AND ISNUMERIC(c.IE) = 1
   AND cc.IE = CONVERT(BIGINT, c.IE)

  WHERE c.CNPJ = '22255331000105'
  --WHERE (c.ativo = 0 or cm.ativa = 0)
  --  and cm.modelo = 57
  --  and c.UF = 35
  --  and (cm.pKeyModal = 3 and cc.ind5703 = 1)