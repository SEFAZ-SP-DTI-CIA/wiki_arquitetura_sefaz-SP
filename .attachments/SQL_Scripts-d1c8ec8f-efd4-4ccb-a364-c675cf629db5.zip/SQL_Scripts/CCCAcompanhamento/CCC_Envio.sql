USE CCC
GO

DECLARE @CNPJ    BIGINT = 29368951000108                                                    

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[Contribuinte] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[ContribuinteHistorico] ch (nolock)
WHERE InscMF = @CNPJ
ORDER BY ch.datu DESC

SELECT *
  FROM      CCC.Contribuinte          c  (nolock)
INNER JOIN CCC.ContribuinteHistorico ch (nolock)
    ON c.NSUCCC = ch.NSUCCC
WHERE  c.cUF = 35
   AND  c.datu > '2019-9-17 14:00'
   AND ch.datu > '2019-9-17 14:00'
   AND ch.cSitCNPJ = 3
   AND c.cSitCNPJ = 1


SELECT *
  FROM CCC.Contribuinte ch (nolock)
    WHERE  ch.InscMF = 29368951000108
	order by dAtu

SELECT *
  FROM CCC.ContribuinteHistorico ch (nolock)
    WHERE  ch.InscMF = 29368951000108
	order by dAtu

--=============================================================================================
--Acompanhamento gen�rico
--=============================================================================================
USE CCC
GO

SELECT '' AS ContribuinteAtualizacoesQueue, Count(1) AS ContribuinteAtualizacoesQueue FROM cccEnvio.ContribuinteAtualizacoesQueue (NOLOCK)
SELECT TOP 30 '' AS ContribuinteAtualizacoesQueue, flagRead, dataModificacao, *
  FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
 ORDER BY pkey ASC

SELECT TOP 10 '' AS LogXML, timestampReg, *
  FROM [cccEnvio].[LogXML] (NOLOCK)
-- WHERE erro like '%9322%'
 ORDER BY 3 DESC

SELECT TOP 100 '' AS 'LogXML exceto erro 9320', timestampReg, *
 FROM [cccEnvio].[LogXML] (NOLOCK)
WHERE erro <> 
'Erro de validacao do tipo J: Mensagem no Web Service
cStat:9320
Rejeicao: Registro no CCC ja cadastrado pela UF e dados nao foram alterados'
  AND erro <>
'Erro de validacao do tipo J: Mensagem no Web Service
cStat:9322
Rejeicao: Registro no CCC ja excluido pela UF'
ORDER BY 3 DESC

SELECT TOP 20 '' AS ContribuinteRejeitado, *
  FROM [cccEnvio].[ContribuinteRejeitado] (NOLOCK)
 ORDER BY 2 DESC

SELECT TOP 20 '' AS ContribuinteDeSP_orderByDatu, c.datu, *
  FROM [ccc].[Contribuinte] c (NOLOCK)
 WHERE cUF = 35 
 ORDER BY c.dAtu DESC

SELECT TOP 10 '' AS ContribuinteDeSP_orderByPkey, c.datu, *
  FROM [ccc].[Contribuinte] c (NOLOCK)
 WHERE cUF = 35
 ORDER BY c.pkey DESC

SELECT TOP 20 '' AS ContribuinteHistoricoDeSP_orderByPkey, c.datu, *
  FROM [ccc].[ContribuinteHistorico] c (NOLOCK)
 WHERE cUF = 35
 ORDER BY c.pkey DESC

SELECT TOP 20 '' AS ContribuinteHistoricoDeSP_orderByDatu, c.datu, *
  FROM [ccc].[ContribuinteHistorico] c (NOLOCK)
 WHERE cUF = 35
 ORDER BY c.datu DESC

SELECT '' AS '[DW].[Queue]', COUNT(1) FROM [DW].[Queue] (NOLOCK)
SELECT TOP 5 '' AS '[DW].[Queue]', * 
FROM [DW].[Queue] (NOLOCK)
ORDER BY timestampReg DESC
SELECT TOP 5 '' AS '[DW].[Queue]', * 
FROM [DW].[Queue] (NOLOCK)
ORDER BY timestampReg ASC

SELECT '' AS '[CCC].[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccEnvio' OR servico = 'cccGeraFila' or servico IS NULL

GO
RETURN

--=============================================================================================
--Acompanhamento de envio de um CNPJ
--=============================================================================================

DECLARE @CNPJ    BIGINT = 62623418000102                                                    
DECLARE @NR_CNPJ VARCHAR(14) = (SELECT FORMAT(@CNPJ, 'd14'))

--SELECT ID_SITUACAO_ESTABELECIMENTO, ID_OCORRENCIA_CADASTRAL, * 
--FROM CADESP.DBO.TB_ESTABELECIMENTO (NOLOCK)
--WHERE NR_CNPJ =  @NR_CNPJ

--SELECT DT_INICIO_TRANSACAO, ID_SITUACAO_ESTABELECIMENTO, ID_OCORRENCIA_CADASTRAL, * 
--FROM CADESP.DBO.TB_ESTABELECIMENTO_LOG L (NOLOCK)
--WHERE NR_CNPJ =  @NR_CNPJ
--ORDER BY L.DT_INICIO_TRANSACAO DESC

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[Contribuinte] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[ContribuinteHistorico] ch (nolock)
WHERE InscMF = @CNPJ
ORDER BY ch.datu DESC

SELECT '' AS cccEnvio_ContribuinteAtualizacoesQueue, dataModificacao, flagRead, datu, *
FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
WHERE COD_INSCR_MF = @CNPJ

DECLARE @RESTRICAO VARCHAR(16)  = ('%'+ CONVERT(VARCHAR,@CNPJ) +'%')

SELECT '' AS cccEnvio_ContribuinteRejeitado, *
FROM [cccEnvio].[ContribuinteRejeitado] (NOLOCK)
WHERE XML_Request LIKE @RESTRICAO
ORDER BY 2 DESC

SELECT TOP 100 '' AS LogXML, timestampReg, *
FROM [cccEnvio].[LogXML] (NOLOCK)
--WHERE erro NOT LIKE '%9320%'
WHERE TimestampReg > '2019-09-16' --DATEADD(WEEK, -1, GETDATE())
 AND XML_Request LIKE @RESTRICAO
ORDER BY 3 DESC

SELECT TOP 10 '' AS Log_FilaCredenciamentoDFe, *
  FROM [cccEnvio].[Log_FilaCredenciamentoDFe] (NOLOCK)
 WHERE RegistroCNPJ = @NR_CNPJ

SELECT TOP 10 '' AS FILA_LOG, * 
  FROM [CADESPSS].[CCC].[FILA_LOG] fl (nolock)
 INNER JOIN [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
    ON fl.ID_ESTABELECIMENTO = es.ID_ESTABELECIMENTO
 WHERE es.NR_CNPJ = @NR_CNPJ
 ORDER BY ID_FILA_LOG DESC

SELECT TOP 10 '' as FILA_FLUXO_ALTERNATIVO_LOG, * 
  FROM [CADESPSS].[CCC].[FILA_FLUXO_ALTERNATIVO_LOG] fl (nolock)
 INNER JOIN [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
    ON fl.ID_ESTABELECIMENTO = es.ID_ESTABELECIMENTO
 WHERE es.NR_CNPJ = @NR_CNPJ
 ORDER BY pkey DESC

SELECT TOP 10 '' as TB_ESTABELECIMENTO, * 
  FROM [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
 WHERE es.NR_CNPJ = @NR_CNPJ

SELECT TOP 10 '' as TB_ESTABELECIMENTO_LOG, * 
  FROM [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
 WHERE es.NR_CNPJ = @NR_CNPJ
GO
RETURN

--=============================================================================================
--Acompanhamento de envio de um NSUCCC
--=============================================================================================
DECLARE @NSUCCC BIGINT      = 17183650 --15868675 17183650	85726117
DECLARE @NSUCCCMOVTO BIGINT = 85726117 --53615899

SELECT 'CCC.Contribuinte', datu, indAtua, * FROM [CCC].[Contribuinte] (nolock)
WHERE NSUCCC      = @NSUCCC

SELECT 'CCC.ContribuinteHistorico', datu, indAtuaEndereco, * FROM [CCC].[ContribuinteHistorico] (nolock)
WHERE NSUCCC      = @NSUCCC

SELECT 'cccEnvio.ContribuinteAtualizacoesQueue', dataModificacao, flagRead, indAtuaEndereco, *
FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
WHERE NSUCCC      = @NSUCCC


--=============================================================================================
--Acompanhamento de envio de um NSU
--=============================================================================================
DECLARE @NSUCCC BIGINT      = 3923598 --15868675
DECLARE @NSUCCCMOVTO BIGINT = 53648457 --53615899

SELECT 'CCC.Contribuinte', datu, indAtua, * FROM [CCC].[Contribuinte] (nolock)
WHERE NSUCCC      = @NSUCCC
  AND NSUCCCMOVTO = @NSUCCCMOVTO 

SELECT 'CCC.ContribuinteHistorico', datu, indAtuaEndereco, * FROM [CCC].[ContribuinteHistorico] (nolock)
WHERE NSUCCC      = @NSUCCC
  AND NSUCCCMOVTO = @NSUCCCMOVTO 

SELECT 'cccEnvio.ContribuinteAtualizacoesQueue', dataModificacao, flagRead, indAtuaEndereco, *
FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
WHERE NSUCCC      = @NSUCCC
  AND NSUCCCMovto = @NSUCCCMOVTO 

--=============================================================================================
-- Verificando se todas as altera��es nos Contribuintes Habilitados pelo Sistema de Credenciamento de NF-e foram enviados pelo CCC
--=============================================================================================
DECLARE @DezMinutosAtras DATETIME = DATEADD(MINUTE, -10, GETDATE())

SELECT ch.timestampReg, cc.dAtu, ch.*, cc.* 
  FROM     [NFe_Out].[NFeOut].[ContribuintesHabilitados] ch (nolock)
 LEFT JOIN [CCC].[ccc].[Contribuinte]                    cc (nolock)
  ON FORMAT(cc.InscMF, 'd14') = ch.CNPJ
 WHERE ch.timestampReg > @DezMinutosAtras
   AND cc.cUF = 35
   AND (cc.inf55dCreden IS NOT NULL AND cc.ind55 IS NOT NULL)
 ORDER BY ch.timestampReg DESC
--=============================================================================================
--Atualiza��o de config
--=============================================================================================
/*
USE [CCC]
GO

UPDATE [CCC].[ccc].[Configuracao]
   SET valor = 'true'
 WHERE 1=1
   AND servico = 'cccGeraFila'
   AND servico = 'cccEnvio'
   AND pkeyConfiguracaoTipo = (SELECT pkey FROM [CCC].[ccc].[ConfiguracaoTipo] where nome = 'FLUXO_ALTERNATIVO_READ_FLAG')
*/

/*
USE [CCC]
GO

UPDATE [CCC].[ccc].[Configuracao]
   SET valor = 'true'
   -- SELECT * FROM [CCC].[ccc].[Configuracao]
 WHERE pkey = (SELECT c.pkey
                 FROM      [CCC].[ccc].[Configuracao]     c  (nolock)
                INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct (nolock)
                   ON c.pkeyConfiguracaoTipo = ct.pkey
                WHERE ct.nome   = 'FORCE_RESTART_FLAG'
                  AND c.servico = 'cccEnvio')

WAITFOR DELAY '00:00:10'

UPDATE [CCC].[ccc].[Configuracao]
   SET valor = '100'
   -- SELECT * FROM [CCC].[ccc].[Configuracao]
 WHERE pkey = (SELECT c.pkey
                 FROM      [CCC].[ccc].[Configuracao]     c  (nolock)
                INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct (nolock)
                   ON c.pkeyConfiguracaoTipo = ct.pkey
                WHERE ct.nome   = 'GC_THREADSLEEP_TIME'
                  AND c.servico = 'cccEnvio')
*/

