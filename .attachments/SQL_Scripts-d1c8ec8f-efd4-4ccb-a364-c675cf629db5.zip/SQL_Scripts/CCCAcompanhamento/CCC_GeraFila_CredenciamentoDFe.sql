USE CCC
GO

-- ============= FILAS
SELECT COUNT(1)
  FROM [cccEnvio].[FilaCredenciamentoDFe] (nolock) -- 580563
SELECT TOP 10 *
  FROM [cccEnvio].[FilaCredenciamentoDFe] (nolock) -- where CNPJ = '09520219000358'
 ORDER BY IdFila DESC

SELECT COUNT(1) 
  FROM [cccEnvio].[FilaFluxoAlternativoCredenciamentoDFe] (nolock)
SELECT TOP 20 '' as FilaFluxoAlternativoCredenciamentoDFe, * 
  FROM [cccEnvio].[FilaFluxoAlternativoCredenciamentoDFe] (nolock) -- WHERE CodInscrMf = 44358091000107
 ORDER BY pkey DESC

-- ============= LOGS
SELECT TOP 30 '' as Log_FilaCredenciamentoDFe, * 
  FROM [cccEnvio].[Log_FilaCredenciamentoDFe] (nolock)
--where RegistroCNPJ = '22255331000105'
 ORDER BY pKey DESC

SELECT TOP 30 '' as Log_FilaFluxoAlternativoCredenciamentoDFe, * 
  FROM [cccEnvio].[Log_FilaFluxoAlternativoCredenciamentoDFe] (nolock)
 ORDER BY pkey DESC

-- ============= Log De erro
 SELECT top 10 '' as Staging_Logs_Genericos, * 
   FROM [NFe_Staging].[dbo].[LogsGenericos] (nolock)
  ORDER BY pkey DESC

----- Procura de registros no CCC
SELECT * FROM CCC.ccc.Contribuinte (nolock)
 WHERE InscMF = 2575829008203
--   AND IE     = 804010267114

---- ============= Reprocessamento de contribuintes com erro
-- INSERT INTO [cccEnvio].[FilaCredenciamentoDFe] 
--  (CNPJ, IE, UF)
-- SELECT RegistroCNPJ, RegistroIE, RegistroUF
--   FROM [cccEnvio].[Log_FilaCredenciamentoDFe] 
--  WHERE Erro like 'Erro ao recuperar%'
--  ORDER BY pKey DESC

-- INSERT INTO [cccEnvio].[FilaCredenciamentoDFe] 
--  (CNPJ, IE, UF)
--SELECT RegistroCNPJ, RegistroIE, RegistroUF 
--  FROM [cccEnvio].[Log_FilaFluxoAlternativoCredenciamentoDFe] (nolock)
-- WHERE pkey >= 68
--   AND pkey <= 72
-- ORDER BY pkey DESC