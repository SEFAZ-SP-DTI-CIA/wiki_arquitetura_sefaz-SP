SELECT '' AS '[CCC].[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM      [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccGeraFila'

SELECT '' AS '[CCC].[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM      [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccEnvio'

 SELECT * FROM [CCC].[cccRecebimento].[InformacoesProcessamento]
 SELECT '' AS '[CCC].[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM      [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccRecebimento'

SELECT '' AS '[CCC].[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM      [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico IS NULL

SELECT * FROM [CCC].[cccRecebimento].[InformacoesProcessamento]

SELECT * FROM [CCC].[ccc].[Configuracao_LOG]  c
    LEFT JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 /*
USE CCC
GO

UPDATE c
   SET valor = 'true'
-- SELECT nome, valor
  FROM [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccGeraFila' AND nome = 'FLUXO_ALTERNATIVO_READ_FLAG'

UPDATE c
   --SET valor = '1-20180801,2-20180801,3-20180801,4-20180801,5-20180101,6-20180101,7-20180101,8-20180101,9-20180101,10-20190101'
   SET valor = '1-20180801,2-20180801,3-20180801,4-20180801,5-20180101,6-20180101,7-20180101,8-20180101,9-20180101'
-- SELECT *  
  FROM [CCC].[ccc].[Configuracao] c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE nome = 'FEATURES_DATE'


*/
--select * from ccc.ccc.Configuracao where pkey = 
-- delete from ccc.ccc.Configuracao where pkey = 71