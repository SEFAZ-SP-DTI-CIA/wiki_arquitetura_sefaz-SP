USE CCC
GO

DECLARE @CNPJ    BIGINT = 32416215000184                                                    
DECLARE @NR_CNPJ VARCHAR(14) = (SELECT FORMAT(@CNPJ, 'd14'))

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[Contribuinte] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[ContribuinteHistorico] ch (nolock)
WHERE InscMF = @CNPJ
ORDER BY ch.datu DESC

SELECT '' AS cccEnvio_ContribuinteAtualizacoesQueue, dataModificacao, flagRead, datu, *
FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
WHERE COD_INSCR_MF = @CNPJ

DECLARE @RESTRICAO VARCHAR(16)  = ('%'+ CONVERT(VARCHAR,@CNPJ) +'%')

SELECT '' AS cccEnvio_ContribuinteRejeitado, *
FROM [cccEnvio].[ContribuinteRejeitado] (NOLOCK)
WHERE XML_Request LIKE @RESTRICAO
ORDER BY 2 DESC

SELECT TOP 100 '' AS LogXML, timestampReg, *
FROM [cccEnvio].[LogXML] (NOLOCK)
WHERE TimestampReg > DATEADD(WEEK, -1, GETDATE())
 AND XML_Request LIKE @RESTRICAO
ORDER BY 3 DESC

SELECT TOP 10 '' as Log_FilaCredenciamentoDFe, *
  FROM [cccEnvio].[Log_FilaCredenciamentoDFe] (NOLOCK)
 WHERE RegistroCNPJ = @NR_CNPJ

SELECT TOP 10 '' AS FILA_LOG, * 
  FROM [CADESPSS].[CCC].[FILA_LOG] fl (nolock)
 INNER JOIN [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
    ON fl.ID_ESTABELECIMENTO = es.ID_ESTABELECIMENTO
 WHERE es.NR_CNPJ = @NR_CNPJ
 ORDER BY ID_FILA_LOG DESC

SELECT TOP 10 '' as FILA_FLUXO_ALTERNATIVO_LOG, * 
  FROM [CADESPSS].[CCC].[FILA_FLUXO_ALTERNATIVO_LOG] fl (nolock)
 INNER JOIN [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
    ON fl.ID_ESTABELECIMENTO = es.ID_ESTABELECIMENTO
 WHERE es.NR_CNPJ = @NR_CNPJ
 ORDER BY pkey DESC

SELECT TOP 10 '' as TB_ESTABELECIMENTO, * 
  FROM [CADESPSS].DBO.TB_ESTABELECIMENTO es (nolock)
 WHERE es.NR_CNPJ = @NR_CNPJ

GO