USE CADESP

-- Procura por CNPJ

DECLARE @CNPJ BIGINT = 32971110000197
DECLARE @CNPJ_CHAR CHAR(14) = FORMAT(@CNPJ, 'd14')
DECLARE @ID_MUNCIPIO BIGINT

select emp.* 
  from      dbo.TB_ESTABELECIMENTO est (nolock)
 inner join dbo.TB_EMPRESA         emp (nolock)
    on est.ID_EMPRESA = emp.ID_EMPRESA
 where est.NR_CNPJ = @CNPJ_CHAR

select prd.* 
  from      dbo.TB_ESTABELECIMENTO est (nolock)
 inner join dbo.TB_PRODUTOR_RURAL  prd (nolock)
    on est.ID_PRODUTOR_RURAL = prd.ID_PRODUTOR_RURAL
 where est.NR_CNPJ = @CNPJ_CHAR

select est.* 
  from      dbo.TB_ESTABELECIMENTO est (nolock)
 inner join dbo.TB_ENDERECO        edr (nolock)
    on est.ID_ENDERECO = edr.ID_ENDERECO
 where est.NR_CNPJ = @CNPJ_CHAR

select edr.* 
  from      dbo.TB_ESTABELECIMENTO est (nolock)
 inner join dbo.TB_ENDERECO        edr (nolock)
    on est.ID_ENDERECO = edr.ID_ENDERECO
 where est.NR_CNPJ = @CNPJ_CHAR

select @ID_MUNCIPIO = ID_MUNICIPIO
  from      dbo.TB_ESTABELECIMENTO est (nolock)
 inner join dbo.TB_ENDERECO        edr (nolock)
    on est.ID_ENDERECO = edr.ID_ENDERECO
 where est.NR_CNPJ = @CNPJ_CHAR

select * from dbo.TB_DOM_MUNICIPIO where ID_MUNICIPIO = @ID_MUNCIPIO 

select * 
  from dbo.TB_ESTABELECIMENTO_LOG (nolock)
 where NR_CNPJ = @CNPJ_CHAR

RETURN 

-- Procura por CNPJ Base

DECLARE @CNPJ_BASE BIGINT = 03672254
DECLARE @CNPJ_BASE_CHAR CHAR(8) = FORMAT(@CNPJ_BASE, 'd8')

select IN_IE_UNICA_ESTABELECIMENTOS, * 
  from dbo.TB_EMPRESA         em (nolock)
 where NR_CNPJ_BASE = @CNPJ_BASE_CHAR

select es.* 
  from      dbo.TB_EMPRESA         em (nolock)
 inner join dbo.TB_ESTABELECIMENTO es (nolock)
    on em.ID_EMPRESA = es.ID_EMPRESA
 where NR_CNPJ_BASE = @CNPJ_BASE_CHAR

RETURN

-- Procura por IE 

DECLARE @IE BIGINT = 653088760112
DECLARE @IE_CHAR CHAR(12) = FORMAT(@IE, 'd12') 

select * from dbo.TB_EMPRESA (nolock) where NR_IE_UNICA_ESTABELECIMENTOS = @IE_CHAR

select * from dbo.TB_ESTABELECIMENTO (nolock) where NR_IE = @IE_CHAR

RETURN


-- Procura por Id Estabelecimento

select es.* 
  from      dbo.TB_EMPRESA         em (nolock)
 inner join dbo.TB_ESTABELECIMENTO es (nolock)
    on em.ID_EMPRESA = es.ID_EMPRESA
 where es.ID_ESTABELECIMENTO = 5276157

select em.* 
  from      dbo.TB_EMPRESA         em (nolock)
 inner join dbo.TB_ESTABELECIMENTO es (nolock)
    on em.ID_EMPRESA = es.ID_EMPRESA
 where es.ID_ESTABELECIMENTO = 5276157

RETURN

--====================================

select * from TB_DOM_CNAE_FISCAL
where ID_CNAE_FISCAL = 2605

SELECT * FROM dbo.TB_ESTABELECIMENTO (NOLOCK)
WHERE ID_ESTABELECIMENTO IN (4154834,5317146)

select EM.*
from TB_ESTABELECIMENTO ES
INNER JOIN TB_EMPRESA EM
ON ES.ID_EMPRESA = EM.ID_EMPRESA
where NR_CNPJ = '53143814000141' 

select DT_INICIO_TRANSACAO, DT_FIM_ATIVIDADE, * 
from TB_ESTABELECIMENTO_LOG LG
where NR_CNPJ = '08564557000167' 
ORDER BY LG.DT_INICIO_TRANSACAO DESC

select top 10 * 
from TB_EMPRESA_LOG
where id_empresa = 3517085
order by ID_EMPRESA_LOG desc

--select DT_INICIO_TRANSACAO, * 
--from TB_ESTABELECIMENTO_LOG
--where NR_CNPJ = '23882834000173' 
--  AND NR_IE = '289030990119'

SELECT TOP 1 * FROM TB_ENDERECO
where ID_ENDERECO in (28877696,	28877696)

select * from TB_

SELECT TOP 1 * FROM TB_ENDERECO_CONTATO_CONTABILISTA
where ID_ENDERECO_CONTATO_CONTABILISTA in (27189988,	22478301)

SELECT top 1 * FROM TB_DOM_MUNICIPIO (NOLOCK)

select DT_INICIO_ATIVIDADE, DT_FIM_ATIVIDADE, * 
from TB_ESTABELECIMENTO
where NR_CNPJ IN (
'08372141000228',
'07883336000199',
'09967852000208'
)


SELECT * FROM TB_ESTABELECIMENTO (nolock)
where NR_CNPJ = '67690628000137'

SELECT * FROM TB_ESTABELECIMENTO_LOG (nolock)
where NR_CNPJ = '67690628000137'
order by DT_INICIO_TRANSACAO DESC

SELECT * FROM CCC.FILA_LOG
WHERE ID_ESTABELECIMENTO = 6686107

