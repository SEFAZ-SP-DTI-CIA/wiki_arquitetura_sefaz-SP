USE CCC
GO

SELECT * FROM [cccRecebimento].[InformacoesProcessamento] -- 109028523
SELECT '' AS '[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM      [CCC].[ccc].[Configuracao]     c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccRecebimento' -- 109028523
   AND nome = 'NSUCCC_MOVIMENTO_INICIAL'

----- FILA
SELECT '' AS LogXML_Queue, COUNT(1) AS NroRegistros
  FROM [CCC].[cccRecebimento].[LogXML_Queue] (nolock)

SELECT TOP 50 '' AS LogXML_Queue, *
  FROM [CCC].[cccRecebimento].[LogXML_Queue] (nolock)
  ORDER BY pkeyLogXML DESC

----- LOG
SELECT '' AS LogXML, COUNT(1) AS NroRegistros
  FROM [CCC].[cccRecebimento].[LogXML] (nolock)

SELECT TOP 100 '' AS LogXML, TimestampReg, *, CONVERT(XML, XML_Request), CONVERT(XML, XML_Response)
  FROM [CCC].[cccRecebimento].[LogXML]  lo (nolock)
 --WHERE pkey = 7408964 
 ORDER BY lo.TimestampReg DESC

SELECT TOP 100 '' AS LogXML_ComErro, TimestampReg, *, CONVERT(XML, XML_Request), CONVERT(XML, XML_Response)
  FROM [CCC].[cccRecebimento].[LogXML]  lo (nolock)
 WHERE Erro IS NOT NULL
 ORDER BY lo.TimestampReg DESC

----- Registros de Erro
SELECT '' AS RegistrosLoteErro, COUNT(1) AS NroRegistros FROM [CCC].[cccRecebimento].[RegistrosLoteErro] (nolock)
SELECT TOP 30 '' AS RegistrosLoteErro, timestampReg, *
  FROM [CCC].[cccRecebimento].[RegistrosLoteErro] (nolock)
 ORDER BY pkey DESC

----- Contribuintes fora de SP
SELECT TOP 5 '' AS ContribuinteForaDeSP_OrdeByDatu, c.datu, *
  FROM [CCC].[ccc].[Contribuinte] c (NOLOCK)
 WHERE cUF != 35
 ORDER BY c.datu DESC

SELECT TOP 10 '' AS ContribuinteForaDeSP_orderByPkey, c.datu, *
  FROM [CCC].[ccc].[Contribuinte] c (NOLOCK)
 WHERE cUF != 35
 ORDER BY c.pkey DESC

----- Contribuinte Hist�rico fora de SP
SELECT TOP 10 '' AS ContribuinteHistoricoForaDeSP, c.datu, *
  FROM [CCC].[ccc].[ContribuinteHistorico] c (NOLOCK)
 WHERE cUF != 35
 ORDER BY c.datu DESC

 ---- Contribuinte Historico Log NSUCCCMovto Repetido
SELECT TOP 10 '' AS ContribuinteHistoricoForaDeSP, c.datu, *
  FROM [CCC].[CCC].[ContribuinteHistoricoLogNSUCCCMovtoRepetido] c (NOLOCK)
 WHERE cUF != 35
 ORDER BY c.datu DESC

---- DW
SELECT '' AS '[DW].[Queue]', FORMAT(COUNT(1), '#,#', 'pt-br') AS NroRegistros  
  FROM [DW].[Queue] (NOLOCK)

SELECT TOP 50 '' AS '[DW].[Queue]', * 
  FROM [CCC].[DW].[Queue] (NOLOCK)
 ORDER BY timestampReg DESC

---- Configura��o
SELECT '' AS '[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM     [CCC].[ccc].[Configuracao]     c
 INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
    ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccRecebimento'

 GO
 RETURN

----------------------------------------------------------------------------------
-- Verifica��o de se houve um erro que n�o se auto-corrigiu

SELECT NSUCCCMovto, COUNT(NSUCCCMovto)
  FROM [CCC].[cccRecebimento].[RegistrosLoteErro] (NOLOCK)
 WHERE timestampReg > '2018-01-01'
 GROUP BY NSUCCCMovto
 HAVING COUNT(NSUCCCMovto) > 1

----------------------------------------------------------------------------------

-------- Procura de contribuinte por CNPJ
DECLARE @CNPJ    BIGINT = 26725395000183
DECLARE @NR_CNPJ VARCHAR(14) = (SELECT FORMAT(@CNPJ, 'd14'))

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[CCC].[Contribuinte] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[CCC].[ContribuinteHistorico] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS ContribuinteHistoricoLogNSUCCCMovtoRepetido, datu, * FROM [CCC].[CCC].[ContribuinteHistoricoLogNSUCCCMovtoRepetido] (nolock)
WHERE InscMF = @CNPJ


-------- Procura de contribuinte por NSUCCC
DECLARE @NSUCCC INT = 23052912 

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[CCC].[Contribuinte] (nolock)
WHERE NSUCCC = @NSUCCC

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[CCC].[ContribuinteHistorico] ch (nolock)
WHERE NSUCCC = @NSUCCC
order by ch.datu desc

SELECT '' AS ContribuinteHistoricoLogNSUCCCMovtoRepetido, datu, * FROM [CCC].[CCC].[ContribuinteHistoricoLogNSUCCCMovtoRepetido] (nolock)
WHERE NSUCCC = @NSUCCC

SELECT '' AS RegistrosLoteErro, timestampReg, *
  FROM [CCC].[cccRecebimento].[RegistrosLoteErro] (nolock)
 WHERE NSUCCC = @NSUCCC
 ORDER BY pkey DESC

SELECT TOP 50 '' AS '[DW].[Queue]', * 
  FROM [CCC].[DW].[Queue] (NOLOCK)
 WHERE NSUCCC = @NSUCCC
 ORDER BY pKey DESC

SELECT '' AS '[ETL_NFE].[DWCCC].[ResultadoProcessamento]', *
  FROM [ETL_NFE].[DWCCC].[ResultadoProcessamento] (NOLOCK)
  WHERE NSUCCC = @NSUCCC
  ORDER BY dataProcessamento DESC 

SELECT '' AS '[ETL_NFE].[DWCCC].[ResultadoProcessamento]', *
  FROM [ETL_NFE].[DWCCC].[ResultadoProcessamento] (NOLOCK)
  WHERE NSUCCC = @NSUCCC
  ORDER BY NSUCCCMovto DESC 


-------- Procura de contribuinte por NSUCCCMovto
DECLARE @NSUCCCMovto INT = 86384757 

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[CCC].[Contribuinte] (nolock)
WHERE NSUCCCMovto = @NSUCCCMovto

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[CCC].[ContribuinteHistorico] (nolock)
WHERE NSUCCCMovto = @NSUCCCMovto

SELECT '' AS ContribuinteHistoricoLogNSUCCCMovtoRepetido, datu, * FROM [CCC].[CCC].[ContribuinteHistoricoLogNSUCCCMovtoRepetido] (nolock)
WHERE NSUCCCMovto = @NSUCCCMovto

SELECT '' AS RegistrosLoteErro, timestampReg, *
  FROM [CCC].[cccRecebimento].[RegistrosLoteErro] (nolock)
 WHERE NSUCCCMovto = @NSUCCCMovto
 ORDER BY pkey DESC

SELECT TOP 50 '' AS '[DW].[Queue]', * 
  FROM [CCC].[DW].[Queue] (NOLOCK)
 WHERE NSUCCCMovto = @NSUCCCMovto
 ORDER BY pKey DESC

SELECT '' AS '[ETL_NFE].[DWCCC].[ResultadoProcessamento]', *
  FROM [ETL_NFE].[DWCCC].[ResultadoProcessamento] (NOLOCK)
  WHERE NSUCCCMovto = @NSUCCCMovto
  ORDER BY dataProcessamento DESC 

-------------------------------------------------------------------------------------------------
-- Verifica��o se todos os Contribuintes recebidos pelo CCC de outro estados foram colocados na tabela de Contribuintes Habilitados da NF-e
DECLARE @DezMinutosAtras DATETIME = DATEADD(HOUR, -10, GETDATE())

-- TODO: rever essa query abaixo. A l�gica no CTeAdmin.Contribuinte � que o timestampReg � sempre a 'data inicial', e o timestampUpd � data de altera��o do registro.
SELECT cc.dAtu, ch.timestampUpd, ch.timestampReg, ch.*, cc.* 
  FROM      [CCC].[ccc].[Contribuinte]          cc (nolock)
  LEFT JOIN [CTe_Out].[CTeAdmin].[Contribuinte] ch (nolock)
  ON FORMAT(cc.InscMF, 'd14') = ch.CNPJ
 WHERE cc.dAtu > @DezMinutosAtras
   AND cc.cUF != 35
   AND cc.tpInscMF = 1 -- 1=CNPJ 2=CPF
   AND (inf57dCreden IS NOT NULL OR inf67dCreden IS NOT NULL)
 ORDER BY cc.datu DESC

SELECT cc.dAtu, ch.timestampReg, ch.*, cc.* 
  FROM      [CCC].[ccc].[Contribuinte]                    cc (nolock)
  LEFT JOIN [NFe_Out].[NFeOut].[ContribuintesHabilitados] ch (nolock)
  ON FORMAT(cc.InscMF, 'd14') = ch.CNPJ
 WHERE cc.dAtu > @DezMinutosAtras
   AND cc.cUF != 35
   AND cc.tpInscMF = 1 -- 1=CNPJ 2=CPF
   AND cc.inf55dCreden IS NOT NULL 
   AND cc.ind55 IS NOT NULL
 ORDER BY cc.datu DESC

-- Verifica��o se todos os erros a partir de um certo instante foram corrigidos
SELECT r.timestampReg, c.datu, r.erro, c.*, r.*
 FROM      [CCC].[CCC].[Contribuinte]                 c (nolock)
INNER JOIN [CCC].[cccRecebimento].[RegistrosLoteErro] r (nolock)
   ON c.NSUCCC = r.nsuccc
WHERE r.timestampReg > '2018-12-01'
  and r.timestampReg > c.datu

----
 /* Reprocessamento
 INSERT INTO [cccRecebimento].[LogXML_Queue]
           ([pkeyLogXML]           
           ,[dataModificacao])
	
    SELECT [pkeyLogXML]
		    ,GETDATE()
      FROM [cccRecebimento].[RegistrosLoteErro]
      WHERE ....
 */

 -------------------------------------------------------------------------------------------------
-- Dados por UF 
CREATE TABLE #UF (codigo INT, sigla CHAR(2) )
INSERT INTO  #UF (codigo, sigla) VALUES (11,'RO'),(12,'AC'),(13,'AM'),(14,'RR'),(15,'PA'),(16,'AP'),(17,'TO'),(21,'MA'),(22,'PI'),(23,'CE'),(24,'RN'),(25,'PB'),(26,'PE'),(27,'AL'),(28,'SE'),(29,'BA'),(31,'MG'),(32,'ES'),(33,'RJ'),(35,'SP'),(41,'PR'),(42,'SC'),(43,'RS'),(50,'MS'),(51,'MT'),(52,'GO'),(53,'DF')

SELECT * FROM #UF 

SELECT FORMAT(MAX(NSUCCC), '#,#', 'pt-br') as MaxNSUCCC, cuf , sigla
  FROM [CCC].[CCC].[Contribuinte] C (nolock)
 INNER JOIN #UF u
   ON c.cUF = u.codigo
GROUP BY cuf, sigla
ORDER BY cUF 

SELECT FORMAT(MAX(NSUCCCMovto), '#,#', 'pt-br') as MaxNSUCCCMovto, cuf , sigla
  FROM [CCC].[CCC].[Contribuinte] C (nolock)
 INNER JOIN #UF u
   ON c.cUF = u.codigo
GROUP BY cuf, sigla
ORDER BY cUF

SELECT FORMAT(count(NSUCCC), '#,#', 'pt-br') as NroContribuintes, cuf , sigla
FROM [CCC].[CCC].[Contribuinte] C (nolock)
 INNER JOIN #UF u
   ON c.cUF = u.codigo
GROUP BY cuf, sigla
ORDER BY count(NSUCCC)

DROP TABLE #UF