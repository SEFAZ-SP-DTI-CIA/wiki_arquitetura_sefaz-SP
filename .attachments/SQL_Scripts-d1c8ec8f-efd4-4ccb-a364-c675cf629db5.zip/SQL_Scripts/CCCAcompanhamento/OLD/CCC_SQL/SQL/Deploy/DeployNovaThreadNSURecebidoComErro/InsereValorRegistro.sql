USE [CCC]
GO

declare @pkeyConfiguracaoTipo bigint = (select pkey from ccc.ConfiguracaoTipo where nome = 'PKEY_REGISTRO_NSU_RECEBIDO_COM_ERRO')

INSERT INTO [ccc].[Configuracao]
           ([servico]
           ,[pkeyConfiguracaoTipo]
           ,[valor])
     VALUES
           ('cccRecebimento'
           ,@pkeyConfiguracaoTipo
           ,0)

DECLARE @sleepTime bigint = (select pkey from ccc.ConfiguracaoTipo where nome = 'RECUPERA_NSU_RECEBIDO_COM_ERRO_THREADSLEEP_TIME')

INSERT INTO [ccc].[Configuracao]
           ([servico]
           ,[pkeyConfiguracaoTipo]
           ,[valor])
     VALUES
           ('cccRecebimento'
           ,@sleepTime
           ,600000)
GO



