USE [CCC]
GO

INSERT INTO [ccc].[ConfiguracaoTipo]
           ([nome]
           ,[descricao])
     VALUES
           ('PKEY_REGISTRO_NSU_RECEBIDO_COM_ERRO',
            'Configura��o que indica a pkey do NSU recebido com erro que foi processada')
GO


INSERT INTO [ccc].[ConfiguracaoTipo]
           ([nome]
           ,[descricao])
     VALUES
           ('RECUPERA_NSU_RECEBIDO_COM_ERRO_THREADSLEEP_TIME',
            'Configura��o que indica o sleep time da thread que reprocessa NSUs recebidos com erro. Valor em mil�simos de segundos')
GO
