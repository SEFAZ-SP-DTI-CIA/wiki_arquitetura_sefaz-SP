USE [CCC]


GO
PRINT N'Altering [ccc].[Contribuinte]...';


GO
ALTER TABLE [ccc].[Contribuinte]
    ADD [IndOperNaoContrib] BIT NULL;


GO
PRINT N'Altering [ccc].[ContribuinteHistorico]...';


GO
ALTER TABLE [ccc].[ContribuinteHistorico]
    ADD [IndOperNaoContrib] BIT NULL;


GO
PRINT N'Altering [cccEnvio].[ContribuinteAtualizacoesQueue]...';


GO
ALTER TABLE [cccEnvio].[ContribuinteAtualizacoesQueue]
    ADD [IndOperNaoContrib] BIT NULL;


GO
PRINT N'Altering [cccEnvio].[usp_CCC_Contribuinte_Atualizacoes_Queue_Insert]...';


GO
ALTER PROCEDURE [cccEnvio].[usp_CCC_Contribuinte_Atualizacoes_Queue_Insert]
(
    @cUF               tinyint,
    @TIPO_INSCR_MF     tinyint,
    @COD_INSCR_MF      bigint,
    @IE                bigint,
    @indAtua           tinyint,
    @cSit              tinyint,
    @dSit              datetime,
    @cSitCADESP        smallint,
    @indST             bit,
    @xNome             varchar(100),
    @xFant             varchar(60),
    @UFEnder           varchar(2),
    @xRegApur          varchar(60),
    @CNAE              int,
    @dIniAtiv          datetime,
    @dBaixa            datetime,
    @IEUnica           bigint,
    @IEAtual           bigint,
    @indAtuaEndereco   bit,
    @end_xLgr          varchar(255),
    @end_nro           varchar(60),
    @end_xCpl          varchar(60),
    @end_xBairro       varchar(60),
    @end_cMun          int,
    @end_xMun          varchar(60),
    @end_CEP           int,
    @IndOperNaoContrib bit)        
AS
BEGIN
    SET NOCOUNT ON;
    --SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    
    -- Parameter validation
    DECLARE    @lMsgErro  VARCHAR(1024),
            @lMsgParam VARCHAR(128),
            @lMsgVirg  VARCHAR(5)

    SET    @lMsgVirg  = '';
    SET    @lMsgParam = '';
    
    DECLARE    @pkeyContribuinte BIGINT = -1,
            @agora            DATETIME = GETDATE(),
            @lErrorNumber     BIGINT,
            @lErrorSeverity   BIGINT,
            @lErrorState      BIGINT,
            @lErrorProcedure  VARCHAR(200),
            @lErrorLine       BIGINT,
            @lErrorMessage    VARCHAR(600)

    BEGIN TRY
        DECLARE @DUPLICADO bit = 0

        IF EXISTS (SELECT 1 FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
        WHERE
                ISNULL(cUF              ,'') = ISNULL(@cUF             ,'')
            and ISNULL(TIPO_INSCR_MF    ,'') = ISNULL(@TIPO_INSCR_MF   ,'')
            and ISNULL(COD_INSCR_MF     ,'') = ISNULL(@COD_INSCR_MF    ,'')
            and ISNULL(IE               ,'') = ISNULL(@IE              ,'')
            and ISNULL(indAtua          ,'') = ISNULL(@indAtua         ,'')
            and ISNULL(cSit             ,'') = ISNULL(@cSit            ,'')
            and ISNULL(dSit             ,'') = ISNULL(@dSit            ,'')
            and ISNULL(cSitCADESP       ,'') = ISNULL(@cSitCADESP      ,'')
            and ISNULL(indST            ,'') = ISNULL(@indST           ,'')
            and ISNULL(xNome            ,'') = ISNULL(@xNome           ,'')
            and ISNULL(xFant            ,'') = ISNULL(@xFant           ,'')
            and ISNULL(UFEnder          ,'') = ISNULL(@UFEnder         ,'')
            and ISNULL(xRegApur         ,'') = ISNULL(@xRegApur        ,'')
            and ISNULL(CNAE             ,'') = ISNULL(@CNAE            ,'')
            and ISNULL(dIniAtiv         ,'') = ISNULL(@dIniAtiv        ,'')
            and ISNULL(dBaixa           ,'') = ISNULL(@dBaixa          ,'')
            and ISNULL(IEUnica          ,'') = ISNULL(@IEUnica         ,'')
            and ISNULL(IEAtual          ,'') = ISNULL(@IEAtual         ,'')
            and ISNULL(indAtuaEndereco  ,'') = ISNULL(@indAtuaEndereco ,'')
            and ISNULL(end_xLgr         ,'') = ISNULL(@end_xLgr        ,'')
            and ISNULL(end_nro          ,'') = ISNULL(@end_nro         ,'')
            and ISNULL(end_xCpl         ,'') = ISNULL(@end_xCpl        ,'')
            and ISNULL(end_xBairro      ,'') = ISNULL(@end_xBairro     ,'')
            and ISNULL(end_cMun         ,'') = ISNULL(@end_cMun        ,'')
            and ISNULL(end_xMun         ,'') = ISNULL(@end_xMun        ,'')
            and ISNULL(end_CEP          ,'') = ISNULL(@end_CEP         ,'')
            and ISNULL(IndOperNaoContrib,'') = ISNULL(IndOperNaoContrib,'')
        )
        BEGIN
            SET @DUPLICADO = 1
        END
        ELSE
        BEGIN
            IF EXISTS(SELECT 1 FROM [ccc].[Contribuinte] (NOLOCK)
            WHERE InscMF = @COD_INSCR_MF
                AND dAtu > DATEADD(mi,-2, getdate())
                AND ISNULL(cUF              ,'') = ISNULL(@cUF              ,'')
                AND ISNULL(tpInscMF         ,'') = ISNULL(@TIPO_INSCR_MF    ,'')
                AND ISNULL(InscMF           ,'') = ISNULL(@COD_INSCR_MF     ,'')
                AND ISNULL(IE               ,'') = ISNULL(@IE               ,'')
                AND ISNULL(indAtua          ,'') = ISNULL(@indAtua          ,'')
              --AND ISNULL(cSit             ,'') = ISNULL(@cSit             ,'')
                AND ISNULL(dSit             ,'') = ISNULL(@dSit             ,'')
                AND ISNULL(cSitCADESP       ,'') = ISNULL(@cSitCADESP       ,'')
              --AND ISNULL(indST            ,'') = ISNULL(@indST            ,'')
                AND ISNULL(xNome            ,'') = ISNULL(@xNome            ,'')
                AND ISNULL(xFant            ,'') = ISNULL(@xFant            ,'')
                AND ISNULL(UFEnder          ,'') = ISNULL(@UFEnder          ,'')
              --AND ISNULL(xRegApur         ,'') = ISNULL(@xRegApur         ,'')
                AND ISNULL(CNAE             ,'') = ISNULL(@CNAE             ,'')
                AND ISNULL(dIniAtiv         ,'') = ISNULL(@dIniAtiv         ,'')
                AND ISNULL(dBaixa           ,'') = ISNULL(@dBaixa           ,'')
                AND ISNULL(IEUnica          ,'') = ISNULL(@IEUnica          ,'')
                AND ISNULL(IEAtual          ,'') = ISNULL(@IEAtual          ,'')
                AND ISNULL(indAtuaEndereco  ,'') = ISNULL(@indAtuaEndereco  ,'')
                AND ISNULL(xLgr             ,'') = ISNULL(@end_xLgr         ,'')
                AND ISNULL(nro              ,'') = ISNULL(@end_nro          ,'')
                AND ISNULL(xCpl             ,'') = ISNULL(@end_xCpl         ,'')
                AND ISNULL(xBairro          ,'') = ISNULL(@end_xBairro      ,'')
                AND ISNULL(cMun             ,'') = ISNULL(@end_cMun         ,'')
              --AND ISNULL(end_xMun         ,'') = ISNULL(@end_xMun         ,'')
                AND ISNULL(CEP              ,'') = ISNULL(@end_CEP          ,'')
              --AND ISNULL(IndOperNaoContrib,'') = ISNULL(@IndOperNaoContrib,'')
            )
            BEGIN
                SET @DUPLICADO = 1
            END
        END
        
        IF (@DUPLICADO = 0)
        BEGIN            
            BEGIN TRAN
                --Ap�s a carga inicial vamos gravar em uma tabela separada linhas da fila sem Atualiza��es
                INSERT INTO [cccEnvio].[ContribuinteAtualizacoesQueue] 
                           ([cUF]        , [TIPO_INSCR_MF]   , [COD_INSCR_MF], [IE]      , [indAtua] 
                           ,[cSit]       , [dSit]            , [cSitCADESP]  , [indST]   , [xNome]  , [xFant]
                           ,[UFEnder]    , [xRegApur]        , [CNAE]        , [dIniAtiv], [dBaixa]
                           ,[IEUnica]    , [IEAtual]         , [indAtuaEndereco]
                           ,[end_xLgr]   , [end_nro]         , [end_xCpl]
                           ,[end_xBairro],[end_cMun]         , [end_xMun]
                           ,[end_CEP]    ,[IndOperNaoContrib], [dAtu]) 
                           
                     VALUES
                           (@cUF        , @TIPO_INSCR_MF    , @COD_INSCR_MF   , @IE      , @indAtua,
                            @cSit       , @dSit             , @cSitCADESP     , @indST   , @xNome  , @xFant,
                            @UFEnder    , @xRegApur         , @CNAE           , @dIniAtiv, @dBaixa ,
                            @IEUnica    , @IEAtual          , @indAtuaEndereco,
                            @end_xLgr   , @end_nro          , @end_xCpl,
                            @end_xBairro, @end_cMun         , @end_xMun,
                            @end_CEP    , @IndOperNaoContrib, GETDATE())                        
            
                -- tem que desativar se existir outro contribuinte com mesmo CNPJ mas com outra IE em SP
                -- se estiver excluindo, tem que excluir os CNPJs antigos
                CREATE TABLE #IEsAntigas
                (    
                    IE BIGINT
                )

                IF (@indAtua = 9) -- exclus�o
                BEGIN
                    INSERT INTO #IEsAntigas(IE)
                        SELECT IE
                          FROM [ccc].[Contribuinte]
                         WHERE InscMF = @COD_INSCR_MF
                           AND IE <> @IE
                        -- and cSit = 1 -- tem que excluir todos, mesmo os baixados
                           AND cUF = 35
                END        
                ELSE
                BEGIN
                    INSERT INTO #IEsAntigas (IE)
                        SELECT IE
                          FROM [ccc].[Contribuinte]
                         WHERE InscMF = @COD_INSCR_MF
                           AND IE <> @IE
                           AND cSitIE = 1 -- nos demais casos s� precisa baixar os que est�o ativos
                           AND cUF = 35
                END

                -- o contribuinte tem outra IE mais antiga que tamb�m est� ativa -> precisa colocar na fila novamente para desativar as IEs antigas
                -- ou se for exclus�o do CCC, a� tamb�m tem que excluir todas as IEs antigas do mesmo CNPJ
                -- n�o tem problema para IE �nica porque a coluna IE est� com o valor da IE�nica (os dois est�o com o mesmo valor)
                IF ((SELECT COUNT(1) FROM #IEsAntigas) > 0)
                BEGIN
                    INSERT INTO [cccEnvio].[ContribuinteAtualizacoesQueue] 
                            ([cUF], [TIPO_INSCR_MF], [COD_INSCR_MF], [IE]
                            ,[indAtua] 
                            ,[cSit]
                            ,[dSit]
                            ,[cSitCADESP]
                            ,[indST]
                            ,[xNome]
                            ,[xFant], [UFEnder]
                            ,[xRegApur]
                            ,[CNAE]       , [dIniAtiv], [dBaixa]
                            ,[IEUnica]    , [IEAtual] , [indAtuaEndereco]
                            ,[end_xLgr]   , [end_nro] , [end_xCpl]
                            ,[end_xBairro], [end_cMun]
                            ,[end_xMun]
                            ,[end_CEP], [dInc], [NSUInc], [dAtu], [NSUAtu]
                            ,[flagRead]
                            ,[dataModificacao]
                            ,[UID_execution]
                            ,[IndOperNaoContrib]) 
                    SELECT 
                            [cUF], [tpInscMF], [InscMF], [IE]
                            ,CASE WHEN @indAtua = 9 THEN @indAtua ELSE indAtua END
                            ,0 --[cSit]
                            ,[dSit]
                            ,0 --[cSitCADESP]
                            ,CONVERT (BIT, CASE tpIE WHEN 1 THEN 0 WHEN 2 THEN 1 END) AS [indST]
                            ,@xNome --[xNome] - Alterado 2013-04-30, RS reportou caso em que a IE foi alterada junto com o nome. Ap�s a inclus�o da nova IE com o nome alterado, a desativa��o que geramos posteriormente estava atualizando o CCC com o nome antigo na tabela Pessoa (Ver manual).
                            ,[xFant], [UFEnder]
                            ,CASE regTrib WHEN 1 THEN 'SIMPLES NACIONAL' 
                                          WHEN 2 THEN 'SIMPLES NACIONAL - MEI' 
                                          WHEN 9 THEN 'NORMAL - REGIME PERI�DICO DE APURA��O' 
                                          END AS [xRegApur]
                            ,[CNAE]   , [dIniAtiv], [dBaixa]
                            ,[IEUnica], [IEAtual] , [indAtuaEndereco]
                            ,[xLgr]   , [nro]     , [xCpl]
                            ,[xBairro], [cMun]
                            ,'' AS [xMun]
                            ,[CEP], [dInc], [NSUCCC], [dAtu], [NSUCCCMovto]
                            ,0         -- flagRead
                            ,GETDATE() -- dataModificacao
                            ,null      -- UID_execution
                            ,IndOperNaoContrib
                     FROM [ccc].[Contribuinte] as contribuinte (nolock)
                    WHERE InscMF = @COD_INSCR_MF
                      AND IE in (SELECT IE FROM #IEsAntigas)
                      AND cUF = 35
                END
            COMMIT
        END        
    END TRY
    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
        BEGIN
            ROLLBACK
        END;
        SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
                        + ' Error=['    + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
                        + ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
                        + ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
                        + ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
                        + ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
                        + ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
        THROW 50050, @lMsgErro, 1;
    END CATCH
END
GO
PRINT N'Altering [cccEnvio].[usp_CCC_Grava_Envio_Com_Sucesso]...';


GO
ALTER PROCEDURE [cccEnvio].[usp_CCC_Grava_Envio_Com_Sucesso] 
    @pkeyFilaEnvio BIGINT,
    @TIPO_INSCR_MF TINYINT,
    @COD_INSCR_MF  BIGINT,
    @IE      BIGINT,
    @IEAtual BIGINT,
    @indAtua TINYINT,
    @dInc    DATETIME,
    @NSUInc	 BIGINT,
    @dAtu    DATETIME,
    @NSUAtu  BIGINT,
    @dhResp  DATETIME
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    DECLARE @IE_A_Atualizar   BIGINT,
            @pkeyContribuinte BIGINT = -1,
            @pkeyModificado   BIGINT,
            @Agora            DATETIME,
            @NSUAtuAntigo     BIGINT = -1

    DECLARE @ContribuintesAtualizados TABLE
    (
        [pkey]              bigint           NOT NULL,
        [cUF]               tinyint          NULL,
        [TIPO_INSCR_MF]     tinyint          NULL,
        [COD_INSCR_MF]      bigint           NULL,
        [IE]                bigint           NULL,
        [cSit]              tinyint          NULL,
        [dSit]              datetime         NULL,
        [cSitCADESP]        smallint         NULL,
        [indST]             bit              NULL,
        [xNome]             varchar(100)     NULL,
        [xFant]             varchar(60)      NULL,
        [UFEnder]           varchar(2)       NULL,
        [xRegApur]          varchar(60)      NULL,
        [CNAE]              int              NULL,
        [dIniAtiv]          datetime         NULL,
        [dBaixa]            datetime         NULL,
        [IEUnica]           bigint           NULL,
        [IEAtual]           bigint           NULL,
        [indAtuaEndereco]   bit              NULL,
        [end_xLgr]          varchar(255)     NULL,
        [end_nro]           varchar(60)      NULL,
        [end_xCpl]          varchar(60)      NULL,
        [end_xBairro]       varchar(60)      NULL,
        [end_cMun]          int              NULL,
        [end_xMun]          varchar(60)      NULL,
        [end_CEP]           int              NULL,
        [indAtua]           tinyint          NULL,
        [dInc]              datetime         NULL,
        [NSUInc]            bigint           NULL,
        [dAtu]              datetime         NULL,
        [NSUAtu]            bigint           NULL,
        [flagRead]          bit              NULL,
        [dataModificacao]   datetime         NULL,
        [UID_execution]     uniqueidentifier NULL,
        [IndOperNaoContrib] bit              NULL
    )	
    
    BEGIN TRY
        BEGIN TRAN
            select @pkeyContribuinte = pkey, @NSUAtuAntigo = NSUCCCMovto
            FROM [ccc].[Contribuinte]
            WHERE NSUCCC = @NSUInc
              AND NSUCCCMovto <= @NSUAtu

            DELETE FROM [cccEnvio].[ContribuinteAtualizacoesQueue]
            OUTPUT DELETED.* INTO @ContribuintesAtualizados
            WHERE pkey = @pkeyFilaEnvio
            
            SET @Agora = GETDATE()

            -- se for exclus�o, estamos gravando 9 no cSit (ao inv�s da �ltima situa��o)
            UPDATE @ContribuintesAtualizados
               SET cSit = indAtua
             WHERE indAtua = 9

            IF ((@pkeyContribuinte = -1) AND (@NSUAtuAntigo <> @NSUAtu))
            BEGIN
                INSERT INTO [ccc].[Contribuinte] (
                            [cUF], [tpInscMF], [InscMF], [IE]
                            , [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
                            , [indIEDestOpc], [porte], [regTrib]
                            , [UFEnder], [CNAE], [dIniAtiv]
                            , [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
                            , [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco], [IndOperNaoContrib]
                            , [dInc], [NSUCCC], [dAtu], [NSUCCCMovto], [dhResp]
                        )
                     SELECT [cUF], [TIPO_INSCR_MF], [COD_INSCR_MF], [IE]
                           , [cSit], 1, [dSit], [xNome], [xFant], CONVERT(TINYINT, CASE indST WHEN 0 THEN 1 WHEN 1 THEN 2 END) AS [tpIE]
                           , 0, 0, CASE xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 
                                                 WHEN 'SIMPLES NACIONAL - MEI' THEN 2 
                                                 WHEN 'NORMAL - REGIME PERI�DICO DE APURA��O' THEN 9 
                                                 END AS [regTrib]
                           , [UFEnder], [CNAE], [dIniAtiv]
                           , [dBaixa], [end_cMun], [end_xLgr], [end_nro], [end_xCpl], [end_xBairro], [end_CEP]
                           , [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco], [IndOperNaoContrib]
                           , @Agora, @NSUInc, @Agora, @NSUAtu, @dhResp
                        FROM @ContribuintesAtualizados
                -- obs: na inser��o n�o coloca na contribuinte hist�rico 
                --(sen�o na hora de atualizar, vai dar erro na constraint de NSUAtu para ContribuinteHistorico)

                -- insert para DW
                INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
                VALUES (@NSUInc, @NSUAtu, @Agora)
            END
            ELSE 
            BEGIN
                DECLARE @ContribuinteOld TABLE
                (
                        [pkey]				BIGINT			NOT NULL,
                        [NSUCCC]			BIGINT			NOT NULL,
                        [NSUCCCMovto]		BIGINT			NOT NULL,
                        [cUF]				TINYINT			NULL,
                        [tpInscMF]			TINYINT			NULL,
                        [InscMF]			BIGINT			NULL,
                        [IE]				BIGINT			NULL,
                        [cSitIE]			TINYINT			NULL,
                        [cSitCNPJ]			TINYINT			NULL,
                        [dSit]				DATE			NULL,
                        [xNome]				VARCHAR(100)	NULL,
                        [xFant]				VARCHAR(60)		NULL,
                        [tpIE]				TINYINT			NULL,
                        [indIEDestOpc]		TINYINT			NULL,
                        [porte]				TINYINT			NULL,
                        [regTrib]			TINYINT			NULL,
                        [UFEnder]			CHAR(2)			NULL,
                        [CNAE]				INT				NULL,
                        [dIniAtiv]			DATETIME		NULL,
                        [dBaixa]			DATETIME		NULL,
                        [cMun]				INT				NULL,
                        [xLgr]				VARCHAR(255)	NULL,
                        [nro]				VARCHAR(60)		NULL,
                        [xCpl]				VARCHAR(60)		NULL,
                        [xBairro]			VARCHAR(60)		NULL,
                        [CEP]				INT				NULL,
                        [ind55]				TINYINT			NULL,
                        [dIniCreden]		DATE			NULL,
                        [ind65]				TINYINT			NULL,
                        [dCreden]			DATE			NULL,
                        [inf57dCreden]		DATE			NULL,
                        [ind5701]			TINYINT			NULL,
                        [ind5702]			TINYINT			NULL,
                        [ind5703]			TINYINT			NULL,
                        [ind5704]			TINYINT			NULL,
                        [ind5705]			TINYINT			NULL,
                        [ind5706]			TINYINT			NULL,
                        [cSitCADESP]		SMALLINT		NULL,
                        [IEUnica]			BIGINT			NULL,
                        [IEAtual]			BIGINT			NULL,
                        [indAtua]			TINYINT			NULL,
                        [indAtuaEndereco]	BIT				NULL,
                        [dInc]				DATETIME		NOT NULL,
                        [dAtu]				DATETIME		NULL,
                        [dhResp]			DATETIME		NULL,
                        [IndOperNaoContrib] BIT             NULL
                )
                
                UPDATE 
                    [ccc].[Contribuinte] 
                SET
                    @pkeyModificado = [ccc].[Contribuinte].pkey,
                    [NSUCCC]      = @NSUInc,
                    [NSUCCCMovto] = @NSUAtu,
                    [cUF]        = ca.cUF,
                    [tpInscMF]   = ca.TIPO_INSCR_MF,
                    [InscMF]     = ca.COD_INSCR_MF,
                    [IE]         = ca.IE,
                    [cSitIE]     = ca.cSit,
                    [dSit]       = ca.dSit,
                    [cSitCADESP] = ca.cSitCADESP,
                    [tpIE] = CONVERT(TINYINT, CASE ca.indST WHEN 0 THEN 1 WHEN 1 THEN 2 END),
                    [xNome]    = ca.xNome,
                    [xFant]    = ca.xFant,
                    [UFEnder]  = ca.UFEnder,
                    [regTrib]  = CASE ca.xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 WHEN 'SIMPLES NACIONAL - MEI' THEN 2 WHEN 'NORMAL - REGIME PERI�DICO DE APURA��O' THEN 9 END,
                    [CNAE]     = ca.CNAE,
                    [dIniAtiv] = ca.dIniAtiv,
                    [dBaixa]   = ca.dBaixa,					
                    [IEUnica]  = ca.IEUnica,
                    [IEAtual]  = ca.IEAtual,
                    [indAtuaEndereco] = ca.indAtuaEndereco,
                    [xLgr]    = ca.end_xLgr,
                    [nro]     = ca.end_nro,
                    [xCpl]    = ca.end_xCpl,
                    [xBairro] = ca.end_xBairro,
                    [cMun]    = ca.end_cMun,
                    [CEP]     = ca.end_CEP,
                    [indAtua] = ca.indAtua,
                    [dAtu]    = @Agora,
                    [dhResp]  = @dhResp,
                    [IndOperNaoContrib] = ca.IndOperNaoContrib
                OUTPUT DELETED.* 
                  INTO @ContribuinteOld
                  FROM @ContribuintesAtualizados ca
                 WHERE [ccc].[Contribuinte].NSUCCC = @NSUInc
                   AND [ccc].[Contribuinte].NSUCCCMovto <= @NSUAtu	

                -- S� insere na contribuinte hist�rico se o @NSUAtuAntigo for diferente porque sen�o vai dar erro de constraint
                if (@NSUAtuAntigo <> @NSUAtu)
                begin
                    INSERT INTO [ccc].[ContribuinteHistorico]
                               ([pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
                                , [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
                                , [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
                                , [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
                                , [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
                                , [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
                                , [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco], [IndOperNaoContrib]
                                , [dInc], [dAtu], [dhResp]							   
                               )
                         select  [pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
                                , [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
                                , [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
                                , [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
                                , [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
                                , [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
                                , [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco], [IndOperNaoContrib]
                                , [dInc], @Agora, [dhResp]
                            FROM @ContribuinteOld

                    -- insert para DW
                    INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
                    VALUES (@NSUInc, @NSUAtu, @Agora)
                END
                -- n�o insere no DW se n�o houve altera��o no NSUAtu
            END			


        COMMIT
    END TRY
    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
        BEGIN
            ROLLBACK
        END;

        DECLARE @lMsgErro varchar(1024)
        SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
                        + ' Error=['    + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
                        + ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
                        + ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
                        + ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
                        + ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
                        + ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
        THROW 50050, @lMsgErro, 1;
    END CATCH
END
GO
PRINT N'Altering [cccEnvio].[usp_CCC_Grava_Envio_Contribuinte_Repetido]...';


GO
ALTER PROCEDURE [cccEnvio].[usp_CCC_Grava_Envio_Contribuinte_Repetido] 
    @pkeyFilaEnvio BIGINT,
    @NSUInc        BIGINT = NULL,
    @dhResp        DATETIME,
    @XML_Request   VARCHAR(MAX),
    @XML_Response  VARCHAR(MAX),
    @Erro          VARCHAR(MAX),
    @NSUAtu        BIGINT = NULL
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    DECLARE @IE_A_Atualizar   BIGINT,
            @pkeyContribuinte BIGINT = -1,
            @pkeyModificado   BIGINT,
            @Agora            DATETIME,
            @NSUAtuAntigo     BIGINT = -1			

    DECLARE @ContribuintesAtualizados TABLE
    (
        [pkey]              bigint           NOT NULL,
        [cUF]               tinyint          NULL,
        [TIPO_INSCR_MF]     tinyint          NULL,
        [COD_INSCR_MF]      bigint           NULL,
        [IE]                bigint           NULL,
        [cSit]              tinyint          NULL,
        [dSit]              datetime         NULL,
        [cSitCADESP]        smallint         NULL,
        [indST]             bit              NULL,
        [xNome]             varchar(100)     NULL,
        [xFant]             varchar(60)      NULL,
        [UFEnder]           varchar(2)       NULL,
        [xRegApur]          varchar(60)      NULL,
        [CNAE]              int              NULL,
        [dIniAtiv]          datetime         NULL,
        [dBaixa]            datetime         NULL,
        [IEUnica]           bigint           NULL,
        [IEAtual]           bigint           NULL,
        [indAtuaEndereco]   bit              NULL,
        [end_xLgr]          varchar(255)     NULL,
        [end_nro]           varchar(60)      NULL,
        [end_xCpl]          varchar(60)      NULL,
        [end_xBairro]       varchar(60)      NULL,
        [end_cMun]          int              NULL,
        [end_xMun]          varchar(60)      NULL,
        [end_CEP]           int              NULL,
        [indAtua]           tinyint          NULL,
        [dInc]              datetime         NULL,
        [NSUInc]            bigint           NULL,
        [dAtu]              datetime         NULL,
        [NSUAtu]            bigint           NULL,
        [flagRead]          bit              NULL,
        [dataModificacao]   datetime         NULL,
        [UID_execution]     uniqueidentifier NULL,
        [IndOperNaoContrib] bit              NULL
    )
    
    BEGIN TRY
        BEGIN TRAN
            DELETE FROM [cccEnvio].[ContribuinteAtualizacoesQueue]
            OUTPUT DELETED.*
              INTO @ContribuintesAtualizados
             WHERE pkey = @pkeyFilaEnvio
            
            SET @Agora = GETDATE()

            -- se for exclus�o, estamos gravando 9 no cSit (ao inv�s da �ltima situa��o)
            UPDATE @ContribuintesAtualizados
               SET cSit = indAtua
             WHERE indAtua = 9
            
            INSERT INTO cccEnvio.LogXML
            (
                XML_Request,
                XML_Response,
                Erro,
                TimestampReg
            )
            VALUES 
            (
                @XML_Request,
                @XML_Response,
                @Erro,
                @agora
            )

            IF (@NSUInc IS NOT NULL)
            BEGIN
                SELECT @pkeyContribuinte = pkey, @NSUAtuAntigo = NSUCCCMovto
                  FROM [ccc].[Contribuinte]
                 WHERE NSUCCC = @NSUInc

                IF (@pkeyContribuinte <> -1 AND @NSUAtuAntigo < @NSUAtu)
                BEGIN
                    DECLARE @ContribuinteOld TABLE
                    (
                        [pkey]				BIGINT			NOT NULL,
                        [NSUCCC]			BIGINT			NOT NULL,
                        [NSUCCCMovto]		BIGINT			NOT NULL,
                        [cUF]				TINYINT			NULL,
                        [tpInscMF]			TINYINT			NULL,
                        [InscMF]			BIGINT			NULL,
                        [IE]				BIGINT			NULL,
                        [cSitIE]			TINYINT			NULL,
                        [cSitCNPJ]			TINYINT			NULL,
                        [dSit]				DATE			NULL,
                        [xNome]				VARCHAR(100)	NULL,
                        [xFant]				VARCHAR(60)		NULL,
                        [tpIE]				TINYINT			NULL,
                        [indIEDestOpc]		TINYINT			NULL,
                        [porte]				TINYINT			NULL,
                        [regTrib]			TINYINT			NULL,
                        [UFEnder]			CHAR(2)			NULL,
                        [CNAE]				INT				NULL,
                        [dIniAtiv]			DATETIME		NULL,
                        [dBaixa]			DATETIME		NULL,
                        [cMun]				INT				NULL,
                        [xLgr]				VARCHAR(255)	NULL,
                        [nro]				VARCHAR(60)		NULL,
                        [xCpl]				VARCHAR(60)		NULL,
                        [xBairro]			VARCHAR(60)		NULL,
                        [CEP]				INT				NULL,
                        [ind55]				TINYINT			NULL,
                        [dIniCreden]		DATE			NULL,
                        [ind65]				TINYINT			NULL,
                        [dCreden]			DATE			NULL,
                        [inf57dCreden]		DATE			NULL,
                        [ind5701]			TINYINT			NULL,
                        [ind5702]			TINYINT			NULL,
                        [ind5703]			TINYINT			NULL,
                        [ind5704]			TINYINT			NULL,
                        [ind5705]			TINYINT			NULL,
                        [ind5706]			TINYINT			NULL,
                        [cSitCADESP]		SMALLINT		NULL,
                        [IEUnica]			BIGINT			NULL,
                        [IEAtual]			BIGINT			NULL,
                        [indAtua]			TINYINT			NULL,
                        [indAtuaEndereco]	BIT				NULL,
                        [dInc]				DATETIME		NOT NULL,
                        [dAtu]				DATETIME		NULL,
                        [dhResp]			DATETIME		NULL,
                        [IndOperNaoContrib] BIT             NULL
                    )

                    UPDATE 
                        [ccc].[Contribuinte] 
                    SET
                        [cUF]        = ca.cUF,
                        [tpInscMF]   = ca.TIPO_INSCR_MF,
                        [InscMF]     = ca.COD_INSCR_MF,
                        [IE]         = ca.IE,
                        [cSitIE]     = ca.cSit,
                        [dSit]       = ca.dSit,
                        [cSitCADESP] = ca.cSitCADESP,
                        [tpIE] = CONVERT(TINYINT, CASE ca.indST WHEN 0 THEN 1 WHEN 1 THEN 2 END),
                        [xNome]    = ca.xNome,
                        [xFant]    = ca.xFant,
                        [UFEnder]  = ca.UFEnder,
                        [regTrib]  = CASE ca.xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 
                                                      WHEN 'SIMPLES NACIONAL - MEI' THEN 2 
                                                      WHEN 'NORMAL - REGIME PERI�DICO DE APURA��O' THEN 9 
                                                      END,
                        [CNAE]     = ca.CNAE,
                        [dIniAtiv] = ca.dIniAtiv,
                        [dBaixa]   = ca.dBaixa,					
                        [IEUnica]  = ca.IEUnica,
                        [IEAtual]  = ca.IEAtual,
                        [indAtuaEndereco]   = ca.indAtuaEndereco,
                        [xLgr]              = ca.end_xLgr,
                        [nro]               = ca.end_nro,
                        [xCpl]              = ca.end_xCpl,
                        [xBairro]           = ca.end_xBairro,
                        [cMun]              = ca.end_cMun,
                        [CEP]               = ca.end_CEP,
                        [indAtua]           = ca.indAtua,
                        [IndOperNaoContrib] = ca.IndOperNaoContrib,
                        [dAtu]        = @Agora,
                        [NSUCCCMovto] = @NSUAtu
                    OUTPUT DELETED.* INTO @ContribuinteOld
                      FROM @ContribuintesAtualizados ca
                     WHERE [ccc].[Contribuinte].NSUCCC = @NSUInc

                    INSERT INTO [ccc].[ContribuinteHistorico]
                                ([pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
                                , [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
                                , [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
                                , [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
                                , [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
                                , [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
                                , [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco]
                                , [dInc], [dAtu], [dhResp]							   
                                )
                            select  [pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
                                , [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
                                , [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
                                , [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
                                , [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
                                , [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
                                , [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco]
                                , [dInc], @Agora, [dhResp]
                            FROM @ContribuinteOld

                    INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
                    VALUES (@NSUInc, @NSUAtu, @Agora)
                END
                ELSE IF (@pkeyContribuinte = -1)
                BEGIN
                    INSERT INTO [ccc].[Contribuinte] (
                                  [cUF], [tpInscMF], [InscMF], [IE]
                                , [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
                                , [indIEDestOpc], [porte], [regTrib]
                                , [UFEnder], [CNAE], [dIniAtiv]
                                , [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
                                , [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco], [IndOperNaoContrib]
                                , [dInc], [NSUCCC], [dAtu], [NSUCCCMovto], [dhResp]
                            )
                         SELECT [cUF], [TIPO_INSCR_MF], [COD_INSCR_MF], [IE]
                               , [cSit], 1, [dSit], [xNome], [xFant]
                               , CONVERT(TINYINT, CASE indST WHEN 0 THEN 1 
                                                             WHEN 1 THEN 2 
                                                             END) AS [tpIE]
                               , 0, 0, CASE xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 
                                                     WHEN 'SIMPLES NACIONAL - MEI' THEN 2 
                                                     WHEN 'NORMAL - REGIME PERI�DICO DE APURA��O' THEN 9 
                                                     END AS [regTrib]
                               , [UFEnder], [CNAE], [dIniAtiv]
                               , [dBaixa], [end_cMun], [end_xLgr], [end_nro], [end_xCpl], [end_xBairro], [end_CEP]
                               , [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco], [IndOperNaoContrib]
                               , @Agora, @NSUInc, @Agora, ISNULL(@NSUAtu, @NSUInc), @dhResp
                            FROM @ContribuintesAtualizados

                    INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
                    VALUES (@NSUInc, @NSUAtu, @Agora)
                END
            END			
        COMMIT
    END TRY
    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
        BEGIN
            ROLLBACK
        END;

        DECLARE @lMsgErro varchar(1024)
        SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
                        + ' Error=['    + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
                        + ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
                        + ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
                        + ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
                        + ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
                        + ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
        THROW 50050, @lMsgErro, 1;
    END CATCH
END
GO
PRINT N'Altering [cccEnvio].[usp_CCC_GetFilaEnvio]...';


GO
ALTER PROCEDURE [cccEnvio].[usp_CCC_GetFilaEnvio]
(
    @MAX_TIME_LOCK_DATA_CONSUMER AS INT
)
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    DECLARE @lMsgErro VARCHAR(1024)
    
    BEGIN TRY
        BEGIN TRAN
            DECLARE @UID_EXECUTION AS UNIQUEIDENTIFIER
            SET	@UID_EXECUTION = NEWID()

            UPDATE [cccEnvio].[ContribuinteAtualizacoesQueue] WITH(READPAST, ROWLOCK, UPDLOCK)
            SET	UID_execution = @UID_EXECUTION,
                flagRead = 1,
                dataModificacao = GETDATE()
            WHERE
                pkey IN (SELECT TOP 1 pkey
                           FROM [cccEnvio].[ContribuinteAtualizacoesQueue] WITH(READPAST, ROWLOCK, UPDLOCK)
                          WHERE flagRead = 0 
                             OR flagRead is null
                             OR DATEADD(second, @MAX_TIME_LOCK_DATA_CONSUMER, dataModificacao) <= GETDATE()
                          ORDER BY pkey asc)
            SELECT
               [pkey]
              ,[cUF]
              ,[TIPO_INSCR_MF]
              ,[COD_INSCR_MF]
              ,[IE]
              ,[cSit]
              ,[dSit]
              ,[cSitCADESP]
              ,[indST]
              ,[xNome]
              ,[xFant]
              ,[UFEnder]
              ,[xRegApur]
              ,[CNAE]
              ,[dIniAtiv]
              ,[dBaixa]
              ,[IEUnica]
              ,[IEAtual]
              ,[indAtuaEndereco]
              ,[end_xLgr]
              ,[end_nro]
              ,[end_xCpl]
              ,[end_xBairro]
              ,[end_cMun]
              ,[end_xMun]
              ,[end_CEP]
              ,[indAtua]
              ,[dInc]
              ,[NSUInc]
              ,[dAtu]
              ,[NSUAtu]
              ,[IndOperNaoContrib]
            FROM 
                [cccEnvio].[ContribuinteAtualizacoesQueue] WITH(NOLOCK)
            WHERE
                UID_execution = @UID_EXECUTION
        COMMIT;
    END TRY

    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
        BEGIN
            ROLLBACK
        END;

        --DECLARE @lMsgErro varchar(1024)
        SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
                        + ' Error=['    + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
                        + ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
                        + ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
                        + ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
                        + ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
                        + ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
        THROW 50050, @lMsgErro, 1;
    END CATCH
END
GO
PRINT N'Refreshing [ccc].[usp_CCC_ObterContribuinte]...';


GO
EXECUTE sp_refreshsqlmodule N'[ccc].[usp_CCC_ObterContribuinte]';


GO
PRINT N'Refreshing [cccRecebimento].[usp_CCC_Contribuinte_Insert]...';


GO
EXECUTE sp_refreshsqlmodule N'[cccRecebimento].[usp_CCC_Contribuinte_Insert]';


GO
PRINT N'Update complete.';


GO
