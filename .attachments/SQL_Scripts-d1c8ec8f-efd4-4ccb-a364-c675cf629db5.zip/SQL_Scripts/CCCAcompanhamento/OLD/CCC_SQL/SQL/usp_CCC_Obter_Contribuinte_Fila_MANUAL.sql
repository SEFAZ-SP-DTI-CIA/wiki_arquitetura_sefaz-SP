DECLARE @CNPJ VARCHAR(14) = '08561701000101'

		DECLARE	@return_value int,
			@UFEnder char(2),
			@end_xLgr varchar(150),
			@end_nro varchar(6),
			@end_xCpl varchar(156),
			@end_xBairro varchar(72),
			@end_cMun int,
			@end_CEP char(8)
	   
		DECLARE @IND_ATUALIZACAO tinyint --Indicador de atualiza��o do Cadastro Centralizado
		DECLARE @RET_IE_ANTERIOR bigint		
		DECLARE @ID_FILA bigint, 
				@ID_EMPRESA bigint, 
				@ID_ESTABELECIMENTO bigint = (SELECT top 1 ID_ESTABELECIMENTO FROM TB_ESTABELECIMENTO (nolock) where NR_CNPJ = @CNPJ),
				@ID_ENDERECO bigint,
				@ID_PRODUTOR_RURAL bigint

		EXEC	[CCC].[usp_CCC_Obter_DadosEndereco]
				@ID_ESTABELECIMENTO,
				@ID_ENDERECO OUTPUT,
				@UFEnder OUTPUT,
				@end_xLgr OUTPUT,
				@end_nro OUTPUT,
				@end_xCpl OUTPUT,
				@end_xBairro OUTPUT,
				@end_cMun OUTPUT,
				@end_CEP OUTPUT

		select  top (1) 
					  estab.ID_EMPRESA,
					  estab.ID_ESTABELECIMENTO,
					  estab.ID_PRODUTOR_RURAL,
					  @ID_ENDERECO as ID_ENDERECO,
					  '35' as cUF,  -- C�digo da UF respons�vel pelo cadastro			  
					  estab.NR_CNPJ as CNPJ,
					  NULL as CPF,			  
					  CASE emp.IN_IE_UNICA_ESTABELECIMENTOS
								WHEN 1 THEN (emp.NR_IE_UNICA_ESTABELECIMENTOS) --SE CONTRIBUINTE EM REGIME DE IEUnica, enviar IE Unica no campo IE.
								ELSE (estab.NR_IE)END AS IE,
					  @IND_ATUALIZACAO as indAtua,
					  [CCC].[UFC_OBTEM_SITUACAO_CONTRIBUINTE_CCC] (
									estab.ID_SITUACAO_ESTABELECIMENTO,
									estab.ID_OCORRENCIA_CADASTRAL,
									ISNULL(emp.IN_IE_UNICA_ESTABELECIMENTOS, 0),
									NR_IE_UNICA_ESTABELECIMENTOS) as cSit,
					  estab.DT_INICIO_VALIDADE_SITUACAO as dSit,
					  cast(cast(estab.ID_SITUACAO_ESTABELECIMENTO as VARCHAR(2)) + cast(estab.ID_OCORRENCIA_CADASTRAL as VARCHAR(3)) as smallint) as cSitCADESP,
					  estab.IN_SUBST_TRIBUTARIO as indST,
					  LTRIM(RTRIM(ISNULL(emp.NM_EMPRESARIAL, PR.NM_EMPRESARIAL))) as xNome,
					  LTRIM(RTRIM(estab.NM_FANTASIA)) as xFant,
					  @UFEnder as UFEnder,
					  ISNULL(ra.DS_REGIME_APURACAO, 'PRODUTOR RURAL - CNPJ') as xRegApur,
					  CCC.UFC_OBTEM_CNAE_FISCAL_CCC(estab.ID_CNAE_FISCAL) AS CNAE,
					  estab.DT_INICIO_ATIVIDADE as dIniAtiv,
					  estab.DT_FIM_ATIVIDADE as dBaixa,
					  ISNULL(emp.IN_IE_UNICA_ESTABELECIMENTOS, 0) as indIEUnica,
					  emp.NR_IE_UNICA_ESTABELECIMENTOS as IEUnica,
					  @RET_IE_ANTERIOR  as IEAtual,
					  --@ATUALIZACAO_ENDERECO as indAtuaEndereco, 
					  @end_xLgr as end_xLgr,
					  @end_nro as end_nro,
					  @end_xCpl as end_xCpl,
					  @end_xBairro as end_xBairro,
					  @end_cMun as end_cMun, 
					  NULL as end_xMun,
					  @end_CEP as end_CEP
		FROM
			[dbo].[TB_ESTABELECIMENTO] AS estab WITH (NOLOCK) 
		LEFT JOIN
			[dbo].[TB_EMPRESA] AS emp WITH (NOLOCK) 
			ON estab.ID_EMPRESA = emp.ID_EMPRESA 	
			LEFT JOIN TB_DOM_REGIME_APURACAO ra WITH (NOLOCK) 
				ON emp.ID_REGIME_APURACAO = ra.ID_REGIME_APURACAO 
		LEFT JOIN
			[dbo].[TB_PRODUTOR_RURAL] AS PR WITH (NOLOCK) 
			ON estab.ID_PRODUTOR_RURAL = PR.ID_PRODUTOR_RURAL 					
		WHERE estab.NR_CNPJ = @CNPJ