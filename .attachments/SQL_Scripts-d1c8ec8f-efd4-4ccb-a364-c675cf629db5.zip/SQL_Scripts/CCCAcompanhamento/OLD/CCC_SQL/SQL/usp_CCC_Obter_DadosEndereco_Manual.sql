USE CADESP
GO


DECLARE @ID_ESTABELECIMENTO AS BIGINT = 65981

--SELECT @ID_ESTABELECIMENTO = ID_ESTABELECIMENTO FROM TB_ESTABELECIMENTO (nolock) WHERE NR_CNPJ = '00862023000105'
--SELECT @ID_ESTABELECIMENTO 

DECLARE  @ID_ENDERECO BIGINT 
DECLARE  @UFEnder CHAR(2) 
DECLARE  @end_xLgr varchar(150) 
DECLARE  @end_nro varchar(6) 
DECLARE  @end_xCpl varchar(156) 
DECLARE  @end_xBairro varchar(60) 
DECLARE  @end_cMun int 
DECLARE  @end_CEP char(8)

SET NOCOUNT ON    

DECLARE @IE varchar(12)
DECLARE @indST bit
DECLARE @ID_ESTABELECIMENTO_local bigint 
 
 set @ID_ESTABELECIMENTO_local = @ID_ESTABELECIMENTO
 
 -- Sen�o o endere�o est� vindo em branco
 --SET TRANSACTION ISOLATION LEVEL READ COMMITTED

    -- demanda 2013/02/01: contribuintes com IE iniciada por 8, endere�o em outra UF, e n�o Substituto Tribut�rio (indST=0)
    -- - O registro s� deve ser enviado ao CCC se CNAE do estabelecimento � de energia el�trica ou comunica��o 
    --   e Existe registro do procurador no estado preenchido no CADESP, com endere�o correto e UF igual a SP
    select @ID_ENDERECO = estab.ID_ENDERECO,
           @indST = IN_SUBST_TRIBUTARIO,
           @UFEnder = UF.SG_UF,
           @IE = CASE emp.IN_IE_UNICA_ESTABELECIMENTOS
                    WHEN 1 THEN (emp.NR_IE_UNICA_ESTABELECIMENTOS) --SE CONTRIBUINTE EM REGIME DE IEUnica, enviar IE Unica no campo IE.
                    ELSE (estab.NR_IE)
                 END
    FROM      [dbo].[TB_ESTABELECIMENTO] estab
    LEFT JOIN [dbo].[TB_EMPRESA]         AS emp 
      ON estab.ID_EMPRESA = emp.ID_EMPRESA
    LEFT join [dbo].[TB_ENDERECO] ende 
      ON estab.ID_ENDERECO = ende.ID_ENDERECO
    INNER JOIN TB_DOM_MUNICIPIO MU 
      ON MU.ID_MUNICIPIO = ende.ID_MUNICIPIO
    INNER JOIN TB_DOM_UF UF 
      ON UF.ID_UF = MU.ID_UF
    WHERE estab.ID_ESTABELECIMENTO = @ID_ESTABELECIMENTO_local

    if (@IE like '8%') AND (@indST = 0) AND (@UFEnder != 'SP') 
    BEGIN
         SELECT 1
        set @UFEnder = null -- para n�o ficar sujeira na mem�ria
        set @ID_ENDERECO = null -- para n�o ficar sujeira na mem�ria
         
        -- pegando o endere�o do procurador se CNAE de el�trica ou comunica��o, sen�o vai tudo null
        select  @ID_ENDERECO = estabp.ID_ENDERECO,
                @UFEnder = UF.SG_UF,
                @end_xLgr = LTRIM(RTRIM(dtl.DS_TIPO_LOGRADOURO + ' ' + ende.NM_LOGRADOURO)),
                @end_nro = LTRIM(RTRIM(ende.NR_LOGRADOURO)),
                @end_xCpl = LTRIM(RTRIM(ende.NM_COMPLEMENTO_LOGRADOURO)),
                @end_xBairro = SUBSTRING(LTRIM(RTRIM(ende.NM_BAIRRO)), 1, 60),
                @end_cMun = MU.CD_MUNICIPIO_IBGE, 
                --NULL as end_xMun,
                @end_CEP = ende.NR_CEP
        from dbo.TB_ESTABELECIMENTO estab
        inner join dbo.TB_DOM_CNAE_FISCAL cnae 
            on estab.ID_CNAE_FISCAL = cnae.id_cnae_fiscal 
        inner join [dbo].[TB_ESTABELECIMENTO_PROCURADOR] estabp 
            on estabp.ID_ESTABELECIMENTO = estab.ID_ESTABELECIMENTO
        inner join dbo.TB_ENDERECO ende 
            on estabp.ID_ENDERECO = ende.ID_ENDERECO     
                INNER JOIN TB_DOM_MUNICIPIO MU 
                    ON MU.ID_MUNICIPIO = ende.ID_MUNICIPIO
                INNER JOIN TB_DOM_UF UF 
                    ON UF.ID_UF = MU.ID_UF
                INNER JOIN TB_DOM_TIPO_LOGRADOURO dtl
                    ON dtl.ID_TIPO_LOGRADOURO = ende.ID_TIPO_LOGRADOURO
        where estab.ID_ESTABELECIMENTO = @ID_ESTABELECIMENTO_local
            and cd_cnae_fiscal in
            ('3511501', '3513100', '6110802', '6110803', '6110899', '6120599', '6130200', '6142600', '6143400', 
            '6190601', '6190602', '6190699', '6311900', '6319400')
            and UF.SG_UF = 'SP' -- se n�o for de SP n�o � pra retornar o endere�o do procurador

    END
    else
    BEGIN
        -- Todos os demais casos, pega os dados de endere�o do estabelecimento
         SELECT 2
         select @ID_ENDERECO = estab.ID_ENDERECO,
                @UFEnder = UF.SG_UF,
                @end_xLgr = LTRIM(RTRIM(dtl.DS_TIPO_LOGRADOURO + ' ' + ende.NM_LOGRADOURO)),
                @end_nro = LTRIM(RTRIM(ende.NR_LOGRADOURO)),
                @end_xCpl = LTRIM(RTRIM(ende.NM_COMPLEMENTO_LOGRADOURO)),
                @end_xBairro = SUBSTRING(LTRIM(RTRIM(ende.NM_BAIRRO)), 1, 60),
                @end_cMun = MU.CD_MUNICIPIO_IBGE, 
                --NULL as end_xMun,
                @end_CEP = ende.NR_CEP
         from [dbo].[TB_ESTABELECIMENTO] AS estab
         inner join dbo.TB_ENDERECO ende 
         on estab.ID_ENDERECO = ende.ID_ENDERECO     
                INNER JOIN TB_DOM_MUNICIPIO MU 
                    ON MU.ID_MUNICIPIO = ende.ID_MUNICIPIO
                INNER JOIN TB_DOM_UF UF 
                    ON UF.ID_UF = MU.ID_UF
                INNER JOIN TB_DOM_TIPO_LOGRADOURO dtl
                    ON dtl.ID_TIPO_LOGRADOURO = ende.ID_TIPO_LOGRADOURO
         where estab.ID_ESTABELECIMENTO = @ID_ESTABELECIMENTO_local
    END

SELECT @ID_ENDERECO as 'ID_Endereco', @UFEnder as 'UFEnder', @end_xLgr as 'end_xlgr'
,
@end_nro as end_nro,
@end_xCpl as end_xCpl ,
@end_xBairro as end_xBairro, 
@end_cMun as end_cMun ,
@end_CEP as end_CEP 