--=============================================================================================
--Acompanhamento gen�rico
--=============================================================================================
USE CCC
GO

DECLARE @CNPJ    BIGINT = 608000116
DECLARE @NR_CNPJ VARCHAR(14) = (SELECT FORMAT(@CNPJ, 'd14'))

--SELECT ID_SITUACAO_ESTABELECIMENTO, ID_OCORRENCIA_CADASTRAL, * 
--FROM CADESP.DBO.TB_ESTABELECIMENTO (NOLOCK)
--WHERE NR_CNPJ =  @NR_CNPJ

--SELECT DT_INICIO_TRANSACAO, ID_SITUACAO_ESTABELECIMENTO, ID_OCORRENCIA_CADASTRAL, * 
--FROM CADESP.DBO.TB_ESTABELECIMENTO_LOG L (NOLOCK)
--WHERE NR_CNPJ =  @NR_CNPJ
--ORDER BY L.DT_INICIO_TRANSACAO DESC

SELECT '' AS CCC_Contribuinte, datu, * FROM [CCC].[Contribuinte] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS CCC_ContribuinteHistorico, datu, * FROM [CCC].[ContribuinteHistorico] (nolock)
WHERE InscMF = @CNPJ

SELECT '' AS cccEnvio_ContribuinteAtualizacoesQueue, dataModificacao, flagRead, datu, *
FROM [cccEnvio].[ContribuinteAtualizacoesQueue] (NOLOCK)
WHERE COD_INSCR_MF = @CNPJ

DECLARE @RESTRICAO VARCHAR(16)  = ('%'+ CONVERT(VARCHAR,@CNPJ) +'%')
--SELECT @RESTRICAO

SELECT TOP 5 '' AS cccEnvio_ContribuinteRejeitado, *
FROM [cccEnvio].[ContribuinteRejeitado] (NOLOCK)
WHERE XML_Request LIKE @RESTRICAO
ORDER BY 2 DESC

SELECT TOP 10 '' AS LogXML, timestampReg, *
FROM [cccEnvio].[LogXML] (NOLOCK)
--WHERE erro NOT LIKE '%9320%'
WHERE TimestampReg > '2017-12-20'
 AND XML_Request LIKE @RESTRICAO
ORDER BY 3 DESC
