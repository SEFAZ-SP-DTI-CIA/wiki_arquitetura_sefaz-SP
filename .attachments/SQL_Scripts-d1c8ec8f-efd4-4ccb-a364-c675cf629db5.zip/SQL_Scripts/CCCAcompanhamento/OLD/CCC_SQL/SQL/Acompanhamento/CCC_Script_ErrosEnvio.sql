USE CCC
GO

DECLARE @hoje DATETIME = CONVERT(DATE, GETDATE())

DECLARE @dataInicial DATETIME = '2017-12-06 10:00:00' -- DATEADD(DAY, -9, @hoje)

DECLARE @dataFinal DATETIME = DATEADD(DAY, 1, @hoje)

--SELECT @dataInicial, @dataFinal, @hoje

;WITH cte AS
(
	SELECT pkeyLogXML, CONVERT(XML, XML_Request) AS request, CONVERT(XML, XML_Response) AS response, XML_Request, Erro, TimestampReg
	FROM cccEnvio.ContribuinteRejeitado (NOLOCK)
	WHERE TimestampReg BETWEEN @dataInicial AND @dataFinal
)

SELECT pkeyLogXML,
		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:CNPJ)[1]', 'VARCHAR(14)') as CNPJ,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infCad/ns:UFEnder)[1]', 'VARCHAR(10)') as UFEnder,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infCad/ns:dBaixa)[1]', 'VARCHAR(10)') as dBaixa,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:IE)[1]', 'VARCHAR(14)') as IE,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infCad/ns:CNAE)[1]', 'VARCHAR(8)') as CNAE,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infCad/ns:cMun)[1]', 'VARCHAR(8)') as cMun,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infCad/ns:xFant)[1]', 'VARCHAR(60)') as xFant,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infEnder/ns:nro)[1]', 'VARCHAR(60)') as nro,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infEnder/ns:xLgr)[1]', 'VARCHAR(255)') as xLgr,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infEnder/ns:CEP)[1]', 'VARCHAR(255)') as CEP,

		request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:infEnder/ns:xBairro)[1]', 'VARCHAR(60)') as xBairro,

		response.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe";	(/ns:retManutCCC/ns:cStat)[1]', 'VARCHAR(5)') + ' - ' +
		response.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe";  (/ns:retManutCCC/ns:xMotivo)[1]', 'VARCHAR(255)') as Erro1,

		TimestampReg,
		request
--INTO #TempTable
FROM cte
--where erro like '%9305%' -- IE inv�lida
--where erro NOT like '%9317%' -- Data de Baixa informada para cSitIE=1
--WHERE erro like '%9308%' -- CNAE inexistente
--where erro like '%9305%' -- IE inv�lida
--where erro like '%9302%' -- CNPJ inv�lido
--where erro like '%9321%' -- UF do Endere�o difere da UF para contribuinte normal (tpIE=�1-Normal�)
--where erro like '%215%' -- Falha schema
--where erro like '%9311%' -- Data da Baixa inferior � Data de In�cio de Atividade
--where request.value('declare namespace ns="http://www.portalfiscal.inf.br/nfe"; (/ns:manutCCC/ns:CNPJ)[1]', 'VARCHAR(14)') = '9093996000100'
ORDER BY cte.TimestampReg DESC

/*
SELECT CNPJ FROM #TempTable 
WHERE LEN(xLgr) = 1

DROP TABLE #TempTable
*/