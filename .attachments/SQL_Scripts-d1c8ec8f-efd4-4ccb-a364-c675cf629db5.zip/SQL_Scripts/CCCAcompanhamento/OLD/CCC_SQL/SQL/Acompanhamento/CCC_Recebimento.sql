USE CCC
GO

SELECT '' AS '[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM [ccc].[Configuracao] c
INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
   ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccRecebimento'
   AND nome = 'NSUCCC_INICIAL'

-----
SELECT TOP 30 '' AS LogXML_Queue, COUNT(1) AS NroRegistros
  FROM [cccRecebimento].[LogXML_Queue] (nolock)

SELECT TOP 30 '' AS LogXML_Queue, *
  FROM [cccRecebimento].[LogXML_Queue] (nolock)
  ORDER BY pkeyLogXML DESC
-----
SELECT TOP 30 '' AS LogXML, COUNT(1) AS NroRegistros
  FROM [cccRecebimento].[LogXML] (nolock)

SELECT TOP 30 '' AS LogXML, *
  FROM [cccRecebimento].[LogXML] (nolock)
  ORDER BY pkey DESC
-----
SELECT TOP 30 '' AS RegistrosLoteErro, COUNT(1) AS NroRegistros
  FROM [cccRecebimento].[RegistrosLoteErro] (nolock)

SELECT TOP 30 '' AS RegistrosLoteErro, *
  FROM [cccRecebimento].[RegistrosLoteErro] (nolock)
 ORDER BY pkey DESC
-----
SELECT TOP 500 '' AS ContribuinteForaDeSP, c.datu, indAtua, *
  FROM [ccc].[Contribuinte] c (NOLOCK)
 WHERE cUF != 35
 ORDER BY 4 DESC
----
SELECT TOP 5 '' AS '[DW].[Queue]', * 
  FROM [DW].[Queue] (NOLOCK)
 ORDER BY timestampReg DESC
SELECT '' AS '[DW].[Queue]', COUNT(1) AS NroRegistros 
  FROM [DW].[Queue] (NOLOCK)
----
SELECT '' AS '[ccc].[Configuracao]', servico, nome, valor, descricao, *
  FROM [ccc].[Configuracao] c
INNER JOIN [CCC].[ccc].[ConfiguracaoTipo] ct
   ON c.pkeyConfiguracaoTipo = ct.pkey
 WHERE servico = 'cccRecebimento'

 GO
 RETURN
----
 /* Reprocessamento
 INSERT INTO [cccRecebimento].[LogXML_Queue]
           ([pkeyLogXML]           
           ,[dataModificacao])
	
    SELECT [pkeyLogXML]
		    ,GETDATE()
      FROM [cccRecebimento].[RegistrosLoteErro]
      WHERE ....
 */
