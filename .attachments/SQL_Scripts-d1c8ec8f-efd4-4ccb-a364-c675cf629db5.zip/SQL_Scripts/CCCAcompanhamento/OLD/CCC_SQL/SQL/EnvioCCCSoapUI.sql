SELECT '<manutCCC xmlns="http://www.portalfiscal.inf.br/nfe" versao="2.00">
             <tpAmb>1</tpAmb>
             <verAplic>SP_CCC_ENV2.0.0.0</verAplic>
             <cUF>35</cUF>
             <CNPJ>'+right('00000000000000' + cast(InscMF as varchar(14)), 14)+'</CNPJ>
             <IE>'+right(' 000000000000' + cast(IE as varchar(12)), 12)+'</IE>
             <cSitIE>'+CONVERT(varchar(1), cSitIE)+'</cSitIE>
             <cSitCNPJ>1</cSitCNPJ>
             <dSit>'+CONVERT(varchar(10), dSit)+'</dSit>
             <infCad>
                    <xNome>'+xNome+'</xNome>
                    '+CASE WHEN ((xFant IS NOT NULL) AND (RTRIM(LTRIM(xFant)) != '')) THEN '<xFant>'+xFant+'</xFant>' ELSE '' END+'
                    <tpIE>'+CONVERT(varchar(max), tpIE)+'</tpIE>
                    <indIEDestOpc>'+CONVERT(varchar(max), indIEDestOpc)+'</indIEDestOpc>
                    <porte>'+CONVERT(varchar(max), porte)+'</porte>
                    <regTrib>'+CONVERT(varchar(max), regTrib)+'</regTrib>
                    <UFEnder>'+CONVERT(varchar(max), UFEnder)+'</UFEnder>
                    <CNAE>'+CONVERT(varchar(max), CNAE)+'</CNAE>
                    <dIniAtiv>'+CONVERT(varchar(max), CAST(dIniAtiv AS DATE))+'</dIniAtiv>
                    <cMun>'+CONVERT(varchar(max), cMun)+'</cMun>
             </infCad>
<infEnder>
                    <xLgr>'+xLgr+'</xLgr>
                    <nro>'+CONVERT(varchar(max), nro)+'</nro>
                    '+CASE WHEN xCpl IS NOT NULL THEN '<xCpl>'+xCpl+'</xCpl>' ELSE '' END+'
                    <xBairro>'+xBairro+'</xBairro>
                    <CEP>'+right(' 00000000' + cast(CEP as varchar(8)), 8)+'</CEP>
             </infEnder>
             </manutCCC>'
  FROM [CCC].[ccc].[Contribuinte]
  where IE='112347127116' and cSitIE=1
