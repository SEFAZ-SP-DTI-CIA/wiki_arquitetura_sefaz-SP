﻿USE [CCC]


GO
PRINT N'Altering [ccc].[Contribuinte]...';


GO
ALTER TABLE [ccc].[Contribuinte] ALTER COLUMN [indAtua] TINYINT NULL;


GO
PRINT N'Altering [ccc].[ContribuinteHistorico]...';


GO
ALTER TABLE [ccc].[ContribuinteHistorico] ALTER COLUMN [indAtua] TINYINT NULL;


GO
PRINT N'Altering [cccEnvio].[usp_CCC_Grava_Envio_Com_Sucesso]...';


GO
ALTER PROCEDURE [cccEnvio].[usp_CCC_Grava_Envio_Com_Sucesso] 
	@pkeyFilaEnvio BIGINT,
	@TIPO_INSCR_MF tinyint,
	@COD_INSCR_MF  BIGINT,
	@IE      BIGINT,
	@IEAtual BIGINT,
	@indAtua TINYINT,
	@dInc    DATETIME,
	@NSUInc	 BIGINT,
	@dAtu    DATETIME,
	@NSUAtu  BIGINT,
	@dhResp  DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

	DECLARE @IE_A_Atualizar   BIGINT,
			@pkeyContribuinte BIGINT = -1,
			@pkeyModificado   BIGINT,
			@Agora            DATETIME,
			@NSUAtuAntigo     BIGINT = -1

	DECLARE @ContribuintesAtualizados TABLE
	(
		[pkey]            [bigint]       NOT NULL,
		[cUF]             [tinyint]      NULL,
		[TIPO_INSCR_MF]   [tinyint]      NULL,
		[COD_INSCR_MF]    [bigint]       NULL,
		[IE]              [bigint]       NULL,
		[cSit]            [tinyint]      NULL,
		[dSit]            [datetime]     NULL,
		[cSitCADESP]      [smallint]     NULL,
		[indST]           [bit]          NULL,
		[xNome]           [varchar](100) NULL,
		[xFant]           [varchar](60)  NULL,
		[UFEnder]         [varchar](2)   NULL,
		[xRegApur]        [varchar](60)  NULL,
		[CNAE]            [int]          NULL,
		[dIniAtiv]        [datetime]     NULL,
		[dBaixa]          [datetime]     NULL,
		[IEUnica]         [bigint]       NULL,
		[IEAtual]         [bigint]       NULL,
		[indAtuaEndereco] [bit]          NULL,
		[end_xLgr]        [varchar](255) NULL,
		[end_nro]         [varchar](60)  NULL,
		[end_xCpl]        [varchar](60)  NULL,
		[end_xBairro]     [varchar](60)  NULL,
		[end_cMun]        [int]          NULL,
		[end_xMun]        [varchar](60)  NULL,
		[end_CEP]         [int]          NULL,
		[indAtua]         [tinyint]      NULL,
		[dInc]            [datetime]     NULL,
		[NSUInc]          [bigint]       NULL,
		[dAtu]            [datetime]     NULL,
		[NSUAtu]          [bigint]       NULL,
		[flagRead]        [bit]          NULL,
		[dataModificacao] [datetime]     NULL,
		[UID_execution]   [uniqueidentifier] NULL
	)	
    
    BEGIN TRY
		BEGIN TRAN
			select @pkeyContribuinte = pkey, @NSUAtuAntigo = NSUCCCMovto
			FROM [ccc].[Contribuinte]
			WHERE NSUCCC = @NSUInc
			  AND NSUCCCMovto <= @NSUAtu

			DELETE FROM [cccEnvio].[ContribuinteAtualizacoesQueue]
			OUTPUT DELETED.* INTO @ContribuintesAtualizados
			WHERE pkey = @pkeyFilaEnvio
			
			SET @Agora = GETDATE()

			-- se for exclusão, estamos gravando 9 no cSit (ao invés da última situação)
			UPDATE @ContribuintesAtualizados
			   SET cSit = indAtua
			 WHERE indAtua = 9

			IF ((@pkeyContribuinte = -1) AND (@NSUAtuAntigo <> @NSUAtu))
			BEGIN
				INSERT INTO [ccc].[Contribuinte] (
							[cUF], [tpInscMF], [InscMF], [IE]
							, [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
							, [indIEDestOpc], [porte], [regTrib]
							, [UFEnder], [CNAE], [dIniAtiv]
							, [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
							, [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco]
							, [dInc], [NSUCCC], [dAtu], [NSUCCCMovto], [dhResp]
						)
					 SELECT [cUF], [TIPO_INSCR_MF], [COD_INSCR_MF], [IE]
						   , [cSit], 1, [dSit], [xNome], [xFant], CONVERT(TINYINT, CASE indST WHEN 0 THEN 1 WHEN 1 THEN 2 END) AS [tpIE]
						   , 0, 0, CASE xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 WHEN 'SIMPLES NACIONAL - MEI' THEN 2 WHEN 'NORMAL - REGIME PERIÓDICO DE APURAÇÃO' THEN 9 END AS [regTrib]
						   , [UFEnder], [CNAE], [dIniAtiv]
						   , [dBaixa], [end_cMun], [end_xLgr], [end_nro], [end_xCpl], [end_xBairro], [end_CEP]
						   , [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco]
						   , @Agora, @NSUInc, @Agora, @NSUAtu, @dhResp
						FROM @ContribuintesAtualizados
				-- obs: na inserção não coloca na contribuinte histórico 
				--(senão na hora de atualizar, vai dar erro na constraint de NSUAtu para ContribuinteHistorico)

				-- insert para DW
				INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
				VALUES (@NSUInc, @NSUAtu, @Agora)
			END
			ELSE 
			BEGIN
				DECLARE @ContribuinteOld TABLE
				(
					    [pkey]				BIGINT			NOT NULL,
						[NSUCCC]			BIGINT			NOT NULL,
						[NSUCCCMovto]		BIGINT			NOT NULL,
						[cUF]				TINYINT			NULL,
						[tpInscMF]			TINYINT			NULL,
						[InscMF]			BIGINT			NULL,
						[IE]				BIGINT			NULL,
						[cSitIE]			TINYINT			NULL,
						[cSitCNPJ]			TINYINT			NULL,
						[dSit]				DATE			NULL,
						[xNome]				VARCHAR(100)	NULL,
						[xFant]				VARCHAR(60)		NULL,
						[tpIE]				TINYINT			NULL,
						[indIEDestOpc]		TINYINT			NULL,
						[porte]				TINYINT			NULL,
						[regTrib]			TINYINT			NULL,
						[UFEnder]			CHAR(2)			NULL,
						[CNAE]				INT				NULL,
						[dIniAtiv]			DATETIME		NULL,
						[dBaixa]			DATETIME		NULL,
						[cMun]				INT				NULL,
						[xLgr]				VARCHAR(255)	NULL,
						[nro]				VARCHAR(60)		NULL,
						[xCpl]				VARCHAR(60)		NULL,
						[xBairro]			VARCHAR(60)		NULL,
						[CEP]				INT				NULL,
						[ind55]				TINYINT			NULL,
						[dIniCreden]		DATE			NULL,
						[ind65]				TINYINT			NULL,
						[dCreden]			DATE			NULL,
						[inf57dCreden]		DATE			NULL,
						[ind5701]			TINYINT			NULL,
						[ind5702]			TINYINT			NULL,
						[ind5703]			TINYINT			NULL,
						[ind5704]			TINYINT			NULL,
						[ind5705]			TINYINT			NULL,
						[ind5706]			TINYINT			NULL,
						[cSitCADESP]		SMALLINT		NULL,
						[IEUnica]			BIGINT			NULL,
						[IEAtual]			BIGINT			NULL,
						[indAtua]			TINYINT			NULL,
						[indAtuaEndereco]	BIT				NULL,
						[dInc]				DATETIME		NOT NULL,
						[dAtu]				DATETIME		NULL,
						[dhResp]			DATETIME		NULL
				)
				
				UPDATE 
					[ccc].[Contribuinte] 
				SET
					@pkeyModificado = [ccc].[Contribuinte].pkey,
					[NSUCCC]      = @NSUInc,
					[NSUCCCMovto] = @NSUAtu,
					[cUF]        = ca.cUF,
					[tpInscMF]   = ca.TIPO_INSCR_MF,
					[InscMF]     = ca.COD_INSCR_MF,
					[IE]         = ca.IE,
					[cSitIE]     = ca.cSit,
					[dSit]       = ca.dSit,
					[cSitCADESP] = ca.cSitCADESP,
					[tpIE] = CONVERT(TINYINT, CASE ca.indST WHEN 0 THEN 1 WHEN 1 THEN 2 END),
					[xNome]    = ca.xNome,
					[xFant]    = ca.xFant,
					[UFEnder]  = ca.UFEnder,
					[regTrib]  = CASE ca.xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 WHEN 'SIMPLES NACIONAL - MEI' THEN 2 WHEN 'NORMAL - REGIME PERIÓDICO DE APURAÇÃO' THEN 9 END,
					[CNAE]     = ca.CNAE,
					[dIniAtiv] = ca.dIniAtiv,
					[dBaixa]   = ca.dBaixa,					
					[IEUnica]  = ca.IEUnica,
					[IEAtual]  = ca.IEAtual,
					[indAtuaEndereco] = ca.indAtuaEndereco,
					[xLgr]    = ca.end_xLgr,
					[nro]     = ca.end_nro,
					[xCpl]    = ca.end_xCpl,
					[xBairro] = ca.end_xBairro,
					[cMun]    = ca.end_cMun,
					[CEP]     = ca.end_CEP,
					[indAtua] = ca.indAtua,
					[dAtu]    = @Agora,
					[dhResp]  = @dhResp
				OUTPUT DELETED.* INTO @ContribuinteOld
				FROM @ContribuintesAtualizados ca
				WHERE [ccc].[Contribuinte].NSUCCC = @NSUInc
				  and [ccc].[Contribuinte].NSUCCCMovto <= @NSUAtu	

				-- Só insere na contribuinte histórico se o @NSUAtuAntigo for diferente porque senão vai dar erro de constraint
				if (@NSUAtuAntigo <> @NSUAtu)
				begin
					INSERT INTO [ccc].[ContribuinteHistorico]
							   ([pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
								, [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
								, [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
								, [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
								, [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
								, [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
								, [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco]
								, [dInc], [dAtu], [dhResp]							   
							   )
						 select  [pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
								, [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
								, [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
								, [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
								, [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
								, [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
								, [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco]
								, [dInc], @Agora, [dhResp]
							FROM @ContribuinteOld

					-- insert para DW
					INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
					VALUES (@NSUInc, @NSUAtu, @Agora)
				END
				-- não insere no DW se não houve alteração no NSUAtu
			END			


		COMMIT
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT > 0)
		BEGIN
			ROLLBACK
		END;

		DECLARE @lMsgErro varchar(1024)
		SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
						+ ' Error=['    + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
						+ ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
						+ ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
						+ ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
						+ ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
						+ ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
		THROW 50050, @lMsgErro, 1;
	END CATCH
END
GO
PRINT N'Altering [cccEnvio].[usp_CCC_Grava_Envio_Contribuinte_Repetido]...';


GO

/*
 * Procedure utilizada apenas no caso do erro 
 * ncStats:9320  Rejeicao: Contribuinte (CNPJ/IE ja cadastrado para a UF e dados nao foram alterados)
 * ncStats:9322  Rejeicao: Contribuinte (CNPJ / IE) ja excluido para a UF.
 * 2015-03-24 - Gravar no Historico se for atualizacao e NSUAtu novo <> NSUAtu antigo
 */
ALTER PROCEDURE [cccEnvio].[usp_CCC_Grava_Envio_Contribuinte_Repetido] 
	@pkeyFilaEnvio BIGINT,
	@NSUInc        BIGINT = NULL,
	@dhResp        DATETIME,
	@XML_Request   VARCHAR(MAX),
	@XML_Response  VARCHAR(MAX),
	@Erro          VARCHAR(MAX),
	@NSUAtu        BIGINT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

	DECLARE @IE_A_Atualizar   BIGINT,
			@pkeyContribuinte BIGINT = -1,
			@pkeyModificado   BIGINT,
			@Agora            DATETIME,
			@dAtu             DATETIME=NULL,
			@NSUAtuAntigo     BIGINT = -1			

	DECLARE @ContribuintesAtualizados TABLE
	(
		[pkey]            [bigint]       NOT NULL,
		[cUF]             [tinyint]      NULL,
		[TIPO_INSCR_MF]   [tinyint]      NULL,
		[COD_INSCR_MF]    [bigint]       NULL,
		[IE]              [bigint]       NULL,
		[cSit]            [tinyint]      NULL,
		[dSit]            [datetime]     NULL,
		[cSitCADESP]      [smallint]     NULL,
		[indST]           [bit]          NULL,
		[xNome]           [varchar](100) NULL,
		[xFant]           [varchar](60)  NULL,
		[UFEnder]         [varchar](2)   NULL,
		[xRegApur]        [varchar](60)  NULL,
		[CNAE]            [int]          NULL,
		[dIniAtiv]        [datetime]     NULL,
		[dBaixa]          [datetime]     NULL,
		[IEUnica]         [bigint]       NULL,
		[IEAtual]         [bigint]       NULL,
		[indAtuaEndereco] [bit]          NULL,
		[end_xLgr]        [varchar](255) NULL,
		[end_nro]         [varchar](60)  NULL,
		[end_xCpl]        [varchar](60)  NULL,
		[end_xBairro]     [varchar](60)  NULL,
		[end_cMun]        [int]          NULL,
		[end_xMun]        [varchar](60)  NULL,
		[end_CEP]         [int]          NULL,
		[indAtua]         [tinyint]      NULL,
		[dInc]            [datetime]     NULL,
		[NSUInc]          [bigint]       NULL,
		[dAtu]            [datetime]     NULL,
		[NSUAtu]          [bigint]       NULL,
		[flagRead]        [bit]          NULL,
		[dataModificacao] [datetime]     NULL,
		[UID_execution]   [uniqueidentifier] NULL
	)
    
    BEGIN TRY
		BEGIN TRAN
			DELETE FROM [cccEnvio].[ContribuinteAtualizacoesQueue]
			OUTPUT DELETED.*
			  INTO @ContribuintesAtualizados
			 WHERE pkey = @pkeyFilaEnvio
			
			SET @Agora = GETDATE()

			-- se for exclusão, estamos gravando 9 no cSit (ao invés da última situação)
			UPDATE @ContribuintesAtualizados
			   SET cSit = indAtua
			 WHERE indAtua = 9
			
			IF (@NSUAtu is NOT NULL)
			BEGIN
				set @dAtu = @Agora
			END

			INSERT INTO cccEnvio.LogXML
			(
				XML_Request,
				XML_Response,
				Erro,
				TimestampReg
			)
			VALUES 
			(
				@XML_Request,
				@XML_Response,
				@Erro,
				@agora
			)

			IF (@NSUInc IS NOT NULL)
			BEGIN
				SELECT @pkeyContribuinte = pkey, @NSUAtuAntigo = NSUCCCMovto
				FROM [ccc].[Contribuinte]
				WHERE NSUCCC = @NSUInc

				IF (@pkeyContribuinte <> -1)
				BEGIN
					DECLARE @ContribuinteOld TABLE
					(
						[pkey]				BIGINT			NOT NULL,
						[NSUCCC]			BIGINT			NOT NULL,
						[NSUCCCMovto]		BIGINT			NOT NULL,
						[cUF]				TINYINT			NULL,
						[tpInscMF]			TINYINT			NULL,
						[InscMF]			BIGINT			NULL,
						[IE]				BIGINT			NULL,
						[cSitIE]			TINYINT			NULL,
						[cSitCNPJ]			TINYINT			NULL,
						[dSit]				DATE			NULL,
						[xNome]				VARCHAR(100)	NULL,
						[xFant]				VARCHAR(60)		NULL,
						[tpIE]				TINYINT			NULL,
						[indIEDestOpc]		TINYINT			NULL,
						[porte]				TINYINT			NULL,
						[regTrib]			TINYINT			NULL,
						[UFEnder]			CHAR(2)			NULL,
						[CNAE]				INT				NULL,
						[dIniAtiv]			DATETIME		NULL,
						[dBaixa]			DATETIME		NULL,
						[cMun]				INT				NULL,
						[xLgr]				VARCHAR(255)	NULL,
						[nro]				VARCHAR(60)		NULL,
						[xCpl]				VARCHAR(60)		NULL,
						[xBairro]			VARCHAR(60)		NULL,
						[CEP]				INT				NULL,
						[ind55]				TINYINT			NULL,
						[dIniCreden]		DATE			NULL,
						[ind65]				TINYINT			NULL,
						[dCreden]			DATE			NULL,
						[inf57dCreden]		DATE			NULL,
						[ind5701]			TINYINT			NULL,
						[ind5702]			TINYINT			NULL,
						[ind5703]			TINYINT			NULL,
						[ind5704]			TINYINT			NULL,
						[ind5705]			TINYINT			NULL,
						[ind5706]			TINYINT			NULL,
						[cSitCADESP]		SMALLINT		NULL,
						[IEUnica]			BIGINT			NULL,
						[IEAtual]			BIGINT			NULL,
						[indAtua]			TINYINT			NULL,
						[indAtuaEndereco]	BIT				NULL,
						[dInc]				DATETIME		NOT NULL,
						[dAtu]				DATETIME		NULL,
						[dhResp]			DATETIME		NULL
					)

					UPDATE 
						[ccc].[Contribuinte] 
					SET
						[cUF]        = ca.cUF,
						[tpInscMF]   = ca.TIPO_INSCR_MF,
						[InscMF]     = ca.COD_INSCR_MF,
						[IE]         = ca.IE,
						[cSitIE]     = ca.cSit,
						[dSit]       = ca.dSit,
						[cSitCADESP] = ca.cSitCADESP,
						[tpIE] = CONVERT(TINYINT, CASE ca.indST WHEN 0 THEN 1 WHEN 1 THEN 2 END),
						[xNome]    = ca.xNome,
						[xFant]    = ca.xFant,
						[UFEnder]  = ca.UFEnder,
						[regTrib]  = CASE ca.xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 WHEN 'SIMPLES NACIONAL - MEI' THEN 2 WHEN 'NORMAL - REGIME PERIÓDICO DE APURAÇÃO' THEN 9 END,
						[CNAE]     = ca.CNAE,
						[dIniAtiv] = ca.dIniAtiv,
						[dBaixa]   = ca.dBaixa,					
						[IEUnica]  = ca.IEUnica,
						[IEAtual]  = ca.IEAtual,
						[indAtuaEndereco] = ca.indAtuaEndereco,
						[xLgr]    = ca.end_xLgr,
						[nro]     = ca.end_nro,
						[xCpl]    = ca.end_xCpl,
						[xBairro] = ca.end_xBairro,
						[cMun]    = ca.end_cMun,
						[CEP]     = ca.end_CEP,
						[indAtua] = ca.indAtua,
						[dAtu]        = @Agora,
						[NSUCCCMovto] = @NSUAtu
					OUTPUT DELETED.* INTO @ContribuinteOld
					  FROM @ContribuintesAtualizados ca
					 WHERE [ccc].[Contribuinte].NSUCCC = @NSUInc

					-- Só insere na contribuinte histórico se o @NSUAtuAntigo for diferente porque senão vai dar erro de constraint
					if (@NSUAtuAntigo < @NSUAtu)
					begin
						INSERT INTO [ccc].[ContribuinteHistorico]
								   ([pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
									, [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
									, [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
									, [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
									, [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
									, [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
									, [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco]
									, [dInc], [dAtu], [dhResp]							   
								   )
							 select  [pkey], [NSUCCC], [NSUCCCMovto], [cUF], [tpInscMF], [InscMF]
									, [IE], [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
									, [indIEDestOpc], [porte], [regTrib], [UFEnder], [CNAE], [dIniAtiv]			
									, [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
									, [ind55], [dIniCreden], [ind65], [dCreden], [inf57dCreden]		
									, [ind5701], [ind5702], [ind5703], [ind5704], [ind5705], [ind5706]
									, [cSitCADESP], [IEUnica], [IEAtual], [indAtuaEndereco]
									, [dInc], @Agora, [dhResp]
								FROM @ContribuinteOld

						-- insert para DW
						INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
						VALUES (@NSUInc, @NSUAtu, @Agora)
					END
					-- não insere no DW se não houve alteração no NSUAtu
				END
				ELSE
				BEGIN
					INSERT INTO [ccc].[Contribuinte] (
								[cUF], [tpInscMF], [InscMF], [IE]
								, [cSitIE], [cSitCNPJ], [dSit], [xNome], [xFant], [tpIE]
								, [indIEDestOpc], [porte], [regTrib]
								, [UFEnder], [CNAE], [dIniAtiv]
								, [dBaixa], [cMun], [xLgr], [nro], [xCpl], [xBairro], [CEP]
								, [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco]
								, [dInc], [NSUCCC], [dAtu], [NSUCCCMovto], [dhResp]
							)
						 SELECT [cUF], [TIPO_INSCR_MF], [COD_INSCR_MF], [IE]
							   , [cSit], 1, [dSit], [xNome], [xFant], CONVERT(TINYINT, CASE indST WHEN 0 THEN 1 WHEN 1 THEN 2 END) AS [tpIE]
							   , 0, 0, CASE xRegApur WHEN 'SIMPLES NACIONAL' THEN 1 WHEN 'SIMPLES NACIONAL - MEI' THEN 2 WHEN 'NORMAL - REGIME PERIÓDICO DE APURAÇÃO' THEN 9 END AS [regTrib]
							   , [UFEnder], [CNAE], [dIniAtiv]
							   , [dBaixa], [end_cMun], [end_xLgr], [end_nro], [end_xCpl], [end_xBairro], [end_CEP]
							   , [cSitCADESP], [IEUnica], [IEAtual], [indAtua], [indAtuaEndereco]
							   , @Agora, @NSUInc, @Agora, ISNULL(@NSUAtu, @NSUInc), @dhResp
							FROM @ContribuintesAtualizados

					-- insert para DW só se for inserção de novo registro
					INSERT INTO [DW].[Queue] (NSUInc, NSUATu, timestampReg)
					VALUES (@NSUInc, @NSUAtu, @Agora)
				END
			END			
		COMMIT
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT > 0)
		BEGIN
			ROLLBACK
		END;

		DECLARE @lMsgErro varchar(1024)
		SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
						+ ' Error=['    + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
						+ ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
						+ ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
						+ ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
						+ ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
						+ ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
		THROW 50050, @lMsgErro, 1;
	END CATCH
END
GO
PRINT N'Refreshing [cccEnvio].[usp_CCC_Contribuinte_Atualizacoes_Queue_Insert]...';


GO
EXECUTE sp_refreshsqlmodule N'[cccEnvio].[usp_CCC_Contribuinte_Atualizacoes_Queue_Insert]';


GO
PRINT N'Refreshing [cccRecebimento].[usp_CCC_Contribuinte_Insert]...';


GO
EXECUTE sp_refreshsqlmodule N'[cccRecebimento].[usp_CCC_Contribuinte_Insert]';


GO
PRINT N'Refreshing [cccRecebimento].[usp_CCC_Obter_FilaFaltantes_Queue]...';


GO
EXECUTE sp_refreshsqlmodule N'[cccRecebimento].[usp_CCC_Obter_FilaFaltantes_Queue]';


--GO
--PRINT N'Refreshing [DW].[usp_CCC_select]...';


--GO
--EXECUTE sp_refreshsqlmodule N'[DW].[usp_CCC_select]';


GO
PRINT N'Refreshing [NFe].[usp_ConsultaCNPJ]...';


GO
EXECUTE sp_refreshsqlmodule N'[NFe].[usp_ConsultaCNPJ]';


GO
PRINT N'Update complete.';


GO
