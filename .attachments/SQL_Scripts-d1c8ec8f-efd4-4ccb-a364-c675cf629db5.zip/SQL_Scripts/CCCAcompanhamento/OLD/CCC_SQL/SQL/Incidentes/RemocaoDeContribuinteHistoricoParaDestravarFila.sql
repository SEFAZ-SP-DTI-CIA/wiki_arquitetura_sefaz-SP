USE CCC
GO

DELETE 
FROM CCC.ContribuinteHistorico
WHERE pkey = 12078946