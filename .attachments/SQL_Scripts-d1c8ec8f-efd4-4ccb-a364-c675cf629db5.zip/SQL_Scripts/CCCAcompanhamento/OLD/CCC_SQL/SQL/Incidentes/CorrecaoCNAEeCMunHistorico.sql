USE CCC
GO

CREATE TABLE ##DadosContribuinteUpdateCnaeCMun
(
    pKey        BIGINT      NOT NULL,
    NSUCCC      BIGINT      NOT NULL,
    NSUCCCMovto BIGINT      NOT NULL,
    codCNAE     INT         NOT NULL,
    valorCNAE   VARCHAR(10) NULL, -- tabela CADESP
    codMun      INT         NOT NULL,
    valorMun    INT         NULL, -- tabela CADESP
    PRIMARY KEY(pKey, NSUCCC, NSUCCCMovto)
)

INSERT INTO ##DadosContribuinteUpdateCnaeCMun (pKey, NSUCCC, NSUCCCMovto, codCNAE, codMun)
    SELECT ct.pKey, ct.NSUCCC, ct.NSUCCCMovto, ct.CNAE, ct.cMun
    FROM [CCC].[ContribuinteHistorico] AS ct (NOLOCK)
    WHERE ct.cuf = 35
      AND (LEN(ct.cMun)<=4 OR LEN(ct.CNAE)<=5)

UPDATE t
    SET t.valorCNAE = cnae.CD_CNAE_FISCAL, t.valorMun = mu.CD_MUNICIPIO_IBGE
    FROM ##DadosContribuinteUpdateCnaeCMun AS t

    INNER JOIN [CADESP].[dbo].[TB_DOM_CNAE_FISCAL] cnae (NOLOCK)
    ON t.codCNAE = cnae.ID_CNAE_FISCAL

    INNER JOIN [CADESP].[dbo].[TB_DOM_MUNICIPIO] mu (NOLOCK)
    ON t.codMun = mu.ID_MUNICIPIO
/*
SELECT COUNT(1) FROM ##DadosContribuinteUpdateCnaeCMun (NOLOCK)

SELECT * FROM ##DadosContribuinteUpdateCnaeCMun (NOLOCK) 

SELECT TOP 100 *
FROM ##DadosContribuinteUpdateCnaeCMun
WHERE ##DadosContribuinteUpdateCnaeCMun.valorMun IS NULL
OR ##DadosContribuinteUpdateCnaeCMun.valorCNAE IS NULL

--TRUNCATE TABLE ##DadosContribuinteUpdateCnaeCMun
-- DROP TABLE ##DadosContribuinteUpdateCnaeCMun
*/

CREATE TABLE #UpdateIteracao
(
    pKey        BIGINT      NOT NULL,
    NSUCCC      BIGINT      NOT NULL,
    NSUCCCMovto BIGINT      NOT NULL,
    codCNAE     INT         NOT NULL,
    valorCNAE   VARCHAR(10) NULL, -- tabela CADESP
    codMun      INT         NOT NULL,
    valorMun    INT         NULL, -- tabela CADESP
    PRIMARY KEY(pKey, NSUCCC, NSUCCCMovto)
)

WHILE EXISTS (SELECT TOP 1 pKey FROM ##DadosContribuinteUpdateCnaeCMun)
BEGIN
    
    TRUNCATE TABLE #UpdateIteracao

    BEGIN TRAN

        DELETE TOP (1000)
        FROM ##DadosContribuinteUpdateCnaeCMun
        OUTPUT deleted.* INTO #UpdateIteracao
 
        UPDATE ct
        SET ct.CNAE = u.valorCNAE,
            ct.cMun = u.valorMun
        FROM [ccc].[ContribuinteHistorico] AS ct (NOLOCK)
        INNER JOIN #UpdateIteracao AS u
        ON ct.pKey = u.pKey
         AND ct.NSUCCC      = u.NSUCCC
         AND ct.NSUCCCMovto = u.NSUCCCMovto
         AND ct.CNAE = u.codCNAE
         AND ct.cMun = u.codMun
 
    COMMIT TRAN
END
