SELECT count(1)
FROM ccc.Contribuinte c 
where cuf = 35  
  and LEN(cMun)=4

SELECT count(1)
FROM ccc.Contribuinte c 
where cuf = 35 

SELECT count(1)
FROM ccc.Contribuinte c 
where cuf = 35  
  and LEN(cMun)=4
  and dAtu < '2017-03-14 12:00:00.000'

SELECT top 10 datu, CNAE, cMun, *
FROM ccc.Contribuinte c (NOLOCK)
where cuf = 35  
  and LEN(cMun)=4
  and dAtu < '2017-03-14 12:00:00.000'


SELECT top 10 datu, CNAE, cMun, *
FROM ccc.Contribuinte c (NOLOCK)
where cuf = 35  
  and LEN(cMun)=4
  and dAtu < '2017-03-14 12:00:00.000'
order by c.datu desc

SELECT top 10 datu, CNAE, cMun, *
FROM ccc.Contribuinte c (NOLOCK)
where cuf = 35  
  and LEN(cMun)=4
  and dAtu < '2017-03-14 12:00:00.000'
order by c.datu asc


SELECT datu, CNAE, cMun, *
FROM ccc.Contribuinte c (NOLOCK)
where cuf = 35 
  and dAtu > '2017-03-13' and dAtu < '2017-03-14 12:00:00.000'
  and LEN(cMun)=4
order by c.dAtu desc