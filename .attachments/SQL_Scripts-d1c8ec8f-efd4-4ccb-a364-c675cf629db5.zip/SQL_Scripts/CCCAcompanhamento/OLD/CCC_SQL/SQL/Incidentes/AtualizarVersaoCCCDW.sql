USE [ETL_NFE]
GO

--SELECT * 
--FROM [DWCCC].[ConfigSistema]
--WHERE parametro = 'VERSOES_A_SEREM_EXTRAIDAS'

UPDATE [DWCCC].[ConfigSistema]
SET valor = '2.00'
WHERE parametro = 'VERSOES_A_SEREM_EXTRAIDAS'
