USE CCC
GO

SET IDENTITY_INSERT [DW].[Queue] ON
GO

DELETE FROM [ETL_NFE].[DWCCC].[ResultadoProcessamento]
OUTPUT
    DELETED.pKey, 
    DELETED.NSUInc,
    DELETED.NSUAtu,
    DELETED.timestampReg
INTO 
    CCC.DW.QUEUE
    (pKey, NSUInc, NSUAtu, timestampReg)
WHERE dataProcessamento >= '2017-07-15 00:00:00.000'
  AND dataProcessamento <  '2017-07-16 00:00:00.000'

SET IDENTITY_INSERT [DW].[Queue] OFF
GO
