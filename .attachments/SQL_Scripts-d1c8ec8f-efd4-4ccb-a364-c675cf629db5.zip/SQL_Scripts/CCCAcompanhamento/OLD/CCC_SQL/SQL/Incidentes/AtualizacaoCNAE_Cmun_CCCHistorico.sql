USE CCC
GO

CREATE TABLE #UpdateIteracao
(
    pKey        BIGINT      NOT NULL,
    NSUCCC      BIGINT      NOT NULL,
    NSUCCCMovto BIGINT      NOT NULL,
    codCNAE     INT         NOT NULL,
    valorCNAE   VARCHAR(10) NULL, -- tabela CADESP
    codMun      INT         NOT NULL,
    valorMun    INT         NULL, -- tabela CADESP
    PRIMARY KEY(pKey, NSUCCC, NSUCCCMovto)
)

WHILE EXISTS (SELECT TOP 1 pKey FROM ##DadosContribuinteUpdateCnaeCMun)
BEGIN
    
    TRUNCATE TABLE #UpdateIteracao

    BEGIN TRAN

        DELETE TOP (1000)
        FROM ##DadosContribuinteUpdateCnaeCMun
        OUTPUT deleted.* INTO #UpdateIteracao
 
        UPDATE ct
        SET ct.CNAE = u.valorCNAE,
            ct.cMun = u.valorMun
        FROM [ccc].[ContribuinteHistorico] AS ct (NOLOCK)
        INNER JOIN #UpdateIteracao AS u
        ON ct.pKey = u.pKey
         AND ct.NSUCCC      = u.NSUCCC
         AND ct.NSUCCCMovto = u.NSUCCCMovto
         AND ct.CNAE = u.codCNAE
         AND ct.cMun = u.codMun
 
    COMMIT TRAN
END