USE CCC
GO

CREATE TABLE #UpdateIteracao
(
    pKey      BIGINT      NOT NULL,
    InscMF    BIGINT      NOT NULL,
    CNPJ      VARCHAR(14) NOT NULL,
    codCNAE   INT         NOT NULL,
    valorCNAE VARCHAR(10) NULL, -- tabela CADESP
    codMun    INT         NOT NULL,
    valorMun  INT         NULL, -- tabela CADESP
    PRIMARY KEY(pKey)
)

WHILE EXISTS (SELECT TOP 1 pKey FROM ##DadosContribuinteUpdateCnaeCMun)
BEGIN
    
    TRUNCATE TABLE #UpdateIteracao

    BEGIN TRAN

        DELETE TOP (1000)
        FROM ##DadosContribuinteUpdateCnaeCMun
        OUTPUT deleted.* INTO #UpdateIteracao
 
        UPDATE ct
        SET ct.CNAE = u.valorCNAE,
            ct.cMun = u.valorMun
        FROM ccc.Contribuinte AS ct (NOLOCK)
        INNER JOIN #UpdateIteracao AS u
        ON ct.pKey = u.pKey
         AND ct.CNAE = u.codCNAE
         AND ct.cMun = u.codMun
 
    COMMIT TRAN
END
