USE [ETL_NFE]
GO

UPDATE [DWCCC].[ConfigSistema]
SET valor = 'true'
where parametro = 'EXECUTAR_AGORA'

SELECT * 
FROM [DWCCC].[ConfigSistema]
where parametro = 'EXECUTAR_AGORA'