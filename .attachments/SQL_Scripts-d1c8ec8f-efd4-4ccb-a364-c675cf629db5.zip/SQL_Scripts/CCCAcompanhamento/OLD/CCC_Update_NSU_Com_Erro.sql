update [CCC].[CCC].[Configuracao]
set valor = 'true'
where pkey = 35

update [CCC].[CCC].[Configuracao]
set valor = '751443'
where pkey = 54
