-- Incidentes Relacionados a essa ocorr�ncia:
-- INC000001763661 INC000001766285 INC000001767959 INC000001774608
 
select * 
from pgsf.fiscal 
where num_fiscal = 171235 like '%PUPO%'
--171235

select *
from pgsf.OUTRAS_ATIVIDADES 
WHERE NUM_FISCAL = 171235
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO >= to_date('16/11/2016', 'dd/mm/yyyy')
AND DTC_EXECUCAO <= to_date('30/11/2016', 'dd/mm/yyyy');

select *
from pgsf.OUTRAS_ATIVIDADES 
WHERE NUM_FISCAL = 319627
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO = to_date('31/10/2016', 'dd/mm/yyyy')
;

select *
from pgsf.OUTRAS_ATIVIDADES 
WHERE NUM_FISCAL = 57694
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO = to_date('07/10/2016', 'dd/mm/yyyy')
;


delete outras_atividades WHERE NUM_FISCAL = 59496 AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO >= to_date('14/11/2016', 'dd/mm/yyyy')
AND DTC_EXECUCAO <= to_date('28/11/2016', 'dd/mm/yyyy');

DELETE OUTRAS_ATIVIDADES 
WHERE NUM_FISCAL = 59496 
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO >= to_date('14/11/2016', 'dd/mm/yyyy')
AND DTC_EXECUCAO <= to_date('28/11/2016', 'dd/mm/yyyy');

COMMIT;

DELETE OUTRAS_ATIVIDADES 
WHERE NUM_FISCAL = 319627
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO = to_date('31/10/2016', 'dd/mm/yyyy');

COMMIT;

DELETE OUTRAS_ATIVIDADES 
WHERE NUM_FISCAL = 171235
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO >= to_date('16/11/2016', 'dd/mm/yyyy')
AND DTC_EXECUCAO <= to_date('30/11/2016', 'dd/mm/yyyy');

COMMIT;

-- INC000001765977
select * from pgsf.
select * from pgsf.outras_atividades


where nom_fiscal like '%VARELA%'
--num_fiscal = 94599
select * from pgsf.tb_pontuacao
where id_pontuacao = 436


select * 
from OUTRAS_ATIVIDADES




WHERE NUM_FISCAL = 94599 
AND ID_PONTUACAO = 436 
AND DTC_EXECUCAO = to_date('31/10/2016', 'dd/mm/yyyy');

DELETE OUTRAS_ATIVIDADES WHERE NUM_FISCAL = 94599  AND ID_PONTUACAO = 436 AND DTC_EXECUCAO = to_date('31/10/2016', 'dd/mm/yyyy');




--alter trigger tr_dom_tipo_pontuacao_bi disable;
--insert into tb_dom_tipo_pontuacao values (173, 'Afastamento n�o relat�vel', to_date('25/03/2011', 'dd/mm/yyyy'), to_date('31/12/9999', 'dd/mm/yyyy'), 'mcavelino', sysdate, 0, 0);
--alter trigger tr_dom_tipo_pontuacao_bi enable;

--update tb_dom_tipo_pontuacao set des_tipo_pontuacao = 'Afastamento relat�vel' where id_tipo_pontuacao = 129;
--update tb_pontuacao set id_tipo_pontuacao = 173 where id_tipo_pontuacao = 129 and ds_pontuacao <> 'FALTA ABONADA';

select * 
from tb_pontuacao 
where id_tipo_pontuacao = 129
and ds_pontuacao <> 'FALTA ABONADA';

update tb_pontuacao set id_tipo_pontuacao = 129 where id_tipo_pontuacao = 173 and ds_pontuacao <> 'FALTA ABONADA';

select *
from tb_dom_tipo_pontuacao 
where des_tipo_pontuacao = 'Afastamento relat�vel'

select * 
from tb_dom_tipo_pontuacao 
where id_tipo_pontuacao = 173

-- TESTE
-- fiz o relato dos fiscais abaixo, da DRT-5 (Campinas), equipe 31, incluindo diversos tipos de afastamento nos relatos
-- enviei um por um ao RH usando proc USP_ENVIAR_RMAS

select *
from fiscal
where  nom_fiscal in
('ANTONIO CANDIDO',
'CARLOS ALBERTO DOS SANTOS',
'CLAUDIA MARQUES TAVARES DA SILVA',
'EDSON HURTADO CANDIDO',
'FABR�CIO TORRES DE SOUZA',
'MARCOS PEREIRA CHAGAS PIRES',
'MARIANA LIMA ALVES DE ALBUQUERQUE',
'MOACYR DOS SANTOS LOPES JUNIOR',
'NILTON YUGI TOKITA')
--56884
--93340
--321877
--68746
--320642
--85975
--93819
--95336
--88370

-- verificando que os relatos est�o na situa��o correta...
select *
from tb_relato_situacao
where
id_situacao_relato = 50 --enviado para o RH
and nr_mes = 10
and nr_ano = 2016
and nr_fiscal in
(56884
,93340
,321877
,68746
,320642
,85975
,93819
,95336
,88370)
--id_relato_situacao
--545718
--545719
--545721
--545720
--545722
--545723
--545726
--545724
--545725

-- procurando o RMA que foi gerado...
select *
from tb_rma
where 
nr_mes = 10
and nr_ano = 2016
and nr_fiscal in
(56884
,93340
,321877
,68746
,320642
,85975
,93819
,95336
,88370)
--id_rma:
--99697
--99700
--99702
--99705
--99698
--99703
--99704
--99701
--99699

--usando proc USP_ATUALIZAR_STATUS_RMA nos ids acima, mudando status para 60 (averbado)
-- verificado status averbado corretamente na interface

-- TESTE 2
-- relato de ANTONIO CANDIDO devolvido para corre��o
-- relato corrigido (altera��o de pontos) e enviado, aprovado, homologado


-- procurando o RMA que foi gerado...
select *
from tb_rma
where 
nr_mes = 10
and nr_ano = 2016
and nr_fiscal in
(56884
,93340
,321877
,68746
,320642
,85975
,93819
,95336
,88370)
--s�o os mesmos 

--procurando BC que foi gerado
select *
from tb_boletim_correcao
where 
nr_mes = 10
and nr_ano = 2016
and nr_fiscal = 56884
--id_bc = 8230

-- executada proc USP_ENVIAR_BCS para fiscal com BC (56884)
-- os demais RMAs ficaram j� averbados, porque estou testando em DEV (prod antiga, averba automaticamente se n�o h� altera��o de pontos)
-- executada proc USP_ATUALIZAR_STATUS_BC para BC 8234 para status 90 (BC averbado)

-- verificando quotas...
select nom_fiscal, qn_total_quotas, qn_total_pontos
from tb_rma
join fiscal 
on fiscal.num_fiscal = tb_rma.nr_fiscal
where 
nr_mes = 10
and nr_ano = 2016
and nr_fiscal in
(56884
,93340
,321877
,68746
,320642
,85975
,93819
,95336
,88370)
--ANTONIO CANDIDO	                  1620
--EDSON HURTADO CANDIDO	               0
--MARCOS PEREIRA CHAGAS PIRES	      1440
--NILTON YUGI TOKITA	              2700
--CARLOS ALBERTO DOS SANTOS	         540
--MARIANA LIMA ALVES DE ALBUQUERQUE	1710
--MOACYR DOS SANTOS LOPES JUNIOR	  1800
--FABR�CIO TORRES DE SOUZA	         540
--CLAUDIA MARQUES TAVARES DA SILVA	 630

--verificando se quotas est�o ok
select pa.ds_pontuacao, po.vl_ponto
from tb_pontos po
join tb_pontuacao pa
on po.id_pontuacao = pa.id_pontuacao
where pa.id_tipo_pontuacao = 129
order by pa.ds_pontuacao 
--pa.ds_pontuacao like '%SANGUE%'


