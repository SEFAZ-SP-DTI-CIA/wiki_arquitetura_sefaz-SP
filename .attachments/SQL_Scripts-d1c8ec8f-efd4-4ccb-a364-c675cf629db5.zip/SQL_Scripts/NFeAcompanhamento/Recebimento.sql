USE [NFe_Out_UFs]
GO

SELECT * 
  FROM [DB_NFEINTEGRA].[dbo].[ULTIMO_NSU_RECEBIMENTO] -- 5899917441

-- Fila do Recebimento e NSUFaltante, o problema é quando está grande
SELECT '' as '[dbo].[LOG_XML_QUEUE]', COUNT(1)
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
SELECT TOP 50 '' as '[dbo].[LOG_XML_QUEUE] - flag 0', *
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
 WHERE LOXM_FL_READ = 0
 ORDER BY LOXM_CD_XML ASC
SELECT TOP 50 '' as '[dbo].[LOG_XML_QUEUE] - flag 1', *
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
 WHERE LOXM_FL_READ = 1
 ORDER BY LOXM_CD_XML ASC

-- Log da Fila do Recebimento e NSUFaltante, o problema � quando tem entrada na coluna LOXM_TX_Erro
SELECT TOP 10 '' as '[dbo].[LOG_XML]', LOXM_CD_XML, LOXM_DT_Timestamp, CONVERT(XML, LOXM_TX_XML_Request) AS request, CONVERT(XML, LOXM_TX_XML_Response) AS response, *
  FROM [dbo].[LOG_XML] x (nolock)
 --WHERE LOXM_CD_XML in (132269954,132269954,132269953,132269953)
 ORDER by x.[LOXM_CD_XML] desc

SELECT TOP 10 '' as '[dbo].[LOG_XML] com erro',LOXM_CD_XML, LOXM_DT_Timestamp, CONVERT(XML, LOXM_TX_XML_Request) AS request, CONVERT(XML, LOXM_TX_XML_Response) AS response, *
  FROM [dbo].[LOG_XML] x (nolock)
 WHERE LOXM_TX_Erro IS NOT NULL
 ORDER by x.[LOXM_CD_XML] desc

SELECT TOP 5000 '' AS '[dbo].[REGISTROS_LOTE_ERRO]', *
  FROM [dbo].[REGISTROS_LOTE_ERRO] (nolock)
 ORDER BY pKey DESC

SELECT TOP 30 '' AS '[dbo].[REGISTROS_LOTE_ERRO]_Incomuns', *
  FROM [dbo].[REGISTROS_LOTE_ERRO] (nolock)
 WHERE erro NOT LIKE '125 NSU consultado nao existe no Ambiente Nacional%'
   and erro NOT LIKE 'Tipo de Evento: 410300 ainda não implementado!'
   and erro NOT LIKE 'Inutilizacao só pode ser tratada em Contingência ou SEFAZ Virtual.'
   and erro NOT LIKE 'Número de protocolo não suportado na recepção de Emissão: %'
 ORDER BY pKey DESC

DECLARE @DataProtocoloMaisRecente DATETIME = (SELECT top 1 timestampReg
                                                FROM [dbo].[ProtocoloNFe] p (NOLOCK)
                                               WHERE $Partition.PF_Part_01_Data_2(p.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())   
                                               ORDER BY p.nsu DESC)
SELECT @DataProtocoloMaisRecente as 'Data Protocolo OUT-UFs mais recente'
DECLARE @diffMinutos FLOAT = DATEDIFF(MINUTE, @DataProtocoloMaisRecente, GETDATE());
SELECT  @diffMinutos             as 'Minutos entre o dado mais antigo recebido e agora', 
        @diffMinutos / 60        as 'Horas entre o dado mais antigo recebido e agora',
        @diffMinutos / (24 * 60) as 'Dias entre o dado mais antigo recebido e agora'

RETURN 

-- ====== Últimos registros recebidos Out_UFs ======
USE [NFe_Out_UFs]
GO

-- Todos
SELECT TOP 1000 '' AS '[dbo].[IntegraNSU]', i.*
  FROM     [dbo].[IntegraNSU] i (NOLOCK)
WHERE $Partition.PF_Part_01_Data(i.timestampRecebimento) = $Partition.PF_Part_01_Data(GETDATE())
ORDER BY i.nsuBusca DESC

-- Emissão
DECLARE @maxNsu BIGINT = (SELECT MAX(nsu)
                            FROM [NFe_Out_UFs].[dbo].[IntegraNSU] p (nolock)
                           WHERE [NFe_Out_UFs].$partition.PF_Part_01_Data(timestampRecebimento) = [NFe_Out_UFs].$partition.PF_Part_01_Data(GETDATE()))
SELECT TOP 10 '' AS '[dbo].[IntegraNSU]/[ProtocoloNFe]/[NFe]', i.*, p.*, n.* 
  FROM     [dbo].[IntegraNSU] i (NOLOCK)
 INNER JOIN [dbo].[ProtocoloNFe] p (NOLOCK)
    ON i.nsu = p.nsu
 INNER JOIN [dbo].[NFe] n (NOLOCK)
    ON i.nsu = n.nsu
 WHERE $Partition.PF_Part_01_Data  (i.timestampRecebimento) = $Partition.PF_Part_01_Data  (GETDATE())
   AND $Partition.PF_Part_01_Data_2(p.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())
   AND $Partition.PF_Part_01_Data_2(n.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())
   --AND i.nsu > @maxNsu - 1000
 ORDER BY i.nsu DESC

-- Eventos
SELECT TOP 10 '' AS '[dbo].[IntegraNSU] / [NFeEventos].[IntegraEvento] / [NFeEventos].[Evento]', i.*, iev.*, ev.* 
  FROM     [dbo].[IntegraNSU] i (NOLOCK)
INNER JOIN [NFeEventos].[IntegraEvento] iev (NOLOCK)
        ON i.nsu = iev.nsu
INNER JOIN [NFeEventos].[Evento] ev (NOLOCK)
        ON iev.pkeyEvento = ev.pKey 
WHERE $Partition.PF_Part_01_Data(i.timestampRecebimento) = $Partition.PF_Part_01_Data(GETDATE())
ORDER BY i.nsu DESC

-- ====== Ultimos registros recebidos SCAN ======
USE [NFe_Out]
GO

DECLARE @maxPKey BIGINT = IDENT_CURRENT('NFeOut.Protocolo')    
SELECT pkey
  INTO #ULTIMOS_PROTOCOLOS
  FROM [NFeOut].[Protocolo] p (NOLOCK)
 WHERE $partition.[PF_Part_02_Data](p.timestampReg) = $partition.[PF_Part_02_Data](GETDATE())
   AND p.pKey BETWEEN (@maxPKey - 10000) AND @maxPKey
 ORDER BY pkey DESC

SELECT top 10000 i.* 
  FROM #ULTIMOS_PROTOCOLOS p
 INNER JOIN [NFeIntegra].[IntegraNSU] i
    ON p.pKey = i.fkProtocolo
 WHERE i.fkIntegraTipo <> 1
 ORDER BY nsu DESC

DROP TABLE #ULTIMOS_PROTOCOLOS

RETURN 

---------------------------------------------------------

-- Pesquisa de determinado NSU para ver se � OUT-UFs ou OUT
DECLARE @nsuBase BIGINT = 259124819

SELECT *
  FROM [NFe_Out_UFs].[dbo].[IntegraNSU] (nolock)
  where nsuBusca = @nsuBase

SELECT *
  FROM [NFe_Out].[NFeIntegra].[IntegraNSU] (nolock)
  where nsuAutorizacaoBusca = @nsuBase

-- Pesquisa de determinado documento em Out_UFs
SELECT * 
 FROM [NFe_Out_UFs].[dbo].[ProtocoloNFe] p (nolock)
INNER JOIN [NFe_Out_UFs].[dbo].[DFe_XML] x (nolock)
   ON p.nsu = x.nsu
WHERE p.nsu = 21526473019

-- Autorização em contingência
SELECT TOP 10 *
FROM       [NFe_Out].[NFeOut].[Protocolo] p (nolock)
INNER JOIN [NFe_Out].[NFeOut].[NFe]       n (nolock)
   ON p.pKey = n.pKey
INNER JOIN [NFe_Out].[NFeOut].[NFe_Constraint] c (nolock)
   ON p.pKey = c.fkProtocolo
INNER JOIN [DFe_XML].[NFe].[NFeXML] x (nolock)
   ON p.pKey = x.pKey
INNER JOIN [DFe_XML].[NFe].[NFeProtRelacionamento] re (nolock)
   ON p.pKey = re.pKey
INNER JOIN [NFe_Out].[NFeOut].[InfoContingencia] ic (nolock)
   ON p.pKey = ic.fkProtocolo
INNER JOIN [NFe_Out].NFeEventos.[DadosApoio] da (nolock)
   ON p.pKey = da.pKey
INNER JOIN [NFe_Out].NFeIntegra.[IntegraNSU] iu (nolock)
   ON ic.nsu = iu.nsu
LEFT JOIN  [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt (nolock)
  ON p.pKey = dt.pkey
where iu.nsu = 28973698699

-- Inutilização em contingência
SELECT TOP 2 *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](x.InutNFe)) as unitXML
FROM       [NFe_Out].[NFeOut].[Protocolo]           p  (nolock)
LEFT JOIN [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt (nolock)
   ON p.pKey = dt.pKey
INNER JOIN [NFe_Out].[NFeOut].[NFe_Constraint] nc (nolock)
   ON p.pKey = nc.fkProtocolo
INNER JOIN [NFe_Out].[NFeOut].[InutNFe] inut (nolock)
   ON p.pKey = inut.pKey
 LEFT JOIN [NFe_Out].[NFeOut].[InfoContingencia] ic (nolock)
   ON p.pKey = ic.fkProtocolo
INNER JOIN [NFe_Out].[NFeIntegra].[IntegraNSU]  iu (nolock) -- (fkIntegraTipo=3)
   ON p.pKey = iu.fkProtocolo
INNER JOIN [DFe_XML].[NFe].InutNFeXML x (nolock)
   ON p.pkey = x.pKey
where p.pKey = 20359225

-- Recebimento Evento em contingência
SELECT top 10 * , CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](x.Evento)) as ev1, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](ix.xmlEvento)) as ev2
      FROM [NFe_Out].[NFeOut].[Protocolo]           p (nolock)
LEFT JOIN [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt (nolock)
  ON p.pKey = dt.pkey
INNER JOIN [NFe_Out].[NFeEventos].[Evento_Constraint] ec (nolock)
  ON p.pKey = ec.fkProtocolo
INNER JOIN [NFe_Out].[NFeEventos].[Evento] e (nolock)
  ON p.pKey = e.pKey
INNER JOIN [DFe_XML].[NFe].[EventoXML] x (nolock)
  ON p.pKey = x.pKey
LEFT JOIN [NFe_Out].[NFeIntegra].[IntegraNSU] n (nolock)
  ON p.pKey = n.fkProtocolo
INNER JOIN [NFe_Out].[NFeIntegra].[IntegraEvento] ie (nolock)
  ON p.pKey = ie.pkeyEvento
INNER JOIN [DFe_XML].[NFe].[IntegraEventoXml] ix (nolock)
  ON ie.nsu = ix.nsu
where n.nsu = 29291552151

-- Recebimento Evento EPEC em contingência
SELECT top 10 * 
      FROM [NFe_Out].[NFeOut].[Protocolo]           p  (nolock)
LEFT JOIN [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt  (nolock)
  ON p.pKey = dt.pkey
INNER JOIN [NFe_Out].[NFeEventos].[Evento_Constraint] ec (nolock)
  ON p.pKey = ec.fkProtocolo
INNER JOIN [NFe_Out].[NFeEventos].[Evento] e (nolock)
  ON p.pKey = e.pKey
INNER JOIN [DFe_XML].[NFe].[EventoXML] x (nolock)
  ON p.pKey = x.pKey
LEFT JOIN [NFe_Out].[NFeIntegra].[IntegraNSU] n (nolock)
  ON p.pKey = n.fkProtocolo
INNER JOIN [NFe_Out].[NFeIntegra].[IntegraEvento] ie (nolock)
  ON p.pKey = ie.pkeyEvento
INNER JOIN [DFe_XML].[NFe].[IntegraEventoXml] ix (nolock)
  ON ie.nsu = ix.nsu
INNER JOIN [NFe_Out].[NFeEventos].[EventoEPEC] ee (nolock)
  ON p.pKey = ee.pKey
where ie.nsu = 20359225

-- Recebimento Evento Cancelamento em contingência
SELECT top 10 * 
      FROM [NFe_Out].[NFeOut].[Protocolo]           p (nolock)
LEFT JOIN [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt (nolock)
  ON p.pKey = dt.pkey
INNER JOIN [NFe_Out].[NFeEventos].[Evento_Constraint] ec (nolock)
  ON p.pKey = ec.fkProtocolo
INNER JOIN [NFe_Out].[NFeEventos].[Evento] e (nolock)
  ON p.pKey = e.pKey
INNER JOIN [DFe_XML].[NFe].[EventoXML] x (nolock)
  ON p.pKey = x.pKey
LEFT JOIN [NFe_Out].[NFeIntegra].[IntegraNSU] n (nolock)
  ON p.pKey = n.fkProtocolo
INNER JOIN [NFe_Out].[NFeIntegra].[IntegraEvento] ie (nolock)
  ON p.pKey = ie.pkeyEvento
INNER JOIN [DFe_XML].[NFe].[IntegraEventoXml] ix (nolock)
  ON ie.nsu = ix.nsu
INNER JOIN [NFe_Out].[NFeEventos].[Cancelamento] ca (nolock)
  ON p.pKey = ca.pKey
where ie.nsu = 20359225

-- Recebimento Cancelamento (antigo) em contingência
SELECT TOP 1 *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](cxml.CancNFe)) as cancXML
FROM       [NFe_Out].[NFeOut].[Protocolo]   p (nolock)
LEFT JOIN [NFe_Out].[NFeOut].[NFe_Constraint] nc (nolock)
   ON p.pKey = nc.fkProtocolo
INNER JOIN [NFe_Out].[NFeOut].[CancNFe] c (nolock)
   ON p.pKey = c.pKey
LEFT JOIN [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt (nolock)
   ON p.pKey = dt.pKey
LEFT JOIN [NFe_Out].[NFeEventos].[Evento_Constraint] ec (nolock)
   ON p.pKey = ec.fkProtocolo
LEFT JOIN [NFe_Out].[NFeOut].[InfoContingencia] ic (nolock)
   ON p.pKey = ic.fkProtocolo
INNER JOIN [NFe_Out].[NFeIntegra].[IntegraNSU] iu (nolock)   --  (fkIntegraTipo=3)
   ON p.pKey = iu.fkProtocolo
INNER JOIN [DFe_XML].[NFe].[CancNFeXML] cxml (nolock)
   ON p.pKey = cxml.pKey
WHERE p.pkey = 2442329161 -- 1776334644

-- Autorização de Outras UFs
SELECT TOP 10 dt.*, n.*, x.*, i.*, pf.*, ic.*, CONVERT(XML, x.DFe)
--SELECT TOP 10 n.*, x.*, i.*, pfl.*, dt.*, ic.*
FROM       [NFe_Out_UFs].[dbo].[DFe_XML] x (nolock)
INNER JOIN [NFe_Out_UFs].[dbo].[NFe]     n (nolock) 
  ON x.nsu = n.nsu
LEFT JOIN [NFe_Out_UFs].[dbo].[IntegraNSU] i (nolock)
  ON x.nsu = i.nsu
LEFT JOIN [NFe_Out_UFs].[dbo].[ProtocoloNFe] pf (nolock)
  ON x.nsu = pf.nsu
LEFT JOIN [NFe_Out_UFs].[dbo].[ProtocoloNFeLog] pfl (nolock)
  ON x.nsu = pfl.nsu
LEFT JOIN [NFe_Out_UFs].[dbo].[DadosTransmissao_AN] dt (nolock)
  ON x.nsu = dt.nsu
INNER JOIN [NFe_Out_UFs].[NFeUFs].[DFeInfoCompl] ic (nolock)
  ON x.nsu = ic.nsu
where x.nsu = 272463037

-- Eventos genéricos de Outras UFs
SELECT TOP 10 * 
FROM       [NFe_Out_UFs].[NFeEventos].[Evento]        e  (nolock)
INNER JOIN [NFe_Out_UFs].[NFeEventos].[IntegraEvento] ie (nolock)
  ON e.pKey = ie.pkeyEvento
LEFT  JOIN [NFe_Out_UFs].[dbo].[IntegraNSU] iu (nolock)
  ON ie.nsu = iu.nsu
LEFT JOIN  [NFe_Out_UFs].[dbo].[DadosTransmissao_AN] dt (nolock)
  ON iu.nsu = dt.nsu
where iu.nsu = 272460658

-- Eventos CCe de Outras UFs
SELECT TOP 10 * 
FROM       [NFe_Out_UFs].[NFeEventos].[Evento]         e (nolock)
INNER JOIN [NFe_Out_UFs].[NFeEventos].[IntegraEvento] ie (nolock)
  ON e.pKey = ie.pkeyEvento
LEFT  JOIN [NFe_Out_UFs].[dbo].[IntegraNSU] iu (nolock)
  ON ie.nsu = iu.nsu
LEFT JOIN  [NFe_Out_UFs].[dbo].[DadosTransmissao_AN] dt (nolock)
  ON iu.nsu = dt.nsu
INNER JOIN [NFe_Out_UFs].[NFeEventos].[CCeNFe] cc (nolock)
  ON e.pKey = cc.pKeyEvento
where iu.nsu = 26987106290

-- Eventos Cancelamento de Outras UFs
SELECT TOP 10 * 
FROM       [NFe_Out_UFs].[NFeEventos].[Evento]         e (nolock)
INNER JOIN [NFe_Out_UFs].[NFeEventos].[IntegraEvento] ie (nolock)
  ON e.pKey = ie.pkeyEvento
LEFT  JOIN [NFe_Out_UFs].[dbo].[IntegraNSU] iu (nolock)
  ON ie.nsu = iu.nsu
LEFT JOIN  [NFe_Out_UFs].[dbo].[DadosTransmissao_AN] dt (nolock)
  ON iu.nsu = dt.nsu
INNER JOIN [NFe_Out_UFs].[NFeEventos].[Cancelamento] ca (nolock)
  ON e.pKey = ca.pKeyEvento
where iu.nsu = 219243412

-- Análise do cStat 303

-- Últimos recebidos corretamente
SELECT TOP 10 '' AS '[dbo].[IntegraNSU] / [dbo].[ProtocoloNFe]', i.*, p.* 
  FROM     [NFe_Out_UFs].[dbo].[IntegraNSU]   i (NOLOCK)
INNER JOIN [NFe_Out_UFs].[dbo].[ProtocoloNFe] p (NOLOCK)
  ON i.nsu = p.nsu
WHERE [NFe_Out_UFs].$Partition.PF_Part_01_Data(i.timestampRecebimento) = [NFe_Out_UFs].$Partition.PF_Part_01_Data(GETDATE())
  AND [NFe_Out_UFs].$Partition.PF_Part_01_Data(p.timestampRecebimento) = [NFe_Out_UFs].$Partition.PF_Part_01_Data(GETDATE())
  and status = 303
ORDER BY i.timestampRecebimento DESC

-- �ltimos recebidos corretamente - com melhoria para rodar em produ��o (para procurar apenas em documentos mais recentes, a partir de 14/10/2017, e s� na ProtocoloNFe)
SELECT TOP 10 '' AS '[dbo].[ProtocoloNFe]', p.* 
  FROM [NFe_Out_UFs].[dbo].[ProtocoloNFe] p (NOLOCK)
 WHERE status = 303
   AND p.nsu > 24294854648
 ORDER BY p.timestampRecebimento DESC

-- Ultimos recebidos como erro
SELECT TOP 4 '' AS '[dbo].[REGISTROS_LOTE_ERRO]', *
  FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] (nolock)
 WHERE erro like '%cStat: 303%'
 ORDER BY pKey DESC

-- Eventos de Alerta de Irregularidade Fiscal rejeitados, produção temos 400104, 400120 / homologação = 400100, 400200, 400201, 
SELECT *
  FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] (nolock)
 --WHERE pkey > 37489452 -- pkey de produção a partir de 2017
 --WHERE pkey > 38206428 -- pkey de produção a partir de 2018
   WHERE pkey > 53997026 -- pkey de produção a partir de 10/2018
 --WHERE pkey > 328934980 -- pkey de homologação a partir de 2017
 --WHERE pkey > 329143723 -- pkey de homologação a partir de 2018
   AND (   erro like 'Tipo de Evento: 400%'
        or erro like 'Tipo de Evento: 500%')
  ORDER BY pkey DESC
--SELECT *, CONVERT(XML, LOXM_TX_XML_Response) as Resp
--FROM [NFe_Out_UFs].[dbo].[LOG_XML] where LOXM_CD_XML in (131778276, 137409491)

-- Eventos de Alerta de Irregularidade Fiscal recebidos
-- OUT UFS
SELECT TOP 10 * 
  FROM [NFe_Out_UFs].[NFeEventos].[Evento] (nolock)
 WHERE tpEvento in (400101, 400104, 400105, 400120, 400121, 500100, 500101, 500104, 500105, 400100, 400200, 400201)
-- OUT
SELECT TOP 20 * 
  FROM [NFe_Out].[NFeEventos].[Evento_Constraint] (nolock)
 WHERE tpEvento in (400101, 400104, 400105, 400120, 400121, 500100, 500101, 500104, 500105, 400100, 400200, 400201)

-- Eventos MDF-e - BT2017.002
SELECT tpEvento, count(tpEvento)
  FROM [NFe_Out_UFs].[NFeEventos].[Evento] (nolock)
 --WHERE tpEvento in (610510, 610511, 610514, 610515, 610550, 610552, 610554, 610610, 610611, 610614, 610615, 610500, 610501 ) -- TODOS
 WHERE tpEvento in (610510, 610511, 610514, 610515, 610552, 610554, 610614, 610615) -- Só os novos
 GROUP BY tpEvento

SELECT tpEvento, count(tpEvento)
  FROM [NFe_Out].[NFeEventos].[Evento_Constraint] (nolock)
--WHERE tpEvento in (610510, 610511, 610514, 610515, 610550, 610552, 610554, 610610, 610611, 610614, 610615, 610500, 610501 ) -- TODOS
 WHERE tpEvento in (610510, 610511, 610514, 610515, 610552, 610554, 610614, 610615) -- Só os novos
 GROUP BY tpEvento

-- Eventos Nota Fiscal Referenciada
SELECT tpEvento, count(tpEvento)
  FROM [NFe_Out_UFs].[NFeEventos].[Evento] (nolock)
 WHERE tpEvento = 410300
 GROUP BY tpEvento

SELECT tpEvento, count(tpEvento)
  FROM [NFe_Out].[NFeEventos].[Evento_Constraint] (nolock)
 WHERE tpEvento = 410300
 GROUP BY tpEvento

-- Análise de eventos não suportados

SELECT TOP 10 '' AS '[dbo].[REGISTROS_LOTE_ERRO]', *
  FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] (nolock)
 --WHERE pkey > 37489452 -- pkey de produção a partir de 2017
 --WHERE pkey > 38206428 -- pkey de produção a partir de 2018
 --WHERE pkey > 53997026 -- pkey de produção a partir de 10/2018
   WHERE pkey > 56001973 -- pkey de produção a partir de 2019
 --WHERE pkey > 328934980 -- pkey de homologação a partir de 2017
 --WHERE pkey > 329143723 -- pkey de homologação a partir de 2018
   AND erro like 'Tipo de Evento: %'
 ORDER BY pKey DESC
  
SELECT '' AS '[dbo].[REGISTROS_LOTE_ERRO]', erro, count(erro)
  FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] (nolock)
 --WHERE pkey > 37489452 -- pkey de produção a partir de 2017
 --WHERE pkey > 38206428 -- pkey de produção a partir de 2018
 --WHERE pkey > 53997026 -- pkey de produção a partir de 10/2018
   WHERE pkey > 56001973 -- pkey de produção a partir de 2019
 --WHERE pkey > 328934980 -- pkey de homologação a partir de 2017
 --WHERE pkey > 329143723 -- pkey de homologação a partir de 2018
   AND erro like 'Tipo de Evento: %'
 GROUP BY erro

-- Pegando o registro, baseado no loxm_cd_xml
DECLARE @loxm_cd_xml BIGINT = 154183687
SELECT *, CONVERT(XML, LOXM_TX_XML_Response) as Resp
  FROM [NFe_Out_UFs].[dbo].[LOG_XML] 
 WHERE LOXM_CD_XML = @loxm_cd_xml

-- ===========================================================
-- Relat�rio de recebimento Out-UFS
DECLARE @StartDate SMALLDATETIME = '2017-12-01 00:00:00'; -- CAST(getdate()-1 as smalldatetime);
DECLARE @EndDate   SMALLDATETIME = '2017-12-01 10:00:00'; -- CAST(getdate() as smalldatetime);

WITH cte AS
(
	SELECT @startdate DateValue
	UNION ALL
	SELECT DATEADD (MINUTE, 1, DateValue)
	FROM cte 
	WHERE DATEADD (MINUTE, 1, DateValue) < @enddate
)
SELECT c.DateValue as minuto, COUNT(i.nsu) AS protocolos
  FROM cte c
  LEFT JOIN [NFe_Out_UFs].[dbo].[IntegraNSU] i (NOLOCK)
    ON [NFe_Out_UFs].$partition.PF_Part_01_Data(i.timestampRecebimento) = [NFe_Out_UFs].$partition.PF_Part_01_Data(@EndDate)
    AND c.DateValue = cast(i.timestampRecebimento AS SMALLDATETIME)
 GROUP BY c.DateValue
 ORDER BY c.DateValue ASC
OPTION (MAXRECURSION 0, MAXDOP 4)

-- =============================================================
-- Verificação de notas emitidas por CPF
SELECT * --count(1)
  FROM [NFe_Out_UFs].[NFeUFs].[DFeInfoCompl]  (nolock)
 WHERE tipoIdEmit = 1

SELECT *
  FROM      [NFE_STAGING].[dbo].[DFeInfoCompl_NotasAvulsasMarcadasComEmitenteCPF_Agosto2018] s
 INNER JOIN [NFe_Out_UFs].[NFeUFs].[DFeInfoCompl] o
    ON s.nsu = o.nsu

    WHERE o.idEmit != substring(o.idNFe, 7, 14)

  --WHERE s.nsu    != o.nsu 
  --  or  s.idNFe  != o.idNFe
  --  or  s.serie  != o.serie
  --  or  s.numero != o.numero
  --  or  s.uf     != o.uf
  --  or  s.ano    != o.ano
  --  or  s.timestampRecebimento != o.timestampRecebimento

-- =============================================================
-- Relat�rio de recebimento SCAN - MUITO LERDO, n�o tem �ndice por timestampIntegra

--DECLARE @StartDate SMALLDATETIME = '2017-12-01 00:00:00'; -- CAST(getdate()-1 as smalldatetime);
--DECLARE @EndDate   SMALLDATETIME = '2017-12-01 10:00:00'; -- CAST(getdate() as smalldatetime);

--;WITH cte AS
--(
--	SELECT @startdate DateValue
--	UNION ALL
--	SELECT DATEADD (MINUTE, 1, DateValue)
--	FROM cte 
--	WHERE DATEADD (MINUTE, 1, DateValue) < @enddate
--)
--SELECT c.DateValue as minuto, COUNT(i.nsu) AS protocolos
--  FROM cte c
--  LEFT JOIN [NFe_Out].[NFeIntegra].[IntegraNSU] i (NOLOCK)
--    ON [NFe_Out].$partition.PF_Part_02_Data(i.timestampIntegra) = [NFe_Out].$partition.PF_Part_02_Data(@EndDate)
--    AND c.DateValue = cast(i.timestampIntegra AS SMALLDATETIME)
-- GROUP BY c.DateValue
-- ORDER BY c.DateValue ASC
--OPTION (MAXRECURSION 0, MAXDOP 4)





