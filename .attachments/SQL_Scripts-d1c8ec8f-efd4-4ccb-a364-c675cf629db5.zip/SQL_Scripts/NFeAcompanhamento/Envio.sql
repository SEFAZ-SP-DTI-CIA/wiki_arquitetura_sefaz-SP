USE DB_NFeIntegra
GO 

-- Autoriza��o/inutiliza��o/cancelamento enfileirados
SELECT '' AS '[NFeEnvio].[ProtocoloNFe_Queue]', COUNT(1)
  FROM [NFeEnvio].[ProtocoloNFe_Queue] (nolock)
SELECT TOP 100 '' AS '[NFeEnvio].[ProtocoloNFe_Queue]', * 
  FROM [NFeEnvio].[ProtocoloNFe_Queue] (nolock) ORDER BY pKey DESC

SELECT '' AS '[NFeEnvio].[ProtocoloNFe]', COUNT(1) 
  FROM [NFeEnvio].[ProtocoloNFe] (nolock)
SELECT TOP 500 '' AS '[NFeEnvio].[ProtocoloNFe]', * 
  FROM [NFeEnvio].[ProtocoloNFe] (nolock) ORDER BY pKey DESC

SELECT TOP 500 '' AS '[NFeEnvio].[ProtocoloNFe] mais de 1 dia', * 
  FROM [NFeEnvio].[ProtocoloNFe] (nolock)
 WHERE timestampReg < DATEADD(DAY, -1, GETDATE())

SELECT TOP 15 '' AS '[NFeEnvio].[ProtocoloNFe] presos', * 
  FROM [NFeEnvio].[ProtocoloNFe] (nolock)
 WHERE nroTentativas >= 3

SELECT TOP 15 '' AS '[NFeEnvio].[ProtocoloNFe] quase presos', * 
  FROM [NFeEnvio].[ProtocoloNFe] (nolock)
 WHERE nroTentativas >= 1 AND nroTentativas < 3

-- Estat�sticas de envio de lote para AN
SELECT TOP 20 '' AS '[NFeEnvio].[EstatisticaEnvio]', * 
  FROM [NFeEnvio].[EstatisticaEnvio] (nolock)
 ORDER BY pkey DESC

-- Logs de erro
SELECT top 100 '' AS '[NFeEnvio].[LogXML]', * 
  FROM [NFeEnvio].[LogXML] (nolock)
 --WHERE erro like 'System.Data.SqlClient%'
 --WHERE timestampReg  > '2019-01-01'
 --  AND erro like 'System.Data.SqlClient%'
 ORDER BY pKey DESC

SELECT '' AS '[NFeEnvio].[LogXML] com requests' , *, CONVERT(XML, DECOMPRESS(Request)) as Request, CONVERT(XML, DECOMPRESS(Response)) as Resp
  FROM [NFeEnvio].[LogXML] (nolock)
 WHERE pkey in (SELECT TOP 10 pkey FROM [NFeEnvio].[LogXML] (nolock)
 WHERE Request IS NOT NULL 
                 ORDER BY pKey DESC)
 ORDER BY pKey DESC

SELECT '' AS '[NFeEnvio].[LogXML] com req/resp' , *, CONVERT(VARCHAR(MAX), DECOMPRESS(Request)), CONVERT(XML, DECOMPRESS(Request)) as Req, CONVERT(VARCHAR(MAX), DECOMPRESS(Response)) as Resp
  FROM [NFeEnvio].[LogXML] (nolock)
 WHERE pkey in (SELECT TOP 40 pkey FROM [NFeEnvio].[LogXML] (nolock)
 WHERE Request  IS NOT NULL 
   AND Response IS NOT NULL
   --AND erro NOT LIKE '%cStats:999%'
   --AND erro NOT LIKE '%2999%'
                 ORDER BY pKey DESC)
 ORDER BY pKey DESC

-- Log de envio e retorno do AN - desligado em homologa��o e produ��o.
SELECT TOP 5 *, CONVERT(XML, Request), CONVERT(XML, Response)
  FROM [NFeEnvio].[RetornoAN] (nolock)
-- where timestampReg > '2019-04-12'
 --where Response not like '%<cStat>113</cStat>%'
 --WHERE Request like '%35180300583099000100550100000000061231589520%'
ORDER BY timestampReg DESC

-- Confirma��o de protocolos recebidos
SELECT TOP 10 '' AS '[NFeEnvio].[ProtocoloRecebido]', *
  FROM [NFeEnvio].[ProtocoloRecebido] (nolock)
 WHERE [DB_NFeIntegra].$partition.PF_Part_01_Data(timestampReg) = [DB_NFeIntegra].$partition.PF_Part_01_Data(getdate())
  -- AND chNFe = '35170464555626000147550400000156361000156365'
 ORDER BY pKey DESC

-- Protocolos rejeitados
SELECT TOP 50 '' AS '[NFeEnvio].[ProtocoloRejeitado]', *
  FROM [NFeEnvio].[ProtocoloRejeitado] (nolock)
 --WHERE [DB_NFeIntegra].$partition.PF_Part_01_Data(timestampIntegra) = [DB_NFeIntegra].$partition.PF_Part_01_Data(getdate())
 ORDER BY pKey DESC

-- Protocolos rejeitados e enviados (consertados)
SELECT pr.*, pj.*
  FROM      [NFeEnvio].[ProtocoloRejeitado] pj (nolock)
 INNER JOIN [NFeEnvio].[ProtocoloRecebido]  pr (nolock)
    ON pj.fkProtocolo = pr.fkProtocolo
 WHERE pj.timestampProtocolo > '2019-1-1'

 RETURN

------------------------------------------------------------------------
 -- �ltimas 24 horas
USE NFe_Out
GO
 -- Quantidade de NSUs recebidos.
SELECT '' as QuantidadeDeNSUsRecebidos, LEFT(FORMAT(Count(1), '#,#', 'pt-br'), 20) 
  FROM [NFe_Out].[NFeIntegra].[IntegraNSU] (nolock)
 WHERE NFe_Out.$partition.PF_Part_02_Data(timestampReg) = NFe_Out.$partition.PF_Part_02_Data(getdate())
       AND timestampIntegra > DATEADD(DAY, -1, GETDATE())

-- Quantidade de protocolos autorizados 
SELECT '' as QuantidadeDeNotasAutorizadas, LEFT(FORMAT(Count(1), '#,#', 'pt-br'), 20) 
  FROM [NFe_Out].[NFeOut].[Protocolo] (nolock)
  WHERE NFe_Out.$partition.PF_Part_02_Data(timestampReg) = NFe_Out.$partition.PF_Part_02_Data(getdate()) 
        AND timestampReg > DATEADD(DAY, -1, GETDATE())

------------------------------------------------------------------------
USE NFe_Out
GO

-- NSUs recebidos.
SELECT TOP 5 '' AS '[NFeIntegra].[IntegraNSU]', * 
  FROM [NFeIntegra].[IntegraNSU] (nolock)
WHERE NFe_Out.$partition.PF_Part_02_Data(timestampReg) = NFe_Out.$partition.PF_Part_02_Data(getdate())
 ORDER BY nsu DESC

SELECT '' AS '[NFeIntegra].[IntegraNSU]', * 
  FROM [NFeIntegra].[IntegraNSU] (nolock)
WHERE NFe_Out.$partition.PF_Part_02_Data(timestampReg) = NFe_Out.$partition.PF_Part_02_Data(getdate())
  and nsu = 24509307248


------------------------------------------------------------------------
-- Confirma��o de protocolos enviados e recebidos
USE DB_NFeIntegra
GO 

DECLARE @NRO_PROTOCOLO BIGINT  = 7127840
DECLARE @ANO_PROTOCOLO CHAR(2) = 19
DECLARE @CHNFe         CHAR(44)
DECLARE @PKEY          BIGINT

SELECT @CHNFe = chNFe, @PKEY = p.pKey
  FROM [NFe_Out].[NFeOut].[Protocolo] p (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[NFe] n (nolock)
    ON p.pkey = n.pkey
   AND p.timestampReg = n.timestampReg
 WHERE p.nroProtocolo = @NRO_PROTOCOLO
   AND p.anoProtocolo = @ANO_PROTOCOLO
   AND p.idReceptor = 1

SELECT '' AS '[NFe_Out].[NFeOut].[NFe]', *
  FROM      [NFe_Out].[NFeOut].[NFe]       nf (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[Protocolo] pr (nolock)
    ON nf.pKey = pr.pKey
WHERE pr.anoProtocolo = @ANO_PROTOCOLO
  AND pr.nroProtocolo = @NRO_PROTOCOLO

SELECT '' AS '[NFe_Out].[NFeOut].[DadosTransmissao]', *
  FROM      [NFe_Out].[NFeOut].[DadosTransmissao] (nolock)
WHERE pKey = @PKEY

SELECT '' AS '[NFeEnvio].[ProtocoloRecebido]', *
  FROM [NFeEnvio].[ProtocoloRecebido] (nolock)
 WHERE nroProtocolo = @NRO_PROTOCOLO
   AND anoProtocolo = @ANO_PROTOCOLO

SELECT '' AS '[NFeEnvio].[ProtocoloRejeitado]', *
  FROM [NFeEnvio].[ProtocoloRejeitado] (nolock)
 WHERE nroProtocolo = @NRO_PROTOCOLO
   AND anoProtocolo = @ANO_PROTOCOLO

SELECT '' AS '[DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] / [ProtocoloNFe]', *
  FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] q (nolock)
INNER JOIN  [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pn (nolock)
   ON q.pKey = pn.pKey
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

SELECT '' AS '[DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe]', *
  FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pn (nolock)
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

DECLARE @maxPKeyLogXML BIGINT = (SELECT max(pkey) FROM [NFeEnvio].[LogXML] (nolock))
SELECT * , CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Request)) as Req, CONVERT(XML, DECOMPRESS(Response)) as Resp
  FROM [NFeEnvio].[LogXML] (nolock)
where pkey > @maxPKeyLogXML - 100
  AND [NFe_Out].[NFeOut].[UdfDecompressBin](Request) like '%'+@CHNFe+'%'
 ORDER BY pKey DESC

GO

-- An�lise de presos
SELECT TOP 500 '' AS 'presos', * 
  FROM      [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pnf (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[NFe] nf
    ON pnf.fkProtocolo = nf.pKey  
  WHERE nroTentativas >= 3

SELECT TOP 500 '' AS 'presos', *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](NFe)) as NFeEnviada 
  FROM      [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pnf (nolock)
 INNER JOIN [DFe_XML].[NFe].[NFeXml] x
    ON pnf.fkProtocolo = x.pKey  
 INNER JOIN [NFe_Out].[NFeOut].[NFe] nf
    ON pnf.fkProtocolo = nf.pKey  
  WHERE nroTentativas >= 3

GO

-- Procura de situa��o de uma nota por Chave
DECLARE @chNFe CHAR(44) = '35180511885244000115551540000210211000166986'

DECLARE @ANO_PROTOCOLO INT 
DECLARE @NRO_PROTOCOLO BIGINT 

SELECT @ANO_PROTOCOLO = anoProtocolo, @NRO_PROTOCOLO = nroProtocolo
  FROM      [NFe_Out].[NFeOut].[NFe]       nf (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[Protocolo] pr (nolock)
    ON nf.pKey = pr.pKey
WHERE chNFe = @chNFe

SELECT '' AS '[NFe_Out].[NFeOut].[NFe]', *
  FROM      [NFe_Out].[NFeOut].[NFe]       nf (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[Protocolo] pr (nolock)
    ON nf.pKey = pr.pKey
WHERE pr.anoProtocolo = @ANO_PROTOCOLO
  AND pr.nroProtocolo = @NRO_PROTOCOLO

SELECT '' AS '[NFeEnvio].[ProtocoloRecebido]', *
  FROM [NFeEnvio].[ProtocoloRecebido] (nolock)
 WHERE nroProtocolo = @NRO_PROTOCOLO
   AND anoProtocolo = @ANO_PROTOCOLO

SELECT '' AS '[NFeEnvio].[ProtocoloRejeitado]', *
  FROM [NFeEnvio].[ProtocoloRejeitado] (nolock)
 WHERE nroProtocolo = @NRO_PROTOCOLO
   AND anoProtocolo = @ANO_PROTOCOLO

SELECT '' AS '[DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] / [ProtocoloNFe]', *
  FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] q (nolock)
INNER JOIN  [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pn (nolock)
   ON q.pKey = pn.pKey
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

SELECT '' AS '[DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe]', *
  FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pn (nolock)
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

SELECT '' as '[NFe_Out].[NFeIntegra].[IntegraNSU]', * 
  FROM [NFe_Out].[NFeIntegra].[IntegraNSU] iu (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[Protocolo] pr (nolock)
    ON iu.fkProtocolo = pr.pKey
WHERE pr.anoProtocolo = @ANO_PROTOCOLO
  AND pr.nroProtocolo = @NRO_PROTOCOLO 

DECLARE @maxPKeyLogXML BIGINT = (SELECT max(pkey) FROM [NFeEnvio].[LogXML] (nolock))
SELECT * , CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Request)) as Req, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Response)) as Resp
  FROM [NFeEnvio].[LogXML] (nolock)
 WHERE pkey > @maxPKeyLogXML - 1000
   AND [NFe_Out].[NFeOut].[UdfDecompressBin](Request) like '%' + @chNFe + '%'
 ORDER BY pKey DESC

GO

-- Evento
DECLARE @ANO_PROTOCOLO INT = 19
DECLARE @NRO_PROTOCOLO BIGINT = 10111
SELECT *
  FROM      [NFe_Out].[NFeEventos].[Evento] ev (nolock)
 INNER JOIN [NFe_Out].[NFeOut].[Protocolo]  pr (nolock)
    ON ev.pKey = pr.pKey
WHERE pr.anoProtocolo = @ANO_PROTOCOLO
  AND pr.nroProtocolo = @NRO_PROTOCOLO

SELECT *
  FROM [NFeEventos].[EVENTO_RECEBIDO] (NOLOCK)
 WHERE EVT_NR_PROTOCOLO = @NRO_PROTOCOLO
   AND EVT_DT_ANO       = @ANO_PROTOCOLO

SELECT *
  FROM [NFeEventos].[EVENTO_REJEITADO] (NOLOCK)
 WHERE EVT_NR_PROTOCOLO = @NRO_PROTOCOLO
   AND EVT_DT_ANO       = @ANO_PROTOCOLO

GO
-------------------------------------------------------------------------
-- Verifica��o de dados que est�o na fila de envio
DECLARE @ANO_PROTOCOLO INT    = 18
DECLARE @NRO_PROTOCOLO BIGINT = 873052720

SELECT *
  FROM      [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] q  (nolock)
INNER JOIN  [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe]       pn (nolock)
   ON q.pKey = pn.pKey
INNER JOIN [NFe_Out].[NFeOut].[NFe] n (nolock)
   ON pn.fkProtocolo = n.pKey
INNER JOIN [NFe_Out].[NFeOut].[NFe_Constraint] c (nolock)
   ON pn.fkProtocolo = c.fkProtocolo
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

SELECT *
  FROM      [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] q (nolock)
INNER JOIN  [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe]      pn (nolock)
   ON q.pKey = pn.pKey
--WHERE pn.nroTentativas > 0
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

SELECT *
  FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] pn (nolock)
--WHERE pn.nroTentativas > 0
WHERE pn.anoProtocolo = @ANO_PROTOCOLO
  AND pn.nroProtocolo = @NRO_PROTOCOLO

SELECT ROW_NUMBER() OVER(ORDER BY pq.pkey ASC) as 'PosicaoNaFila', p.anoProtocolo as 'AnoProtocolo', p.nroProtocolo as 'NroProtocolo'
   INTO #FilaNFeEnvio
   FROM [NFeEnvio].[ProtocoloNFe_Queue] pq WITH(nolock)      
INNER JOIN [NFeEnvio].[ProtocoloNFe] p
   ON pq.pKey = p.pKey
  WHERE (flagRead = 0      
         OR DATEADD(second, 3600, dataModificado) <=  GETDATE())
  ORDER BY pq.pkey ASC

SELECT * FROM #FilaNFeEnvio
  WHERE NroProtocolo = @NRO_PROTOCOLO
    AND AnoProtocolo = @ANO_PROTOCOLO

DROP TABLE #FilaNFeEnvio

-----------------------------------------------------------------------
-- An�lise de protocolos recebidos e rejeitados, verificando se eles tem hist�rico de protocolos faltantes e tamb�m de eventos recebidos, 
-- que s�o dois fatores que podem levar a uma nota a estar rejeitada e recebida
USE DB_NFeIntegra
GO

 SELECT TOP 10 *
   FROM    [NFeEnvio].[ProtocoloRejeitado] pj (nolock)
INNER JOIN [NFeEnvio].[ProtocoloRecebido]  pr (nolock)
    ON  pr.anoProtocolo = pj.anoProtocolo
    AND pr.nroProtocolo = pj.nroProtocolo
  --WHERE pj.timestampIntegra > '2017-01-01'

SELECT c.* , f.*, j.*, ec.*
  FROM      [NFeEnvio].[ProtocoloRecebido]  c (nolock)
 INNER JOIN [NFeEnvio].[ProtocoloRejeitado] j (nolock)
    ON c.anoProtocolo = j.anoProtocolo
   AND c.nroProtocolo = j.nroProtocolo 
  LEFT JOIN [dbo].[PROTOCOLOS_FALTANTES_HISTORICO] f (nolock)
    ON c.anoProtocolo = f.PROT_NR_ANO_PROTOCOLO
   AND c.nroProtocolo = f.PROT_NR_PROTOCOLO
  LEFT JOIN [NFe_Out].[NFeEventos].[Evento_Constraint] ec (nolock)
    ON c.chNFe = ec.chNFe
 --WHERE f.PROT_NR_PROTOCOLO IS NULL   
 --  AND j.timestampIntegra > '2017-01-01'

/* --- Reenfileirameito de Presos
GO

BEGIN TRAN

    CREATE TABLE #Queue
    (
	    [pKey] [bigint] NOT NULL,
    )

    INSERT INTO #Queue (pKey)
    SELECT TOP 10000 pkey
      FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe] (nolock)
     WHERE nroTentativas = 3
       AND pKey NOT IN (SELECT pkey FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] (NOLOCK))
       -- AND timestampReg between '2017-09-19 01:17:00' and '2017-09-19 01:31:00' 
     ORDER BY pkey

    UPDATE [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe]
       SET nroTentativas = 0
     WHERE nroTentativas = 3
       AND pkey in (SELECT pKey FROM #Queue)

    INSERT INTO [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] (pKey, flagRead, dataModificado, uidExecution)
    SELECT pKey, 0, GETDATE(), NULL 
      FROM #Queue

    DROP TABLE #Queue

COMMIT
----- */

/* ------------ Reenfileiramento de rejeitados ---------------
USE [DB_NFeIntegra]
GO

BEGIN TRAN

    CREATE TABLE #Queue
    (
	    [pKey] [bigint] NOT NULL,
    )

    INSERT INTO #Queue (pKey)
    SELECT pkey
      FROM [NFeEnvio].[ProtocoloRejeitado] (nolock)
     WHERE ----- adicionar aqui a condi��o dos protocolos que ser�o reenviados

    INSERT INTO [NFeEnvio].[ProtocoloNFe_Queue]
               ([pKey]
               ,[flagRead]
               ,[dataModificado]
               ,[uidExecution])
	    SELECT pkey,
		       0,
		       GETDATE(),
		       NULL
          FROM #Queue

    SET IDENTITY_INSERT [NFeEnvio].[ProtocoloNFe] ON
	 
    INSERT INTO [NFeEnvio].[ProtocoloNFe]
               ([pKey]         ,
                [fkProtocolo]  ,
                [tpDocumento]  ,
                [idReceptor]   ,
                [ufProtocolo]  ,
                [anoProtocolo] ,
                [nroProtocolo] ,
                [nroTentativas],
                [timestampReg] )
	    SELECT [pKey]
		      ,[fkProtocolo]
		      ,[tpDocumento]
		      ,[idReceptor]
		      ,[ufProtocolo]
		      ,[anoProtocolo]
		      ,[nroProtocolo]
		      ,0 -- [nroTentativas]
		      ,[timestampIntegra]
	      FROM [NFeEnvio].[ProtocoloRejeitado] 
	     WHERE pKey IN (SELECT pkey from #Queue)

    SET IDENTITY_INSERT [NFeEnvio].[ProtocoloNFe] OFF

    DROP TABLE #Queue

COMMIT
----------------- */
-- Verifica��o de notas vers�o 4.00
select count(1)
from NFe_Out.NFeOut.NFe (nolock)
where $Partition.PF_Part_02_Data(timestampReg) = $Partition.PF_Part_02_Data(GETDATE())
  and timestampReg > '2017-11-06'
  and versao <> '3.10'

select count(1)
from NFe_Out_UFs.dbo.NFe (nolock)
where $Partition.PF_Part_02_Data(timestampRecebimento) = $Partition.PF_Part_02_Data(GETDATE())
  and timestampRecebimento > '2017-11-06'
  and versao <> '3.10'


--- Verifica��o de Inutiliza��o

SELECT * 
  FROM      NFe_Out.NFeOut.InutNFe        inut (NOLOCK)
 INNER JOIN NFe_Out.NFeOut.Protocolo      pr   (NOLOCK)
    ON inut.pKey = pr.pKey 
 INNER JOIN NFe_Out.NFeOut.NFe_Constraint ct   (NOLOCK)
    ON inut.pkey = ct.fkProtocolo
 WHERE pr.pKey = 8696935588

--DECLARE @maxPKeyLogXML BIGINT = (SELECT max(pkey) FROM [NFeEnvio].[LogXML] (nolock))
--SELECT * 
--  FROM [NFeEnvio].[LogXML] (nolock)
--where pkey = @maxPKeyLogXML - 901

DECLARE @maxPKeyLogXML BIGINT = (SELECT max(pkey) FROM [NFeEnvio].[LogXML] (nolock))
SELECT * , CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Request)) as Req, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Response)) as Resp
  FROM [NFeEnvio].[LogXML] (nolock)
where pkey > @maxPKeyLogXML - 1000
  AND [NFe_Out].[NFeOut].[UdfDecompressBin](Request) like '%<nNfIni>71441%'
 ORDER BY pKey DESC

 -- Pr�ximas leituras da fila
 SELECT TOP 1000 *
   FROM [NFeEnvio].[ProtocoloNFe_Queue] pq WITH(UPDLOCK,READPAST, index(IX_ProtocoloNFe_Queue_flagRead_dataModificado))      
  WHERE (flagRead = 0      
         OR DATEADD(second, 3600, dataModificado) <=  GETDATE())
  ORDER BY pq.pkey ASC

-- Verifica��o de registros na fila mas que foram recebidos no AN
SELECT *
  FROM      [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe_Queue] q (nolock)
INNER JOIN  [DB_NFeIntegra].[NFeEnvio].[ProtocoloNFe]       p (nolock)
   ON q.pKey = p.pKey
INNER JOIN  [DB_NFeIntegra].[NFeEnvio].[ProtocoloRecebido] r (nolock)
   ON p.fkProtocolo = r.fkProtocolo


select top 100 *
from NFe_Out.NFeOut.ConfigSistema_LOG
order by dataAlteracaoRegistro desc