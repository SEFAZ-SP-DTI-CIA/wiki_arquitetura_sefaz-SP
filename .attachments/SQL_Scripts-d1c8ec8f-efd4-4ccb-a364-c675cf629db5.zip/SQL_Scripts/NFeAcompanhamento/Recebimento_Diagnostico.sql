USE [NFe_Out_UFs]
GO

-- Items da fila sendo processados
SELECT '' as '[dbo].[LOG_XML_QUEUE] - Total', COUNT(1)
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
SELECT '' as '[dbo].[LOG_XML_QUEUE] - flag 0', COUNT(1)
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
 WHERE LOXM_FL_READ = 0
SELECT '' as '[dbo].[LOG_XML_QUEUE] - flag 1', COUNT(1)
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
 WHERE LOXM_FL_READ = 1
SELECT TOP 3 '' as '[dbo].[LOG_XML_QUEUE] - flag 0 ASC', *
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
 WHERE LOXM_FL_READ = 0
 ORDER BY [LOXM_CD_XML] ASC
SELECT TOP 3 '' as '[dbo].[LOG_XML_QUEUE] - flag 0 DESC', *
  FROM [dbo].[LOG_XML_QUEUE] (nolock)
 WHERE LOXM_FL_READ = 0
 ORDER BY [LOXM_CD_XML] DESC

DECLARE @DataMaisAntigaRegistroFila DATETIME = 
(SELECT top 1 LOXM_DT_MODIFIED
   FROM [dbo].[LOG_XML_QUEUE] (nolock)
  WHERE LOXM_FL_READ = 0
  ORDER BY [LOXM_CD_XML] ASC)
DECLARE @minutos FLOAT  = DATEDIFF(MINUTE, @DataMaisAntigaRegistroFila, GETDATE()) 
SELECT @minutos  as 'Minutos entre o dado mais antigo da fila e agora'

SELECT TOP 5 '' AS 'Log_XM_QUEUE join LOG_XML', * --, LOXM_TX_XML_Response 
  FROM      [dbo].[LOG_XML_QUEUE] q (nolock)
 INNER JOIN [dbo].[LOG_XML]       x (nolock)
    ON q.LOXM_CD_XML = x.LOXM_CD_XML 
 WHERE q.LOXM_FL_READ = 0
 ORDER BY q.LOXM_CD_XML ASC

-- Detalhes das �ltimas autoriza��es recebidas
SELECT top 5 '' AS '[dbo].[ProtocoloNFe]', *
  FROM [dbo].[ProtocoloNFe] p (NOLOCK)
 WHERE $Partition.PF_Part_01_Data_2(p.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())   
 ORDER BY p.nsu DESC

-- M�dia de atraso de recebimento de documentos (tempo entre autoriza��o e recebimento do mesmo) - dados dos �ltimos 10 minutos
DECLARE @dezMinutosAtras DATETIME = DATEADD(MINUTE, -10, GETDATE()) 
DECLARE @mediaAtrasoRecebimentoContraDataAutorizacaoEmMinutos FLOAT = 
    (SELECT AVG(DATEDIFF(MINUTE, timestampReg, timestampRecebimento))
        FROM [NFe_Out_UFs].[dbo].[ProtocoloNFe] p WITH (NOLOCK)
        WHERE [NFe_Out_UFs].$Partition.PF_Part_01_Data_2(p.timestampRecebimento) = [NFe_Out_UFs].$Partition.PF_Part_01_Data_2(GETDATE())   
        AND timestampRecebimento > @dezMinutosAtras)
SELECT @mediaAtrasoRecebimentoContraDataAutorizacaoEmMinutos             as 'Minutos entre o dado mais antigo recebido e agora', 
       @mediaAtrasoRecebimentoContraDataAutorizacaoEmMinutos / 60        as 'Horas entre o dado mais antigo recebido e agora',
       @mediaAtrasoRecebimentoContraDataAutorizacaoEmMinutos / (24 * 60) as 'Dias entre o dado mais antigo recebido e agora'

SELECT TOP 5 '' as '[dbo].[LOG_XML] com erro',LOXM_CD_XML, LOXM_DT_Timestamp,*
  FROM [dbo].[LOG_XML] x (nolock)
 WHERE LOXM_TX_Erro IS NOT NULL
 ORDER BY x.[LOXM_CD_XML] desc

SELECT TOP 5 '' AS '[dbo].[REGISTROS_LOTE_ERRO]', *
  FROM [dbo].[REGISTROS_LOTE_ERRO] (nolock)
 ORDER BY pKey DESC

RETURN 

-- ===========================================================
-- Atraso do recebimento em rela��o � data do protocolo
DECLARE @startDate DATETIME = '2017-12-01'

WHILE @startDate < GETDATE()
BEGIN
    SELECT top 1 timestampReg, timestampRecebimento, DATEDIFF(MINUTE, timestampReg, timestampRecebimento) as 'Atraso em minutos da primeira nota do dia'
      FROM [NFe_Out_UFs].[dbo].[ProtocoloNFe] p (nolock)
     WHERE $Partition.PF_Part_01_Data_2(p.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())
       and timestampRecebimento > @startDate 
     ORDER BY nsu asc

     SET @startDate = DATEADD(DAY, 1, @startDate)
END

RETURN

-- ===========================================================
-- Relat�rios de notas

-- Quantidade de NSUs recebidas em um dia
DECLARE @diaInicial DATETIME = '2017-11-10'
DECLARE @diaFinal DATETIME   = '2017-11-30'

SELECT cast(DATEPART(DAY, p.timestampRecebimento) as varchar) as Data, count(1) NSUs_Por_DataRecebimentoIntegra
  FROM [dbo].[IntegraNSU] p (NOLOCK)
 WHERE $Partition.PF_Part_01_Data(p.timestampRecebimento) = $Partition.PF_Part_01_Data(GETDATE())   
   and timestampRecebimento > @diaInicial
   and timestampRecebimento < @diaFinal
 group by DATEPART(DAY, timestampRecebimento)       
 order by DATEPART(DAY, timestampRecebimento)       

SELECT cast(DATEPART(DAY, p.timestampRecebimento) as varchar) as Data, count(1) Notas_Recebidas_DataRecebimentoIntegra
  FROM [dbo].[ProtocoloNFe] p (NOLOCK)
 WHERE $Partition.PF_Part_01_Data_2(p.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())   
   and timestampRecebimento > @diaInicial
   and timestampRecebimento < @diaFinal
 group by DATEPART(DAY, timestampRecebimento)       
 order by DATEPART(DAY, timestampRecebimento)    

SELECT cast(DATEPART(DAY, p.timestampRecebimento) as varchar) as Data, count(1) Eventos_Recebidas_DataRecebimentoIntegra
  FROM      [dbo].[IntegraNSU]           p (NOLOCK)
 INNER JOIN [NFeEventos].[IntegraEvento] e (NOLOCK)
    ON p.nsu = e.nsu 
 WHERE $Partition.PF_Part_01_Data(p.timestampRecebimento) = $Partition.PF_Part_01_Data(GETDATE())   
   and p.timestampRecebimento > @diaInicial
   and p.timestampRecebimento < @diaFinal
 group by DATEPART(DAY, p.timestampRecebimento)       
 order by DATEPART(DAY, p.timestampRecebimento) 

SELECT cast(DATEPART(DAY, p.timestampReg) as varchar) as Data, count(1) Notas_Recebidas_PorDataProtocolo
  FROM [dbo].[ProtocoloNFe] p (NOLOCK)
 WHERE $Partition.PF_Part_01_Data_2(p.timestampRecebimento) = $Partition.PF_Part_01_Data_2(GETDATE())   
   and timestampRecebimento > @diaInicial
   and timestampRecebimento < @diaFinal
 group by DATEPART(DAY, timestampReg)       
 order by DATEPART(DAY, timestampReg)     

--DECLARE @maxPkeyProtocolo BIGINT = (SELECT MAX(nsu)
--                                      FROM [NFe_Out_UFs].[dbo].[ProtocoloNFe] p (nolock)
--                                     WHERE [NFe_Out_UFs].$partition.PF_Part_01_Data(timestampReg) = [NFe_Out_UFs].$partition.PF_Part_01_Data(GETDATE()))
