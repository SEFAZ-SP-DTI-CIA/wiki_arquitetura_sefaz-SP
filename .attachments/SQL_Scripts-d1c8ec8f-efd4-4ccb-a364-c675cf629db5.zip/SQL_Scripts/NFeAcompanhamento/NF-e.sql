-- ==== Procura por chave nas principais tabelas

DECLARE @chNFe CHAR(44) = '35190817530779000230550010000005126401887949'
DECLARE @pkey BIGINT = (SELECT pKey FROM [NFe_Out].[NFeOut].[NFe] (NOLOCK) WHERE chNFe = @chNFe)

SELECT '' as Protocolo    , * FROM [NFe_Out].[NFeOut].[Protocolo]           (NOLOCK) WHERE pkey = @pkey
SELECT '' as NFe          , * FROM [NFe_Out].[NFeOut].[NFe]                 (NOLOCK) WHERE pkey = @pkey
SELECT '' as DadosTransm  , * FROM [NFe_Out].[NFeOut].[DadosTransmissao]    (NOLOCK) WHERE pkey = @pkey
SELECT '' as DadosTransmAN, * FROM [NFe_Out].[NFeOut].[DadosTransmissao_AN] (NOLOCK) WHERE pkey = @pkey
SELECT '' as NFeConstraint, * FROM [NFe_Out].[NFeOut].[NFe_Constraint]      (NOLOCK) WHERE fkProtocolo = @pkey

SELECT *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](NFe)) as Req
  FROM [DFe_XML].[NFe].[NFeXml] (NOLOCK) WHERE pkey = @pkey

SELECT * FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRecebido]  (NOLOCK) WHERE fkProtocolo = @pkey
SELECT * FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRejeitado] (NOLOCK) WHERE fkProtocolo = @pkey

SELECT * FROM [NFe_Out].[NFeOut].[ProtocoloRejeitado] (NOLOCK) WHERE chNFe = @chNFe
GO

-- ==== Procura por protocolo nas principais tabelas

DECLARE @nroProtocolo BIGINT  = 2716040
DECLARE @anoProtocolo CHAR(2) = 19

SELECT * FROM [NFe_Out].[NFeOut].[Protocolo] (NOLOCK) 
 WHERE-- [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE()) and
       nroProtocolo = @nroProtocolo and 
       anoProtocolo = @anoProtocolo and 
       idReceptor   = 1             and 
       ufProtocolo  = 35

DECLARE @pkey BIGINT = (SELECT pKey FROM [NFe_Out].[NFeOut].[Protocolo] (NOLOCK) WHERE nroProtocolo = @nroProtocolo and anoProtocolo = @anoProtocolo and idReceptor = 1)

SELECT * FROM [NFe_Out].[NFeOut].[Protocolo]        (NOLOCK) WHERE pkey = @pkey
SELECT * FROM [NFe_Out].[NFeOut].[NFe]              (NOLOCK) WHERE pkey = @pkey
SELECT * FROM [NFe_Out].[NFeOut].[DadosTransmissao] (NOLOCK) WHERE pkey = @pkey
SELECT * FROM [NFe_Out].[NFeOut].[NFe_Constraint]   (NOLOCK) WHERE fkProtocolo = @pkey

SELECT *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](NFe)) as Req
  FROM [DFe_XML].[NFe].[NFeXml] (NOLOCK) WHERE pkey = @pkey

SELECT * FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRecebido]  (NOLOCK) WHERE fkProtocolo = @pkey
SELECT * FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRejeitado] (NOLOCK) WHERE fkProtocolo = @pkey
GO

-- ==== Procura por CNPJ/nro/S�rie nas principais tabelas
DECLARE @chNFe CHAR(44) = '35180252646635000164550010000253151005767182'
DECLARE @cnpjEmit VARCHAR(14) = SUBSTRING(@chNFe, 7, 14)
DECLARE @numero   VARCHAR(9)  = SUBSTRING(@chNFe, 26, 9)
DECLARE @serie    VARCHAR(3)  = SUBSTRING(@chNFe, 23, 3)
DECLARE @UF       CHAR(2)     = SUBSTRING(@chNFe, 1, 2)

SELECT * FROM [NFe_Out].[NFeOut].[NFe_Constraint] (NOLOCK) WHERE cnpjEmit = @cnpjEmit AND numero = @numero AND serie = @serie

DECLARE @pkey BIGINT = (SELECT fkProtocolo FROM [NFe_Out].[NFeOut].[NFe_Constraint] (NOLOCK) WHERE cnpjEmit = @cnpjEmit AND numero = @numero AND serie = @serie)

SELECT * FROM [NFe_Out].[NFeOut].[Protocolo]        (NOLOCK) WHERE pkey = @pkey
SELECT * FROM [NFe_Out].[NFeOut].[NFe]              (NOLOCK) WHERE pkey = @pkey
SELECT * FROM [NFe_Out].[NFeOut].[DadosTransmissao] (NOLOCK) WHERE pkey = @pkey

SELECT *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](NFe)) as Req
  FROM [DFe_XML].[NFe].[NFeXml] (NOLOCK) WHERE pkey = @pkey

SELECT * FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRecebido]  (NOLOCK) WHERE fkProtocolo = @pkey
SELECT * FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRejeitado] (NOLOCK) WHERE fkProtocolo = @pkey

---================== Queries de acompanhamento de documentos mais recentes

SELECT TOP (100) *
  FROM [NFe_In].[NFeIn].[ProcessamentoLog] (nolock)
 ORDER BY pkey DESC

SELECT TOP (100) *
  FROM [NFe_In].[NFeIn].[LoteStagingV310]
 ORDER BY pkey DESC

DECLARE @maxPkeyProtocolo BIGINT = (SELECT MAX(pKey)
                                    FROM [NFe_Out].[NFeOut].[Protocolo] p (nolock)
                                    WHERE [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE()))
-- Todos os documentos
SELECT TOP (1000) *
  FROM [NFe_Out].[NFeOut].[Protocolo] p (nolock)
 WHERE pKey > @maxPkeyProtocolo - 1000
 ORDER BY pkey DESC
 
-- Somente notas
SELECT TOP (100) *
  FROM       [NFe_Out].[NFeOut].[Protocolo] p (nolock)
 INNER JOIN  [NFe_Out].[NFeOut].[NFe]       n (nolock)
    ON p.timestampReg = n.timestampReg
   AND p.pKey         = n.pKey  
 WHERE p.pKey > @maxPkeyProtocolo - 1000
 ORDER BY p.pkey DESC

-- Somente eventos
SELECT TOP (100) *
  FROM       [NFe_Out].[NFeOut].[Protocolo]  p (nolock)
 INNER JOIN  [NFe_Out].[NFeEventos].[Evento] e (nolock)
    ON p.timestampReg = e.timestampReg
   AND p.pKey         = e.pKey  
 WHERE p.pKey > @maxPkeyProtocolo - 1000
   AND p.tpDocumento = 2
   --and veraplic != 'AN_1.0.0'
 ORDER BY p.pkey DESC

-- Somente inutiliza��o
SELECT TOP (100) *
  FROM       [NFe_Out].[NFeOut].[Protocolo] p (nolock)
 --INNER JOIN  [NFe_Out].[NFeOut].[InutNFe]   i (nolock)
 --   ON p.timestampReg = i.timestampReg
 --  AND p.pKey         = i.pKey  
 WHERE p.pKey > @maxPkeyProtocolo - 1000
   AND p.tpDocumento = 3
 ORDER BY p.pkey DESC

SELECT TOP (1000) *
  FROM [NFe_Out].[NFeOut].[ProtocoloRejeitado] (nolock)
 WHERE [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE())
 ORDER BY pkey DESC

RETURN 

---================== Script para relat�rio de quantidade de protocolos 
USE master
GO

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

-- Declare o per�odo a ser comparado
-- Lembre-se: que se a compara��o n�o for do dia inteiro, algumas linhas da primeia ou da �ltima coluna poder�o retornar NULL
DECLARE @dataInicio datetime = '2017-12-11 00:00'
DECLARE @dataFim    datetime = '2017-12-17 23:59'
DECLARE @diffdays    int = 1  -- 1=compara todos os dias do intervalo, 7=compara o dia com a semana anterior

-- Vari�veis de controle
DECLARE @SQLSTR        VARCHAR(5000),
        @SQLSTRcolumns VARCHAR(5000)= '',
        @dataWork      DATETIME     = @dataInicio

-- Prepara a linha de datas para a query din�mica
WHILE @dataWork < @dataFim
BEGIN
       SELECT @SQLSTRcolumns = @SQLSTRcolumns + '[' + LEFT(CONVERT(VARCHAR, @dataWork, 120), 10) + '],'
       SET @dataWork = CONVERT(DATE, DATEADD(DAY ,@diffdays, @dataWork))
END
SET @SQLSTRcolumns=LEFT(@SQLSTRcolumns,len(@SQLSTRcolumns)-1)

IF OBJECT_ID('tempdb.dbo.#CTE1') IS NOT NULL
DROP TABLE #CTE1;

SELECT CONVERT(DATE, timestampReg) AS Data, DATEPART(HOUR, timestampReg) AS Hora
       --, DATEPART(MINUTE, timestampReg) AS Min
       ,COUNT(1)AS NroAutorizacoes
  INTO #CTE1
 FROM [NFe_Out].[NFeOut].[NFe] (NOLOCK)
WHERE timestampReg BETWEEN @dataInicio AND @dataFim
  AND [NFe_Out].$partition.[PF_Part_02_Data](timestampReg) >= [NFe_Out].$partition.[PF_Part_02_Data](@dataInicio)
  AND [NFe_Out].$partition.[PF_Part_02_Data](timestampReg) <= [NFe_Out].$partition.[PF_Part_02_Data](@dataFim)
GROUP BY CONVERT(DATE, timestampReg), DATEPART(HOUR, timestampReg)--,  DATEPART(MINUTE, timestampReg)

SET @SQLSTR='
SELECT * FROM #CTE1 AS C1
PIVOT
(
    SUM (NroAutorizacoes)
    FOR [Data] IN ('+@SQLSTRcolumns+')
) AS pvt
ORDER BY Hora'

EXEC (@SQLSTR)

-- ================================================================ 
USE [NFe_Out]
GO

SELECT top 10 *
  FROM [NFeOut].[SondaMonitoracaoSefaz]
-- WHERE nfeAtiva = 0
 ORDER BY pkey DESC
 
-- ================================================================ 
-- Notas de um contribuinte espec�fico
USE [NFe_Out]
GO
SELECT * 
  FROM [NFe_Out].[NFeOut].[NFe_Constraint]   nc (NOLOCK) 
  JOIN [NFe_Out].[NFeOut].[NFe]              n  (NOLOCK) 
    ON nc.fkProtocolo = n.pKey
 WHERE [NFe_Out].$partition.PF_Part_02_Data(nc.timestampReg) >= [Nfe_Out].$partition.PF_Part_02_Data(dateadd(YEAR, -1, GETDATE()))
   AND nc.cnpjEmit = '24723167000149'

-- ================================================================
-- Verifica��o se documentos n�o recebidos na DadosTransmissao foram transmitidos
USE NFe_Out
GO

DECLARE @DataInicial DATETIME = '2019-1-1'
DECLARE @DataFinal   DATETIME = '2019-12-31' -- GETDATE()

DECLARE @ANO INT = DATEPART(YEAR, @DataInicial) % 2000

SELECT * INTO #PROTOCOLOS_FALTANTES_PERIODO
  FROM       [DB_NFEINTEGRA].[dbo].[PROTOCOLOS_FALTANTES_HISTORICO] f (nolock)
 WHERE PROT_DT_TIMESTAMP_REG > @DataInicial
   AND PROT_DT_TIMESTAMP_REG < @DataFinal

SELECT f.*, p.pKey, p.nroProtocolo, p.anoProtocolo INTO #FALTANTES_SEM_DADOS_TRANSMISSAO
  FROM      #PROTOCOLOS_FALTANTES_PERIODO f
 INNER JOIN [NFeOut].Protocolo            p (nolock)
    ON f.PROT_NR_PROTOCOLO     = p.nroProtocolo
   AND f.PROT_NR_ANO_PROTOCOLO = p.anoProtocolo
  LEFT JOIN  [NFeOut].[DadosTransmissao] dt (nolock)
    ON  p.pKey = dt.pKey   
 WHERE [NFe_Out].$partition.PF_Part_02_Data(p.timestampReg)  >= [Nfe_Out].$partition.PF_Part_02_Data(@DataInicial)
   AND [NFe_Out].$partition.PF_Part_02_Data(p.timestampReg)  <= [Nfe_Out].$partition.PF_Part_02_Data(@DataFinal)
   AND dt.pKey is null
   AND p.idReceptor  = 1
   AND p.ufProtocolo = 35
 ORDER BY PROT_CD_PROTOCOLOS_FALTANTES DESC

SELECT 'FaltantesSemDadosTransmissao', * 
  FROM #FALTANTES_SEM_DADOS_TRANSMISSAO f
 ORDER BY PROT_DT_TIMESTAMP_REG

SELECT 'FaltantesSemDadosTransmissaoTransmitidosAN',* FROM #FALTANTES_SEM_DADOS_TRANSMISSAO f
 INNER JOIN [DB_NFeIntegra].[NFeEventos].[EVENTO_RECEBIDO] er (nolock)
    ON er.EVT_NR_PROTOCOLO = f.PROT_NR_PROTOCOLO
 WHERE er.EVT_DT_ANO       = @ANO
 ORDER BY PROT_DT_TIMESTAMP_REG

DROP TABLE #PROTOCOLOS_FALTANTES_PERIODO
DROP TABLE #FALTANTES_SEM_DADOS_TRANSMISSAO

-- ================================================================
-- Verifica��o de documentos recebidos mais recentemente - S�vio
USE NFe_Out
GO

SELECT TOP 100 *
  INTO #tmp_testeNFe1
  FROM [NFe_Out].[NFeOut].[NFe] n (NOLOCK)
 WHERE NFe_Out.$partition.PF_Part_02_Data(timestampReg) =  NFe_Out.$partition.PF_Part_02_Data(getdate()) and versao='4.00'
 ORDER BY n.pkey DESC

SELECT recibo, versao, host, timestampReg, row_number() over(partition by host order by timestampReg desc) as roworder
  INTO #tmp_testeNFe2
  FROM      #tmp_testeNFe1                       n
 INNER JOIN [NFe_In].[NFeIn].[ProcessamentoLog] p (NOLOCK)
    ON n.recibo = p.pKey
 
SELECT * FROM #tmp_testeNFe2
 WHERE roworder = 1
 ORDER BY host ASC

DROP TABLE #tmp_testeNFe1
DROP TABLE #tmp_testeNFe2
