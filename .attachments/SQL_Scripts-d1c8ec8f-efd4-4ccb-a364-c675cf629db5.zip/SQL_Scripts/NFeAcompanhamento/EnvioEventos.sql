USE DB_NFeIntegra
GO

-- Tabelas com registros enfileirados para serem enviados
SELECT '' as '[NFeEventos].[Evento_Envio_Queue]', Count(1)
  FROM [NFeEventos].[Evento_Envio_Queue] (NOLOCK)
SELECT TOP 200 '' as '[NFeEventos].[Evento_Envio_Queue]',*
  FROM [NFeEventos].[Evento_Envio_Queue] (NOLOCK)
 ORDER BY EVT_CD_EVENTO DESC

SELECT '' as '[NFeEventos].[Evento]', Count(1)
  FROM [NFeEventos].[Evento] (NOLOCK)
SELECT TOP 200 '' as '[NFeEventos].[Evento]', *
  FROM [NFeEventos].[Evento] (NOLOCK)
 ORDER BY EVT_CD_EVENTO DESC

SELECT '' as '[NFeEventos].[Evento_XML]', Count(1)
  FROM [NFeEventos].[Evento_XML] (NOLOCK)
SELECT TOP 200 '' as '[NFeEventos].[Evento_XML]', *
  FROM [NFeEventos].[Evento_XML] (NOLOCK)

-- Logs de erro
SELECT TOP 50 '' as '[NFeEventos].[LOG_XML]', LOXM_DT_Timestamp, *
  FROM [NFeEventos].[LOG_XML] (NOLOCK)
WHERE LOXM_DT_Timestamp between '2019-06-25 09:22:00' and '2019-06-25 10:30:00'
and LOXM_TX_XML_Request like '%1101103519066003940100018755005000049088113913114803%'
 ORDER BY LOXM_CD_XML DESC

SELECT TOP 50 '' as '[NFeEventos].[LOG_XML]', LOXM_DT_Timestamp, *, CONVERT(XML, LOXM_TX_XML_Request) as Req, CONVERT(XML, LOXM_TX_XML_Response) as Resp 
  FROM [NFeEventos].[LOG_XML] (NOLOCK)
 ORDER BY LOXM_CD_XML DESC

-- Estat�sticas de envio
SELECT TOP 500 '' as '[dbo].[ESTATISTICA_ENVIO]', *
 FROM [dbo].[ESTATISTICA_ENVIO] (NOLOCK)
 ORDER BY ESWE_CD_ESTATISTICA_WEBSERVICE DESC

-- Tabelas de retorno dos eventos enviados
SELECT '' as '[NFeEventos].[EVENTO_RETORNO_QUEUE]', COUNT(1)
  FROM [NFeEventos].[EVENTO_RETORNO_QUEUE] (NOLOCK)
SELECT TOP 5 '' as '[NFeEventos].[EVENTO_RETORNO_QUEUE]', *, CONVERT(XML, LOXM_TX_XML_Request) as Req, CONVERT(XML, LOXM_TX_XML_Response) as Resp 
  FROM [NFeEventos].[EVENTO_RETORNO_QUEUE] (NOLOCK)
ORDER BY EVT_CD_QUEUE DESC

SELECT '' as '[NFeEventos].[EVENTO_RECEBIDO]',*
  FROM [NFeEventos].[EVENTO_RECEBIDO] (NOLOCK)
 WHERE EVT_CD_EVENTO > (SELECT MAX(EVT_CD_EVENTO) - 100 
                         FROM [NFeEventos].[EVENTO_RECEBIDO] (NOLOCK))
 --AND EVT_CD_CH_NFE = '35190817530779000230550010000005126401887949'
ORDER BY EVT_DT_TIMESTAMP_REG DESC


SELECT '' as '[NFeEventos].[EVENTO_RECEBIDO]',*
  FROM [NFeEventos].[EVENTO_RECEBIDO] (NOLOCK)
 WHERE EVT_CD_CH_NFE = '35190660039401000187550050000490881139131148'
ORDER BY EVT_DT_TIMESTAMP_REG DESC


-- Tabelas de retorno dos eventos rejeitados
SELECT TOP 500 '' as '[NFeEventos].[EVENTO_REJEITADO]', EVT_DT_TIMESTAMP_REG, *
FROM [NFeEventos].[EVENTO_REJEITADO] (NOLOCK)
--WHERE EVT_CD_CH_NFE = '35190817530779000230550010000005126401887949'
ORDER BY EVT_CD_EVENTO DESC

SELECT TOP 5 '' as '[NFeEventos].[EVENTO_REJEITADO_XML]',  *, CONVERT(XML, EVX_MM_EVENTO) as ev
FROM [NFeEventos].[EVENTO_REJEITADO_XML] (NOLOCK)
ORDER BY EVT_CD_EVENTO DESC

-- Rejeitados e Enviados (consertados)
SELECT ej.*, '', er.*
  FROM      [NFeEventos].[EVENTO_REJEITADO] ej (NOLOCK)
 INNER JOIN [NFeEventos].[EVENTO_RECEBIDO]  er (NOLOCK)
    ON ej.EVT_DT_ANO       = er.EVT_DT_ANO
   AND ej.EVT_NR_PROTOCOLO = er.EVT_NR_PROTOCOLO
 WHERE ej.EVT_DT_TIMESTAMP_REG > '2019-1-1'
ORDER BY ej.EVT_CD_EVENTO DESC

-- Tabelas de retorno dos eventos rejeitados

------------------------------------------------------------------------
-- Presos

SELECT TOP 15 '' as '[NFeEventos].[Evento]', *
  FROM [NFeEventos].[Evento] (NOLOCK)
 WHERE EVT_NR_TENTATIVAS = 3
 ORDER BY EVT_CD_EVENTO DESC

------------------------------------------------------------------------
USE NFe_Out
GO

-- NSUs recebidos.
SELECT TOP 5000 '' as '[NFeIntegra].[IntegraNSU]', * 
  FROM [NFeIntegra].[IntegraNSU] (NOLOCK)
WHERE NFe_Out.$partition.PF_Part_02_Data(timestampReg) = NFe_Out.$partition.PF_Part_02_Data(getdate())
 ORDER BY nsu DESC

-----------------------------------------------------------------------
-- Eventos n�o enviados
SELECT *
  FROM       [DB_NFeIntegra].[NFeEventos].[Evento]     ev    (NOLOCK)
 INNER JOIN  [DB_NFeIntegra].[NFeEventos].[Evento_XML] evxml (NOLOCK)
  ON ev.EVT_CD_EVENTO = evxml.EVT_CD_EVENTO
 ORDER BY ev.EVT_CD_EVENTO

-- Procura por eventos espec�ficos recebidos/rejeitados por ano / protocolo do evento
USE DB_NFeIntegra
GO

DECLARE @ANO VARCHAR(2) = 19
DECLARE @PROTOCOLO INT = 30558839

SELECT '' as '[NFeEventos].[EVENTO_RECEBIDO]',*
  FROM [NFeEventos].[EVENTO_RECEBIDO] (NOLOCK)
 WHERE EVT_NR_PROTOCOLO = @PROTOCOLO
   AND EVT_DT_ANO = @ANO

SELECT '' as '[NFeEventos].[EVENTO_REJEITADO] / [EVENTO_REJEITADO_XML]', EVT_DT_TIMESTAMP_REG, *
  FROM      [NFeEventos].[EVENTO_REJEITADO]     er    (NOLOCK)
 INNER JOIN [NFeEventos].[EVENTO_REJEITADO_XML] erxml (NOLOCK)
    ON er.EVT_CD_EVENTO = erxml.EVT_CD_EVENTO
 WHERE EVT_NR_PROTOCOLO = @PROTOCOLO
   AND EVT_DT_ANO       = @ANO

-----------------------------------------------------------------------
-- Procura por eventos recebidos/rejeitados espec�ficos - chave
USE DB_NFeIntegra
GO

DECLARE @chNFe CHAR(44) = '35190899171171171115550070019205521788793041'

SELECT '' as '[NFeEventos].[Evento]',*
  FROM [NFeEventos].[Evento] (NOLOCK)
 WHERE EVT_CD_CH_NFE = @chNFe

SELECT '' as '[NFeEventos].[Evento_Envio_Queue]', q.*
  FROM     [NFeEventos].[Evento]             e (NOLOCK)
 INNER JOIN [NFeEventos].[Evento_Envio_Queue] q (NOLOCK)
   ON e.EVT_CD_EVENTO = q.EVT_CD_EVENTO
WHERE e.EVT_CD_CH_NFE = @chNFe
                            
SELECT '' as '[NFeEventos].[EVENTO_RETORNO_QUEUE]', *, CONVERT(XML, LOXM_TX_XML_Request) as Req, CONVERT(XML, LOXM_TX_XML_Response) as Resp 
  FROM [NFeEventos].[EVENTO_RETORNO_QUEUE] (NOLOCK)
 WHERE LOXM_TX_XML_Request like  '%'+@chNFe+'%'
ORDER BY EVT_CD_QUEUE DESC
                           
SELECT '' as '[NFeEventos].[EVENTO_RECEBIDO]',*
  FROM [NFeEventos].[EVENTO_RECEBIDO] (NOLOCK)
 WHERE EVT_CD_CH_NFE = @chNFe
 ORDER BY EVT_CD_EVENTO DESC

SELECT '' as '[NFeEventos].[EVENTO_REJEITADO] / [EVENTO_REJEITADO_XML]', EVT_DT_TIMESTAMP_REG, *
  FROM      [NFeEventos].[EVENTO_REJEITADO]     er    (NOLOCK) 
 INNER JOIN [NFeEventos].[EVENTO_REJEITADO_XML] erxml (NOLOCK)
    ON er.EVT_CD_EVENTO = erxml.EVT_CD_EVENTO
 WHERE er.EVT_CD_CH_NFE = @chNFe
 ORDER BY er.EVT_CD_EVENTO DESC

-- Procura por eventos nos logs
SELECT TOP 1 '' as '[NFeEventos].[LOG_XML]', LOXM_DT_Timestamp, * -- para achar LOXM_CD_XML base a ser usado no select seguinte
  FROM [NFeEventos].[LOG_XML] (NOLOCK)
 WHERE LOXM_DT_Timestamp > '2019-09-04 00:00'
 ORDER BY LOXM_CD_XML ASC

SELECT TOP 5 '' as '[NFeEventos].[LOG_XML]', LOXM_DT_Timestamp, *, CONVERT(XML, LOXM_TX_XML_Request) as Req,  CONVERT(XML, LOXM_TX_XML_Response) as Resp
  FROM [NFeEventos].[LOG_XML] (NOLOCK)
 WHERE LOXM_CD_XML > 188                  -- usar LOXM_CD_XML gerado acima
   AND LOXM_DT_Timestamp > '2019-09-06 00:00'
   AND LOXM_TX_XML_Request like '%'+@chNFe+'%'
 ORDER BY LOXM_CD_XML ASC

-----------------------------------------------------------------------
-- Procura dos eventos e chaves na base NFe_Out
USE NFe_Out
GO

DECLARE @chNFCe   CHAR(44) = '35121052556578000807550000000927581000927588'

--SELECT TOP 10 *
--  FROM NFe_Out.NFeEventos.Evento    ev (nolock)
--INNER JOIN NFe_Out.NFeOut.Protocolo pr (nolock)
--   ON ev.pKey = pr.pKey
-- WHERE idEvento = @idEvento

SELECT TOP 10 *
  FROM      NFe_Out.NFeOut.Protocolo  pr(nolock)
 INNER JOIN NFe_Out.NFeEventos.Evento ev
    ON pr.pKey = ev.pKey
 INNER JOIN NFe_Out.NFeEventos.Evento_Constraint ec
    ON pr.pKey = ec.fkProtocolo
 WHERE ec.chNFe = @chNFCe

SELECT TOP 10 *
FROM NFe_Out.NFeOut.NFe (nolock)
WHERE chNFe = @chNFCe

------------ An�lise de timeout da proc de reenvio ------------ 
SELECT TOP 10 '' as '[NFeEventos].[LOG_XML]', LOXM_DT_Timestamp, *
  FROM [NFeEventos].[LOG_XML] (NOLOCK)
 WHERE LOXM_TX_Erro like 'System.Data.SqlClient.SqlException%'
   --AND LOXM_TX_Erro like '%ObterEventosDaFila%'
 ORDER BY LOXM_CD_XML DESC

/* ------------ Reenfileirameito de Presos ------------ 
GO

BEGIN TRAN

    CREATE TABLE #Queue
    (
	    [pKey] [bigint] NOT NULL,
    )

    INSERT INTO #Queue (pKey)
    SELECT EVT_CD_EVENTO
      FROM [DB_NFeIntegra].[NFeEventos].[Evento] (nolock)
     WHERE EVT_NR_TENTATIVAS = 3
       AND EVT_CD_EVENTO NOT IN (SELECT EVT_CD_EVENTO FROM [DB_NFeIntegra].[NFeEventos].[Evento_Envio_Queue] (NOLOCK))
       -- AND timestampReg between '2017-09-19 01:17:00' and '2017-09-19 01:31:00' 
     ORDER BY EVT_CD_EVENTO

    UPDATE [DB_NFeIntegra].[NFeEventos].[Evento]
       SET EVT_NR_TENTATIVAS = 0
     WHERE EVT_NR_TENTATIVAS = 3
       AND EVT_CD_EVENTO in (SELECT pKey FROM #Queue)

    INSERT INTO [DB_NFeIntegra].[NFeEventos].[Evento_Envio_Queue] 
           (EVT_CD_EVENTO, EVT_FL_READ, EVT_DT_MODIFIED, EVT_UID_EXECUTION, CONF_TX_SERVICO)
    SELECT pKey          , 0          , GETDATE()      , NULL             , 'NFeEnvioEventos'
      FROM #Queue

    DROP TABLE #Queue

COMMIT
-------------- */


/* ------------ Reenfileiramento de rejeitados ---------------
USE [DB_NFeIntegra]
GO

BEGIN TRAN

    CREATE TABLE #Queue
    (
	    [pKey] [bigint] NOT NULL,
    )

    INSERT INTO #Queue (pKey)
    SELECT EVT_CD_EVENTO
      FROM [DB_NFeIntegra].[NFeEventos].[Evento_Rejeitado] (nolock)
     WHERE ----- adicionar aqui a condi��o dos eventos que ser�o reenfileirados

    INSERT INTO [NFeEventos].[Evento_XML]
          (EVT_CD_EVENTO, EVX_MM_EVENTO)
    SELECT EVT_CD_EVENTO, EVX_MM_EVENTO
      FROM [NFeEventos].[EVENTO_REJEITADO_XML] (NOLOCK)
     WHERE EVT_CD_EVENTO IN (SELECT pkey from #Queue)

    INSERT INTO [NFeEventos].[EVENTO_ENVIO_QUEUE]
               ([EVT_CD_EVENTO]
               ,[CONF_TX_SERVICO]
               ,[CONF_TX_ESPECIALIZACAO]
               ,[EVT_FL_READ]
               ,[EVT_DT_MODIFIED]
               ,[EVT_UID_EXECUTION])
	    SELECT EVT_CD_EVENTO,
		       NULL,
		       NULL,
		       0,
		       GETDATE(),
		       NULL
          FROM [NFeEventos].[EVENTO_REJEITADO_XML] (NOLOCK)
         WHERE EVT_CD_EVENTO IN (SELECT pkey from #Queue)

    SET IDENTITY_INSERT [NFeEventos].[EVENTO] ON
	 
    INSERT INTO [NFeEventos].[EVENTO]
               ([EVT_CD_EVENTO]
		       ,[EVT_CD_RECEPTOR]
               ,[EVT_CD_ORIGEM]
               ,[EVT_DT_ANO]
               ,[EVT_NR_PROTOCOLO]
               ,[EVT_CD_STATUS]
               ,[EVT_NR_TENTATIVAS]
               ,[EVT_CD_ID_EVENTO]
               ,[EVT_CD_AMB]
               ,[EVT_NR_VERSAO]
               ,[EVT_DS_VER_APLIC]
               ,[EVT_CD_ORGAO]
               ,[EVT_CD_CH_NFE]
               ,[EVT_CD_TP_EVENTO]
               ,[EVT_NR_SEQ_EVENTO]
               ,[EVT_CNPJDEST_CPFDEST]
               ,[EVT_EMAIL]
               ,[EVT_DT_TIMESTAMP_REG]
               ,[EVT_NFEOUT_FKEVENTO]
               ,[EVT_NFEOUT_FKCOMPLEMENTO_EVENTO]
               ,[EVT_TP_IDDEST]
               ,[EVT_IP_ORIGEM])
	    SELECT [EVT_CD_EVENTO]
		      ,[EVT_CD_RECEPTOR]
		      ,[EVT_CD_ORIGEM]
		      ,[EVT_DT_ANO]
		      ,[EVT_NR_PROTOCOLO]
		      ,[EVT_CD_STATUS]
		      ,0 -- [EVT_NR_TENTATIVAS]
		      ,[EVT_CD_ID_EVENTO]
		      ,[EVT_CD_AMB]
		      ,[EVT_NR_VERSAO]
		      ,[EVT_DS_VER_APLIC]
		      ,[EVT_CD_ORGAO]
		      ,[EVT_CD_CH_NFE]
		      ,[EVT_CD_TP_EVENTO]
		      ,[EVT_NR_SEQ_EVENTO]
		      ,[EVT_CNPJDEST_CPFDEST]
		      ,[EVT_EMAIL]
		      ,[EVT_DT_TIMESTAMP_REG]
		      ,[EVT_NFEOUT_FKEVENTO]
		      ,[EVT_NFEOUT_FKCOMPLEMENTO_EVENTO]
		      ,[EVT_TP_IDDEST]
		      ,[EVT_IP_ORIGEM]
	      FROM [DB_NFeIntegra].[NFeEventos].[EVENTO_REJEITADO]
	     WHERE EVT_CD_EVENTO IN (SELECT pkey from #Queue)

    SET IDENTITY_INSERT [NFeEventos].[EVENTO] OFF

    DROP TABLE #Queue

COMMIT
----------------- */
