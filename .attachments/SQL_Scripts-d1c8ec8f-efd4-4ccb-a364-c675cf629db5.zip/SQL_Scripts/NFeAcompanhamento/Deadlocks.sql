USE ADM_BDADOS
GO

SELECT TOP 100 * FROM SQLDeadlockEvents d WITH (NOLOCK) 
 WHERE d.AlertTime > GETDATE()-20
   and DatabaseName != 'CTe_Out'
 ORDER BY AlertTime DESC

