-- ==== Procura por chave da nota do evento nas principais tabelas

DECLARE @chNFe CHAR(44) = '35190817530779000230550010000005126401887949'
DECLARE @pkeyList TABLE (pkey BIGINT) 

-- Busca na NFe_Out

INSERT INTO @pkeyList SELECT fkProtocolo FROM [NFe_Out].[NFeEventos].[Evento_Constraint] (NOLOCK) WHERE chNFe = @chNFe

SELECT * FROM [NFe_Out].[NFeOut].[Protocolo] p         (NOLOCK) INNER JOIN @pkeyList pl ON  p.pkey = pl.pkey
SELECT * FROM [NFe_Out].[NFeOut].[DadosTransmissao] dt (NOLOCK) INNER JOIN @pkeyList pl ON dt.pkey = pl.pkey
SELECT * FROM [NFe_Out].[NFeOut].[DadosTransmissao_AN] dt (NOLOCK) INNER JOIN @pkeyList pl ON dt.pkey = pl.pkey
SELECT * FROM [NFe_Out].[NFeEventos].[Evento] e        (NOLOCK) INNER JOIN @pkeyList pl ON  e.pkey = pl.pkey

SELECT '' as 'EventoXml', *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Evento)) as Req
  FROM      [DFe_XML].[NFe].[EventoXml] e (NOLOCK) 
 INNER JOIN @pkeyList pl 
    ON e.pkey = pl.pkey

-- Busca no Integra 

DECLARE @anoNroProtocolo TABLE (nro BIGINT, ano BIGINT)

INSERT INTO @anoNroProtocolo
SELECT nroProtocolo, anoProtocolo FROM [NFe_Out].[NFeOut].[Protocolo] p (NOLOCK) 
 INNER JOIN @pkeyList pl ON  p.pkey = pl.pkey

SELECT '' as 'EVENTO', * FROM [DB_NFeIntegra].[NFeEventos].[EVENTO]  e (NOLOCK) 
 INNER JOIN @anoNroProtocolo p 
    ON e.EVT_NR_PROTOCOLO = p.nro
   AND e.EVT_DT_ANO       = p.ano

SELECT '' as 'EVENTO_RECEBIDO', * FROM [DB_NFeIntegra].[NFeEventos].[EVENTO_RECEBIDO]  er (NOLOCK) 
 INNER JOIN @anoNroProtocolo p 
    ON er.EVT_NR_PROTOCOLO = p.nro
   AND er.EVT_DT_ANO       = p.ano

SELECT '' as 'EVENTO_REJEITADO', * FROM [DB_NFeIntegra].[NFeEventos].[EVENTO_REJEITADO]  er (NOLOCK) 
 INNER JOIN @anoNroProtocolo p 
    ON er.EVT_NR_PROTOCOLO = p.nro
   AND er.EVT_DT_ANO       = p.ano

SELECT * FROM [NFe_Out].[NFeOut].[ProtocoloRejeitado] (NOLOCK) WHERE chNFe = @chNFe

GO
-- ==== Procura por protocolo do evento nas principais tabelas

DECLARE @nroProtocolo BIGINT = 145182717
DECLARE @anoProtocolo CHAR(2) = 18
DECLARE @pkeyList TABLE (pkey BIGINT) 

SELECT * FROM [NFe_Out].[NFeOut].[Protocolo] (NOLOCK) 
 WHERE [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE())
       and nroProtocolo = @nroProtocolo 
       and anoProtocolo = @anoProtocolo
       and idReceptor   = 1             
       and ufProtocolo  = 35
-- Busca na NFe_Out

INSERT INTO @pkeyList SELECT pkey FROM [NFe_Out].[NFeOut].[Protocolo] (NOLOCK) 
                       WHERE nroProtocolo = @nroProtocolo 
                         and anoProtocolo = @anoProtocolo
                         and idReceptor   = 1             
                         and ufProtocolo  = 35

SELECT * FROM [NFe_Out].[NFeOut].[Protocolo] p         (NOLOCK) INNER JOIN @pkeyList pl ON  p.pkey = pl.pkey
SELECT * FROM [NFe_Out].[NFeOut].[DadosTransmissao] dt (NOLOCK) INNER JOIN @pkeyList pl ON dt.pkey = pl.pkey
SELECT * FROM [NFe_Out].[NFeEventos].[Evento] e        (NOLOCK) INNER JOIN @pkeyList pl ON e.pkey = pl.pkey

--SELECT '' as 'EventoXml', *, CONVERT(XML, [NFe_Out].[NFeOut].[UdfDecompressNFe](Evento)) as Req
--  FROM      [DFe_XML].[NFe].[EventoXml] e (NOLOCK) 
-- INNER JOIN @pkeyList pl 
--    ON e.pkey = pl.pkey

-- Busca no Integra 
SELECT '' as 'EVENTO', * FROM [DB_NFeIntegra].[NFeEventos].[EVENTO]  e (NOLOCK) 
 WHERE e.EVT_NR_PROTOCOLO = @nroProtocolo
   AND e.EVT_DT_ANO       = @anoProtocolo

SELECT '' as 'EVENTO_RECEBIDO', * FROM [DB_NFeIntegra].[NFeEventos].[EVENTO_RECEBIDO]  er (NOLOCK) 
 WHERE er.EVT_NR_PROTOCOLO = @nroProtocolo
   AND er.EVT_DT_ANO       = @anoProtocolo

SELECT '' as 'EVENTO_REJEITADO', * FROM [DB_NFeIntegra].[NFeEventos].[EVENTO_REJEITADO]  er (NOLOCK) 
 WHERE er.EVT_NR_PROTOCOLO = @nroProtocolo
   AND er.EVT_DT_ANO       = @anoProtocolo



