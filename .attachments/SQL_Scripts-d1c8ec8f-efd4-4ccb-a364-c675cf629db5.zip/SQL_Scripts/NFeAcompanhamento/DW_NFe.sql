-- ================= Logs execu��o corrente ================= 
SELECT TOP 1000 *
  FROM [ETL_NFE].[DWNFe].[LOG_EXECUCAO_PROCESSO] (nolock)
 --WHERE LEXP_DS_TIPO = 'Error'
 ORDER BY LEXP_DT_LOG DESC

-- ====================================================================
-- ================= An�lise �ltima rodada

DECLARE @pkeyInicial  BIGINT
DECLARE @pkeyFinal    BIGINT
DECLARE @pkeyMax      BIGINT
DECLARE @nroRegistros BIGINT 
DECLARE @timestampReg DATETIME

-- ================= NFe_Out

SELECT TOP 1 @pkeyInicial = pKeyInicial, @pkeyFinal = pKeyFinal, @timestampReg = timestampReg
  FROM [NFe_Out].[Extracao].[HistoricoExtracaoDW] (NOLOCK)
 ORDER BY timestampReg DESC

SELECT @nroRegistros = COUNT(1)
  FROM [NFe_Out].[NFeOut].[Protocolo] (NOLOCK)
 WHERE pkey >= @pkeyInicial
   AND pkey <= @pkeyFinal

SELECT @pkeyMax = MAX(pkey)
  FROM [NFe_Out].[NFeOut].[Protocolo] (NOLOCK)
 WHERE [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE())

SELECT @timestampReg as DataUltimaExtracao_NFeOut, @pKeyInicial as pKeyInicial, @pKeyFinal as pKeyFinal, 
	   FORMAT((@pKeyFinal - @pKeyInicial),'##,#') as Range, FORMAT(@nroRegistros, '##,#') as NroRegistros,
	   FORMAT(@pkeyMax - @pkeyFinal, '##,#') as NroRegistrosASeremProcessadosProximaCarga

-- ================= NFe_Out_UFs

SELECT TOP 1 @pkeyInicial = pKeyInicial, @pkeyFinal = pKeyFinal, @timestampReg = timestampReg
  FROM [NFe_Out_UFs].[Extracao].[HistoricoExtracaoDW] (NOLOCK)
 ORDER BY timestampReg DESC

SELECT @nroRegistros = COUNT(1)
  FROM [NFe_Out_UFs].[NFeUFs].[DFeRecebimento] (NOLOCK)
 WHERE id >= @pkeyInicial
   AND id <= @pkeyFinal

SELECT @pkeyMax = MAX(id)
  FROM [NFe_Out_UFs].[NFeUFs].[DFeRecebimento] (NOLOCK)
  WHERE id >= @pkeyInicial

SELECT @timestampReg as DataUltimaExtracao_Ouf_UFs, @pKeyInicial as pKeyInicial, @pKeyFinal as pKeyFinal, 
	   FORMAT((@pKeyFinal - @pKeyInicial),'##,#') as Range, FORMAT(@nroRegistros, '##,#') as NroRegistros, 
	   FORMAT(@pkeyMax - @pkeyFinal, '##,#') as NroRegistrosASeremProcessadosProximaCarga

-- Andamento

SELECT count(1)
  FROM [NFe_Out].[Extracao].[DadosNFeQueue] (nolock) -- 2443113

SELECT count(1)
  FROM [NFe_Out].[Extracao].[DadosInutNFeQueue] (nolock)

SELECT count(1)
  FROM [NFe_Out].[Extracao].[DadosEventoQueue] (nolock)

SELECT count(1)
  FROM [NFe_Out].[Extracao].[DadosCancNFeQueue] (nolock)

SELECT count(1)
  FROM [NFe_Out_UFs].[Extracao].[DadosNFeQueue] (nolock)

SELECT count(1)
  FROM [NFe_Out_UFs].[Extracao].[DadosEventoQueue] (nolock) --928092

SELECT count(1)
  FROM [NFe_Out_UFs].[Extracao].[DadosCancNFeQueue] (nolock)