use NFe_Out_UFs
go

select datepart(day, timestampRecebimento), count(1)
from [NFe_Out_UFs].NFeEventos.[IntegraEvento] ie (nolock)
where nsu > 100 and timestampRecebimento between '2020-07-05' and '2020-07-06'
group by datepart(day, timestampRecebimento)



select tpEvento, count(1)
from [NFe_Out_UFs].NFeEventos.[Evento] ie (nolock)
where pKey > 1480000000 and timestampReg between '2020-07-05' and '2020-07-06'
group by tpEvento
order by count(1) desc

select top 10 timestampReg from [NFe_Out_UFs].NFeEventos.[Evento] ie (nolock) where pKey > 1434600000  --1480000000 Jul

select datepart(day, timestampReg), count(1)
from [NFe_Out_UFs].NFeEventos.[Evento] ie (nolock)
where pKey > 1480000000 and timestampReg > '2020-07-01'
group by datepart(day, timestampReg)

select datepart(MONTH, timestampReg), datepart(day, timestampReg), count(1)
from [NFe_Out_UFs].NFeEventos.[Evento] ie (nolock)
where pKey > 1434600000 and timestampReg > '2020-06-01' and timestampReg < '2020-07-01'
group by datepart(MONTH, timestampReg), datepart(day, timestampReg)



select tpEvento, count(1)
from [NFe_Out_UFs].NFeEventos.[Evento] e (nolock)
join [NFe_Out_UFs].NFeEventos.[IntegraEvento] ie (nolock)
on ie.pkeyEvento = e.pKey
where pKey > 1480000000 and nsu > 100 and timestampRecebimento between '2020-07-05' and '2020-07-06'
group by tpEvento



select datepart(day, timestampRecebimento), count(1)
from [NFe_Out_UFs].NFeEventos.[Evento] e (nolock)
join [NFe_Out_UFs].NFeEventos.[IntegraEvento] ie (nolock)
on ie.pkeyEvento = e.pKey
where pKey > 1434600000 and nsu > 100 and timestampRecebimento between '2020-06-01' and '2020-07-01' and tpEvento in (610614, 610554)
group by datepart(day, timestampRecebimento)


use NFe_Out
go

select datepart(day, timestampReg), count(1)
from [NFe_Out].NFeEventos.[Evento] ie (nolock)
where NFe_Out.$partition.PF_Part_02_Data(timestampReg) = NFe_Out.$partition.PF_Part_02_Data('2020-06-01') 
group by datepart(day, timestampReg)

select datepart(day, timestampRecebimento), count(1) from [NFe_Out].[NFeIntegra].[IntegraEvento] (NOLOCK)
where NFe_Out.$partition.PF_Part_02_Data(timestampRecebimento) = NFe_Out.$partition.PF_Part_02_Data('2020-07-01') 
group by datepart(day, timestampRecebimento)