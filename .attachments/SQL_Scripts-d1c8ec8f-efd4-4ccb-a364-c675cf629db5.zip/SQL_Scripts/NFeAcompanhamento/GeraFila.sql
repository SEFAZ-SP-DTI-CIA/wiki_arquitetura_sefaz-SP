USE NFe_Out
GO

-- Fila criada pela autoriza��o e consumida no GeraFila
SELECT '' as '[NFeIntegra].[ProtocoloNFeQueue]', count(1)
  FROM [NFeIntegra].[ProtocoloNFeQueue] (NOLOCK)
SELECT top 50 '' as '[NFeIntegra].[ProtocoloNFeQueue]', *
  FROM [NFeIntegra].[ProtocoloNFeQueue] (NOLOCK) --where fkProtocolo = 188998442
  ORDER BY pKey DESC

-------------------------------------------------------------
USE DB_NFeIntegra
GO 

-- Log de erro
SELECT TOP 100 '' AS '[NFeEnvio].[LogGeraFila]', * 
  FROM [NFeEnvio].[LogGeraFila] (NOLOCK)
ORDER BY pKey DESC

-- Autoriza��o/inutiliza��o/cancelamento enfileirados
SELECT '' AS '[NFeEnvio].[ProtocoloNFe_Queue]', COUNT(1)
  FROM [NFeEnvio].[ProtocoloNFe_Queue] (NOLOCK)
SELECT TOP 500 '' AS '[NFeEnvio].[ProtocoloNFe_Queue]', * 
  FROM [NFeEnvio].[ProtocoloNFe_Queue] (NOLOCK)

SELECT '' AS '[NFeEnvio].[ProtocoloNFe]', COUNT(1) 
  FROM [NFeEnvio].[ProtocoloNFe]  (NOLOCK)
SELECT TOP 500 '' AS '[NFeEnvio].[ProtocoloNFe]', * 
  FROM [NFeEnvio].[ProtocoloNFe]  (NOLOCK) ORDER BY pkey DESC

-- Eventos enfileirados
SELECT '' AS '[NFeEventos].[Evento_Envio_Queue]', COUNT(1)
  FROM [NFeEventos].[Evento_Envio_Queue] (NOLOCK)
SELECT TOP 50 '' AS '[NFeEventos].[Evento_Envio_Queue]', *
  FROM [NFeEventos].[Evento_Envio_Queue] (NOLOCK)

SELECT '' AS '[NFeEventos].[Evento]', COUNT(1) 
  FROM [NFeEventos].[Evento] (NOLOCK)
SELECT TOP 500 '' AS '[NFeEventos].[Evento]', EVT_DT_TIMESTAMP_REG, * 
  FROM [NFeEventos].[Evento] (NOLOCK) ORDER BY EVT_CD_EVENTO DESC

SELECT TOP 500 '' AS '[NFeEventos].[Evento_XML]', * 
  FROM [NFeEventos].[Evento_XML] (NOLOCK) ORDER BY EVT_CD_EVENTO DESC

RETURN
-- Configura��o
SELECT *
  FROM [dbo].[CONFIGURACAO] c (NOLOCK)
 INNER JOIN [dbo].[CONFIGURACAO_TIPO] ct (NOLOCK)
    ON c.CONFIGURACAO_CD_TIPO = ct.CONFIGURACAO_CD_TIPO
 WHERE CONF_TX_SERVICO = 'NFeGeraFila'
--  OR  CONF_TX_SERVICO IS NULL

-- Chaves de notas que est�o sendo enviadas
SELECT n.chNFe, * 
  FROM      [NFeEnvio].[ProtocoloNFe_Queue] q (NOLOCK)
INNER JOIN  [NFeEnvio].[ProtocoloNFe]       p (NOLOCK)
   ON q.pkey = p.pkey
INNER JOIN  [NFe_Out].[NFeOut].[NFe] n (NOLOCK)
   ON p.fkprotocolo = n.pkey