USE DB_NFeIntegra
GO

-- Controle do Protocolo Faltante. Lembrete: se a fila estiver com > 100.000, o Protocolos Faltantes roda em falso.
SELECT '' as '[dbo].[ULTIMO_PROTOCOLO_FALTANTE]', * --135190582615477
  FROM [dbo].[ULTIMO_PROTOCOLO_FALTANTE] (nolock)   --

PRINT ('')
GO
-- Registros dos Protocolos Faltantes (atual e hist�rico)
SELECT TOP 10 '' as '[dbo].[PROTOCOLOS_FALTANTES]', PROT_DT_TIMESTAMP_REG, * 
  FROM [dbo].[PROTOCOLOS_FALTANTES] (nolock)

SELECT TOP 100 '' as '[dbo].[PROTOCOLOS_FALTANTES_HISTORICO]', PROT_DT_TIMESTAMP_REG, * 
  FROM [dbo].[PROTOCOLOS_FALTANTES_HISTORICO] (nolock)
 ORDER BY PROT_CD_PROTOCOLOS_FALTANTES DESC

PRINT ('')
GO
-- Log dos Protocolos Faltantes - todos
SELECT TOP 1000 '' as '[dbo].[LOG_PROTOCOLOS_FALTANTES]', LPRF_DT_TIMESTAMP, LPRF_CD_LOG_PROT_FALT, LPRF_VL_PROT_LIMITE, LPRF_VL_N_PROT_INI, LPRF_VL_N_PROT_PESQ, LPRF_QN_RANGES, LPRF_VL_CSTAT, LPRF_TX_XMOTIVO, LPRF_TX_ERRO, CONVERT(XML, LPRF_TX_XML_Request) as Req, CONVERT(XML, LPRF_TX_XML_Response) as Resp, * 
  FROM [dbo].[LOG_PROTOCOLOS_FALTANTES] p (nolock)
 --WHERE LPRF_DT_TIMESTAMP < '2018-01-03'
 --  AND LPRF_DT_TIMESTAMP > '2018-01-01' 
 ORDER BY p.LPRF_CD_LOG_PROT_FALT DESC

PRINT ('')
GO
-- Log dos Protocolos Faltantes - exceto 115 (existem protocolos faltantes) e 114 (nenhum protocolo faltante)
SELECT TOP 10 '' as '[dbo].[LOG_PROTOCOLOS_FALTANTES] exceto115_114', LPRF_DT_TIMESTAMP, *, CONVERT(XML, LPRF_TX_XML_Request) as Req, CONVERT(XML, LPRF_TX_XML_Response) as Resp 
  FROM [dbo].[LOG_PROTOCOLOS_FALTANTES] (nolock)
 WHERE LPRF_VL_CSTAT NOT IN (115,114)
 ORDER BY LPRF_CD_LOG_PROT_FALT DESC

PRINT ('')
GO
-- Logs gerais
SELECT TOP 20 '' as '[dbo].[LOG_XML]', LOXM_DT_Timestamp, *, CONVERT(XML, LOXM_TX_XML_Request) as Req, CONVERT(XML, LOXM_TX_XML_Response) as Resp 
  FROM [dbo].[LOG_XML] l (nolock) 
 ORDER BY l.LOXM_DT_Timestamp DESC

PRINT ('')
GO
-- Fila do Envio, preenchida pelo GeraFila
SELECT '' as '[NFeEnvio].[ProtocoloNFe_Queue]', count(1) 
  FROM [NFeEnvio].[ProtocoloNFe_Queue] (nolock)
SELECT TOP 5 '' as '[NFeEnvio].[ProtocoloNFe_Queue]', *
  FROM [NFeEnvio].[ProtocoloNFe_Queue] (nolock)

PRINT ('')
GO

RETURN 
------------------------------------------------------------------
-- Procura de um protocolo espec�fico em Protocolos Faltantes
DECLARE @PROT_NR_PROTOCOLO     BIGINT = 515140808
DECLARE @PROT_NR_ANO_PROTOCOLO INT = 19

SELECT * 
  FROM [DB_NFeIntegra].[dbo].[PROTOCOLOS_FALTANTES] (nolock)
 WHERE PROT_NR_PROTOCOLO     = @PROT_NR_PROTOCOLO
   AND PROT_NR_ANO_PROTOCOLO = @PROT_NR_ANO_PROTOCOLO

SELECT * 
  FROM [DB_NFeIntegra].[dbo].[PROTOCOLOS_FALTANTES_HISTORICO] (nolock)
 WHERE PROT_NR_PROTOCOLO     = @PROT_NR_PROTOCOLO
   AND PROT_NR_ANO_PROTOCOLO = @PROT_NR_ANO_PROTOCOLO

DECLARE @LIKE_PATTERN VARCHAR(12) = '%' + CONVERT(varchar, @PROT_NR_PROTOCOLO) + '%'

SELECT top 10 *, CONVERT(XML, LPRF_TX_XML_Request) as Req, CONVERT(XML, LPRF_TX_XML_Response) as Resp 
  FROM [DB_NFeIntegra].[dbo].[LOG_PROTOCOLOS_FALTANTES] (nolock)
 WHERE LPRF_DT_TIMESTAMP > '2019-07-18'
   AND LPRF_TX_XML_Response like @LIKE_PATTERN

------------------------------------------------------------------
-- Verificar se um protocolo espec�fico foi autorizado
DECLARE @ANO INT = 18
DECLARE @PROTOCOLO INT = 13769288

SELECT *
FROM [NFe_Out].[NFeOut].[Protocolo] p (nolock)
WHERE p.ufProtocolo = 35
  AND p.anoProtocolo = @ANO
  and p.nroProtocolo = @PROTOCOLO

-- verificar nsu do protocolo
SELECT n.*
FROM [NFe_Out].[NFeOut].[Protocolo] p (nolock)
INNER JOIN [NFe_Out].[NFeIntegra].[IntegraNSU] n (nolock)
ON p.pKey = n.fkProtocolo
WHERE p.ufProtocolo = 35
  AND p.anoProtocolo = @ANO
  and p.nroProtocolo = @PROTOCOLO

SELECT *
FROM [DB_NFeIntegra].[NFeEnvio].[ProtocoloRecebido] (nolock)
WHERE ufProtocolo = 35
AND   anoProtocolo = @ANO
and nroProtocolo = @PROTOCOLO

------------------------------------------------------------------
-- Procura de buracos na autoriza��o 
SELECT COUNT(1) 
  FROM [NFe_Out].[NFeOut].[Protocolo] (nolock)
 WHERE anoProtocolo = 18
  and idReceptor = 1
  and nroProtocolo between 13769285 and 13769290

------------------------------------------------------------------
/*
-- Atualizar �ltimo protocolo faltante
USE DB_NFeIntegra
GO

UPDATE [dbo].[ULTIMO_PROTOCOLO_FALTANTE]
SET UPRF_NR_ULTIMO_PROTOCOLO_FALTANTE = 135190000000000
*/
