USE DB_NFeIntegra
GO
    SET NOCOUNT ON
    --------------- Quantidade de linhas em ProtocoloNFe/_Queue + presos
    SELECT
        (SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEnvio].[ProtocoloNFe]')       AND (indid <= 1)) as  '# ProtocoloNFe', 
        (SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEnvio].[ProtocoloNFe_Queue]') AND (indid <= 1)) as  '# ProtocoloNFe_Queue', 
        (SELECT LEFT(FORMAT(COUNT(1), '#,#', 'pt-br'), 20) FROM [NFeEnvio].[ProtocoloNFe] WITH (NOLOCK) WHERE nroTentativas not in (0, 3)) AS 'Quase PRESOS',
        (SELECT LEFT(FORMAT(COUNT(1), '#,#', 'pt-br'), 20) FROM [NFeEnvio].[ProtocoloNFe] WITH (NOLOCK) WHERE nroTentativas = 3          ) AS 'PRESOS'    
    PRINT ('')
    GO
    --------------- Quantidade de linhas em NFe_Eventos/_Queue + presos
    SELECT 
        (SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEventos].[EVENTO]')                 AND (indid <= 1)) as  '# NFeEventos.EVENTO', 
        (SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEventos].[EVENTO_ENVIO_QUEUE]')     AND (indid <= 1)) as  '# NFeEventos.EVENTO_ENVIO_QUEUE', 
        (SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEventos].[EVENTO_RETORNO_QUEUE]')   AND (indid <= 1)) as  '# NFeEventos.EVENTO_RETORNO_QUEUE', 
      --(SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEventos].[LOG_XML]')                AND (indid <= 1)) as  '# NFeEventos.LOG_XML', 
        (SELECT LEFT(FORMAT(rowcnt, '#,#', 'pt-br'), 20) FROM sys.sysindexes WHERE id = OBJECT_ID('[NFeEventos].[ProtocolosTemp_eventos]') AND (indid <= 1)) as  '# NFeEventos.ProtocolosTemp_eventos', 
        (SELECT LEFT(FORMAT(COUNT(1), '#,#', 'pt-br'), 20) FROM [NFeEventos].[EVENTO] WITH (NOLOCK) WHERE EVT_NR_TENTATIVAS NOT IN (0, 3)) AS 'Quase PRESOS',
        (SELECT LEFT(FORMAT(COUNT(1), '#,#', 'pt-br'), 20) FROM [NFeEventos].[EVENTO] WITH (NOLOCK) WHERE EVT_NR_TENTATIVAS = 3          ) AS 'PRESOS'
    PRINT ('')
    GO
    --------------- Estatisticas para Protocolos
    DECLARE @offset INT = 1
    DECLARE @dataInicio DATETIME = DATEADD(MINUTE, -@offset, GETDATE()) 
    DECLARE @dataFim    DATETIME = GETDATE()
    DECLARE @maxPkeyEstatisticaEnvioProtocolo BIGINT = (SELECT MAX(pkey) FROM [NFeEnvio].[EstatisticaEnvio] WITH (NOLOCK))
    DECLARE @maxPkeyProtocolo BIGINT = (SELECT MAX(pKey)
                                          FROM [NFe_Out].[NFeOut].[Protocolo] p WITH (NOLOCK)
                                         WHERE [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE()))
    
    SELECT SUM(qtdItensLote) as NroNFesEnviadas, AVG(qtdItensLote) as DocsPorLote, AVG(tempoEnvio) as TMedioAN 
      INTO #tmpNumEstatEnvio
      FROM (SELECT qtdItensLote, tempoEnvio
              FROM [NFeEnvio].[EstatisticaEnvio] WITH (NOLOCK)
             WHERE pkey > (@maxPkeyEstatisticaEnvioProtocolo - 1000000)
               AND dataEnvio >= @dataInicio 
               AND dataEnvio <  @dataFim 
           ) as tmpTable1

    SELECT COUNT(1) as NroNFesAutorizadas INTO #tmpNumNFeOut
      FROM (SELECT 1 as HUM
              FROM [NFe_Out].[NFeOut].[NFe] WITH (NOLOCK)
             WHERE pkey > (@maxPkeyProtocolo - 1000000)
               AND timestampReg >= @dataInicio 
               AND timestampReg <  @dataFim    
           ) as tmpTable
     ORDER BY 1
        
    SELECT 'Media nos ultimos ' + CAST(@offset AS VARCHAR(2)) + ' minutos para protocolos' as Valor, EE.TMedioAN, 
           EE.DocsPorLote, NFO.NroNFesAutorizadas, EE.NroNFesEnviadas, 
           NFO.NroNFesAutorizadas - EE.NroNFesEnviadas as 'Entrada - Saida (+ aumenta a fila, - diminui a fila' 
      FROM      #tmpNumEstatEnvio EE WITH (NOLOCK)
     INNER JOIN #tmpNumNFeOut     NFO
        ON 1=1

    DROP TABLE #tmpNumEstatEnvio
    DROP TABLE #tmpNumNFeOut

    PRINT ('')
    GO
    --------------- Fazendo estatisticas para NFeEventos
    DECLARE @offset INT = 1
    DECLARE @dataInicio DATETIME = DATEADD(MINUTE, -@offset, GETDATE()) 
    DECLARE @dataFim    DATETIME = GETDATE()
    DECLARE @maxPkeyEstatisticaEnvioEvento BIGINT = (SELECT MAX(ESWE_CD_ESTATISTICA_WEBSERVICE) FROM [dbo].[ESTATISTICA_ENVIO] WITH (NOLOCK))
    DECLARE @maxPkeyProtocolo BIGINT = (SELECT MAX(pKey)
                                          FROM [NFe_Out].[NFeOut].[Protocolo] p WITH (NOLOCK)
                                         WHERE [NFe_Out].$partition.PF_Part_02_Data(timestampReg) = [Nfe_Out].$partition.PF_Part_02_Data(GETDATE()))
    
    SELECT SUM(Lotes) as NroEventosEnviados, AVG(Lotes) as DocsPorLote, AVG(TempoAN) as TMedioAN INTO #tmpNumEstatEnvioEventos
    FROM (SELECT ESWE_QN_ITENS_LOTE as Lotes, 
                 ESWE_QN_TEMPO_ENVIO as TempoAN
            FROM [dbo].[ESTATISTICA_ENVIO] WITH (NOLOCK)
           WHERE ESWE_CD_ESTATISTICA_WEBSERVICE > (@maxPkeyEstatisticaEnvioEvento - 1000000)
             AND ESWE_DT_ENVIO >= @dataInicio 
             AND ESWE_DT_ENVIO <  @dataFim
             AND [CONF_TX_SERVICO] = 'NFeEnvioEventos'
         ) as tmpTable1
        
    SELECT COUNT(1) as NroEventosAutorizados INTO #tmpNumNFeEventos
    FROM (SELECT 1 as HUM
            FROM [NFe_Out].[NFeOut].[Protocolo] WITH (NOLOCK)
           WHERE pkey > (@maxPkeyProtocolo - 1000000)
             AND timestampReg >= @dataInicio 
             AND timestampReg <  @dataFim
             AND tpDocumento = 2
             AND idReceptor = 1
         ) as tmpTable
    ORDER BY 1
              
    SELECT 'Media nos últimos ' + CAST(@offset AS VARCHAR(2)) + ' minutos para eventos' as Valor, tMedioAN, 
           EE.DocsPorLote, NFO.NroEventosAutorizados, EE.NroEventosEnviados, 
           NFO.NroEventosAutorizados - EE.NroEventosEnviados as 'Entrada - Saida (+ aumenta a fila, - diminui a fila)' 
      FROM      #tmpNumEstatEnvioEventos EE WITH (NOLOCK)
     INNER JOIN #tmpNumNFeEventos     NFO
        ON 1=1    

    DROP TABLE #tmpNumEstatEnvioEventos
    DROP TABLE #tmpNumNFeEventos

    PRINT ('')
    GO
    --------------- Tempo de resposta medio de Protocolos nas ultimas N horas
    DECLARE @N INT = 4
    DECLARE @maxPkeyEstatisticaEnvioProtocolo BIGINT = (SELECT MAX(pkey) FROM [NFeEnvio].[EstatisticaEnvio] WITH (NOLOCK))
    SELECT * FROM (SELECT cast(DATENAME(hour, dataEnvio) as int) as Hora_Envio_Protocolo, AVG(tempoEnvio) AS 'Média tempo de resposta',  AVG(qtdItensLote) AS 'Nro itens médio lote'
                     FROM [NFeEnvio].[EstatisticaEnvio] WITH (NOLOCK)
                    WHERE pkey > (@maxPkeyEstatisticaEnvioProtocolo - 1000000)
                      AND dataEnvio BETWEEN DATEADD(HOUR, -@N, GETDATE()) AND GETDATE()
                    GROUP BY cast(DATENAME(hour, dataEnvio) as int)) TAB
     ORDER BY TAB.Hora_Envio_Protocolo DESC

    PRINT ('')
    GO
    --------------- Tempo de resposta medio de Eventos nas ultimas N horas
    DECLARE @N INT = 4
    DECLARE @maxPkeyEstatisticaEnvioEvento BIGINT = (SELECT MAX(ESWE_CD_ESTATISTICA_WEBSERVICE) FROM [dbo].[ESTATISTICA_ENVIO] WITH (NOLOCK))
    SELECT * FROM (SELECT cast(DATENAME(hour, ESWE_DT_ENVIO) as int) as Hora_Envio_Evento, AVG(ESWE_QN_TEMPO_ENVIO) AS 'Média tempo de resposta', AVG(ESWE_QN_ITENS_LOTE) AS 'Nro itens médio lote'
                     FROM [dbo].[ESTATISTICA_ENVIO] WITH (NOLOCK)
                    WHERE ESWE_CD_ESTATISTICA_WEBSERVICE > (@maxPkeyEstatisticaEnvioEvento - 1000000)
                      AND ESWE_DT_ENVIO BETWEEN DATEADD(HOUR, -@N, GETDATE()) AND GETDATE()
                    GROUP BY cast(DATENAME(hour, ESWE_DT_ENVIO) as int)) TAB
     ORDER BY TAB.Hora_Envio_Evento DESC

    PRINT ('')
    GO
    --------------- Nro protocolos enviados na ultima hora
    DECLARE @dataInicio DATETIME = DATEADD(HOUR, -1, GETDATE()) 

    SELECT FORMAT(SUM(qtdItensLote), '#,#', 'pt-br') as ProtocolosEnviadosNaUltimaHora
      FROM [NFeEnvio].[EstatisticaEnvio] (nolock)
     WHERE dataEnvio > @dataInicio

    PRINT ('')
    GO
    --------------- Nro Eventos enviados na ultima hora
    DECLARE @dataInicio DATETIME = DATEADD(HOUR, -1, GETDATE()) 

    SELECT FORMAT(SUM(ESWE_QN_ITENS_LOTE), '#,#', 'pt-br') as EventosEnviadosNaUltimaHora
    FROM [dbo].[ESTATISTICA_ENVIO] (NOLOCK)
    WHERE ESWE_DT_ENVIO > @dataInicio

    PRINT ('')
    GO
    --------------- Atraso do ultimo protocolo enviado
    DECLARE @cd_protocolo AS BIGINT
    DECLARE @tsProtocoloRecebido AS DATETIME
    DECLARE @tsProtocoloNFe AS DATETIME
    DECLARE @idNFe AS VARCHAR(44)

    SELECT @cd_protocolo = MAX(pkey) 
      FROM [NFeEnvio].[ProtocoloRecebido] WITH (NOLOCK)
     WHERE [DB_NFeIntegra].$partition.PF_Part_01_Data(timestampReg) = [DB_NFeIntegra].$partition.PF_Part_01_Data(getdate())

    SELECT @tsProtocoloRecebido = timestampReg, @idNFe=chNFe 
      FROM [NFeEnvio].[ProtocoloRecebido] WITH (NOLOCK)
     WHERE pkey = @cd_protocolo

    SELECT TOP 1 @tsProtocoloNFe = timestampReg 
      FROM [NFE_Out].[NFeOut].[NFe] WITH (NOLOCK)
     WHERE chNFe = @idNFe

    SELECT CONVERT(varchar(10), (@tsProtocoloRecebido - @tsProtocoloNFe), 8) as 'Atraso Ultimo protocolo enviado'

    PRINT ('')
    GO
    --------------- Atraso do ultimo evento enviado
    DECLARE @cd_evento AS BIGINT
    DECLARE @tsEventoRecebido AS DATETIME
    DECLARE @tsEventoNFe AS DATETIME
    DECLARE @idNFe AS VARCHAR(44)

    SELECT @cd_evento = MAX(EVT_CD_EVENTO) 
      FROM [NFeEventos].[EVENTO_RECEBIDO] WITH (NOLOCK)
     WHERE [DB_NFeIntegra].$partition.PF_Part_01_Data(EVT_DT_TIMESTAMP_REG) = [DB_NFeIntegra].$partition.PF_Part_01_Data(getdate())

    SELECT @tsEventoRecebido = EVT_DT_TIMESTAMP_REG, @idNFe=EVT_CD_CH_NFE 
      FROM [NFeEventos].[EVENTO_RECEBIDO] WITH (NOLOCK)
     WHERE EVT_CD_EVENTO = @cd_evento

    SELECT TOP 1 @tsEventoNFe = timestampReg 
      FROM [NFE_Out].[NFeEventos].[Evento_Constraint] WITH (NOLOCK)
     WHERE chNFe = @idNFe

    SELECT CONVERT(varchar(10), (@tsEventoRecebido - @tsEventoNFe), 8) as 'Atraso Ultimo evento enviado'

    PRINT ('')
    GO
    --------------- Timestamp protocolo + antigo e mais recente na tabela ProtocoloNFe_Queue
    DECLARE @dataInicio DATETIME, @dataFim DATETIME

    SELECT  @dataInicio = MIN(dataModificado), @dataFim = MAX(dataModificado)
      FROM [NFeEnvio].[ProtocoloNFe_Queue] WITH (NOLOCK)        

    SELECT CONVERT(varchar(20), @dataInicio, 113) AS 'Mais antigo [ProtocoloNFe_Queue]',  
           CONVERT(varchar(20), @dataFim   , 113) AS 'Mais recente [ProtocoloNFe_Queue]', 
           CONVERT(varchar(4), DateDiff(hh, @dataInicio, @dataFim)/24, 120) + 'd ' + CONVERT(varchar(20),(@dataFim - @dataInicio),108) AS 'Diferenca'

    PRINT ('')
    GO
    --------------- Timestamp protocolo + antigo e mais recente na tabela ProtocoloNFe
    DECLARE @dataInicio DATETIME, @dataFim DATETIME

    SELECT @dataInicio = MIN(timestampReg), @dataFim = MAX(timestampReg)
      FROM [NFeEnvio].[ProtocoloNFe] WITH (NOLOCK)        

    SELECT CONVERT(varchar(20), @dataInicio, 113) AS 'Mais antigo [ProtocoloNFe]',  
           CONVERT(varchar(20), @dataFim   , 113) AS 'Mais recente [ProtocoloNFe]', 
           CONVERT(varchar(4), DateDiff(hh, @dataInicio, @dataFim)/24, 120) + 'd ' + CONVERT(varchar(20),(@dataFim - @dataInicio),108) AS 'Diferenca'

    PRINT ('')
    GO
    --------------- Timestamp evento + antigo e mais recente na tabela EVENTO_ENVIO_QUEUE
    DECLARE @dataInicio DATETIME, @dataFim DATETIME

    SELECT @dataInicio = MIN(EVT_DT_MODIFIED), @dataFim = MAX(EVT_DT_MODIFIED)
      FROM [NFeEventos].[EVENTO_ENVIO_QUEUE] WITH (NOLOCK)        

    SELECT CONVERT(varchar(20), @dataInicio, 113) AS 'Mais antigo [EVENTO_ENVIO_QUEUE]',  
           CONVERT(varchar(20), @dataFim   , 113) AS 'Mais recente [EVENTO_ENVIO_QUEUE]', 
           CONVERT(varchar(4), DateDiff(hh, @dataInicio, @dataFim)/24, 120) + 'd ' + CONVERT(varchar(20),(@dataFim - @dataInicio),108) AS 'Diferenca'

    PRINT ('') 
    GO
    --------------- Timestamp protocolo + antigo e mais recente na tabela EVENTO
    DECLARE @dataInicio DATETIME, @dataFim DATETIME

    SELECT @dataInicio = MIN(EVT_DT_TIMESTAMP_REG), @dataFim = MAX(EVT_DT_TIMESTAMP_REG)
      FROM [NFeEventos].[EVENTO] WITH (NOLOCK)        

    SELECT CONVERT(varchar(20), @dataInicio, 113) AS 'Mais antigo [EVENTO]',  
           CONVERT(varchar(20), @dataFim   , 113) AS 'Mais recente [EVENTO]', 
           CONVERT(varchar(4), DateDiff(hh, @dataInicio, @dataFim)/24, 120) + 'd ' + CONVERT(varchar(20),(@dataFim - @dataInicio),108) AS 'Diferenca'

    PRINT ('') 
    GO
    --------------- Protocolos Rejeitados 
    SELECT COUNT (1) as Protocolos_Rejeitados_No_Dia
      FROM [NFeEnvio].[ProtocoloRejeitado]
     WHERE timestampIntegra > CAST(GETDATE() AS DATE)
    PRINT ('') 
    GO
    --------------- Eventos Rejeitados 
    SELECT COUNT (1) as Eventos_Rejeitados_No_Dia
      FROM [NFeEventos].[Evento_Rejeitado]
     WHERE EVT_DT_TIMESTAMP_REG > CAST(GETDATE() AS DATE)
    PRINT ('') 
    GO
    --------------- Erros de protocolo nas ultimas horas
    DECLARE @duasHorasAtras DATETIME = DATEADD(MINUTE, -120, GETDATE()) 
    DECLARE @maxPkeyLogXML BIGINT = (SELECT MAX(pKey) FROM [NFeEnvio].[LogXML] WITH (NOLOCK))

    ;WITH CTE AS
    (SELECT pkey, timestampReg, CASE WHEN erro like 'Protocolo: %' THEN SUBSTRING(erro, 29, LEN(erro)-29) 
                                     ELSE erro
                                END as erro
      FROM [NFeEnvio].[LogXML] WITH (NOLOCK)
     WHERE timestampReg > @duasHorasAtras
       AND pKey > (@maxPkeyLogXML - 1000000)
    )
   
   SELECT COUNT(1) AS QTD_PROTOCOLS, MIN(timestampReg) AS PRIMEIRA, MAX(timestampReg) AS ULTIMA, erro as 'Erro protocolos'
     FROM CTE WITH (NOLOCK)
    WHERE timestampReg > @duasHorasAtras
      AND pKey > (@maxPkeyLogXML - 1000000)
     GROUP BY erro    
     ORDER BY MAX(timestampReg) desc

    PRINT ('')
    GO
    --------------- Erros de eventos nas ultimas horas
    DECLARE @duasHorasAtras DATETIME = DATEADD(MINUTE, -120, GETDATE()) 
    DECLARE @maxPkeyLogEventosXML BIGINT = (SELECT MAX(LOXM_CD_XML) FROM [NFeEventos].[LOG_XML] WITH (NOLOCK))

    SELECT COUNT(1) AS QTD_EVENTOS, MIN(LOXM_DT_Timestamp) AS PRIMEIRA, MAX(LOXM_DT_Timestamp) AS ULTIMA, LOXM_TX_Erro as 'Erro eventos'
      FROM [NFeEventos].[LOG_XML] WITH (NOLOCK)
     WHERE LOXM_DT_Timestamp >= @duasHorasAtras 
       AND LOXM_CD_XML > (@maxPkeyLogEventosXML - 1000000)
     GROUP BY LOXM_TX_Erro    
     ORDER BY MAX(LOXM_DT_Timestamp) desc
    
    PRINT ('')
    GO