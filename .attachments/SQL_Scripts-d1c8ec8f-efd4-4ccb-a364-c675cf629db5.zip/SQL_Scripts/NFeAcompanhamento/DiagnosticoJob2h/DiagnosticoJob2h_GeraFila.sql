USE [NFe_Out]
GO
    SET NOCOUNT ON 

    SELECT '' as '[NFe_Out].[NFeIntegra].[ProtocoloNFeQueue]', LEFT(FORMAT(COUNT(1), '#,#', 'pt-br'), 20)
      FROM [NFeIntegra].[ProtocoloNFeQueue] WITH (NOLOCK)
    
    PRINT('')
    GO

USE [DB_NFeIntegra]
GO 
    SET NOCOUNT ON 
    DECLARE @duasHorasAtras DATETIME = DATEADD(MINUTE, -120, GETDATE()) 
    DECLARE @maxPkeyLogGeraFila BIGINT = (SELECT MAX(pkey) FROM [NFeEnvio].[LogGeraFila] WITH (NOLOCK))

    SELECT LEFT(FORMAT(COUNT(1), '#,#', 'pt-br'), 20) AS QTD, MIN(timestampReg) AS PRIMEIRA, MAX(timestampReg) AS ULTIMA, CAST(erro as VARCHAR(100)) as 'Erro eventos'
      FROM [NFeEnvio].[LogGeraFila] WITH (NOLOCK)
     WHERE timestampReg >= @duasHorasAtras 
       AND pkey         > (@maxPkeyLogGeraFila - 100)
     GROUP BY CAST(erro as VARCHAR(100))    
     ORDER BY MAX(timestampReg) desc
     
     PRINT('')
     GO