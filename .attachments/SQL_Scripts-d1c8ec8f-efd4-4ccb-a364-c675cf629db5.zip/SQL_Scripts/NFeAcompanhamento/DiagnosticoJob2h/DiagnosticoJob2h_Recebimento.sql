USE [NFe_Out_UFs]
GO 
    SET NOCOUNT ON

    SELECT CAST(CONF_TX_VALUE as VARCHAR(20)) as 'NSU_INICIAL'
      FROM      [DB_NFeIntegra].[dbo].[CONFIGURACAO] c
     INNER JOIN [DB_NFeIntegra].[dbo].[CONFIGURACAO_TIPO] ct
        ON c.CONFIGURACAO_CD_TIPO = ct.CONFIGURACAO_CD_TIPO
     WHERE CONF_TX_SERVICO = 'NFeRecebimento'
       AND CONFIGURACAO_DS_TIPO = 'NSU_INICIAL'

    PRINT('')
    GO

    DECLARE @filaTotal BIGINT = (SELECT COUNT(1)
                                   FROM [dbo].[LOG_XML_QUEUE] WITH (NOLOCK))
    DECLARE @filaFlag0 BIGINT = (SELECT COUNT(1)
                                   FROM [dbo].[LOG_XML_QUEUE] WITH (NOLOCK)
                                  WHERE LOXM_FL_READ = 0)
    DECLARE @filaFlag1 BIGINT = (SELECT COUNT(1)
                                   FROM [dbo].[LOG_XML_QUEUE] WITH (NOLOCK)
                                  WHERE LOXM_FL_READ = 1)
    SELECT @filaTotal as 'Total fila', @filaFlag0 as 'flag = 0', @filaFlag1 as 'flag = 1'
    PRINT('')
    GO

    DECLARE @dataProtocoloMaisRecente DATETIME = (SELECT top 1 timestampReg
                                                    FROM [NFe_Out_UFs].[dbo].[ProtocoloNFe] p WITH (NOLOCK)
                                                   WHERE [NFe_Out_UFs].$Partition.PF_Part_01_Data_2(p.timestampRecebimento) = 
                                                         [NFe_Out_UFs].$Partition.PF_Part_01_Data_2(GETDATE())   
                                                   ORDER BY p.nsu DESC)
    DECLARE @atrasoAutorizacaoDoProtocoloMaisRecenteEmMinutos FLOAT = DATEDIFF(MINUTE, @DataProtocoloMaisRecente, GETDATE());
    SELECT  @atrasoAutorizacaoDoProtocoloMaisRecenteEmMinutos             as 'Minutos entre o dado mais antigo recebido e agora', 
            @atrasoAutorizacaoDoProtocoloMaisRecenteEmMinutos / 60        as 'Horas entre o dado mais antigo recebido e agora',
            @atrasoAutorizacaoDoProtocoloMaisRecenteEmMinutos / (24 * 60) as 'Dias entre o dado mais antigo recebido e agora'
    PRINT('')
    GO

    DECLARE @maxPkeyRegistroLoteErro BIGINT = (SELECT MAX(pkey) FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] WITH (NOLOCK))
    DECLARE @duasHorasAtras          DATETIME = DATEADD(HOUR, -2, GETDATE()) 

    SELECT COUNT(1) as NroRegistrosRecebidosEmParticaoReadOnly
      FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] WITH (NOLOCK)
     WHERE pkey         > @maxPkeyRegistroLoteErro - 100000
       AND timestampReg > @duasHorasAtras
       AND erro NOT LIKE '125 NSU consultado nao existe no Ambiente Nacional%'
       AND erro NOT LIKE 'Tipo de Evento%'
       AND erro NOT LIKE '%Timeout%'
       AND stackTrace IS NOT NULL