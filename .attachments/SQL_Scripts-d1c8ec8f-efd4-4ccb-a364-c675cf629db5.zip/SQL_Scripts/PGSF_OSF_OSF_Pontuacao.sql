

--Estudo de pontua��o para OSF por solicita��o

select *
from ordem_servico_fiscal
where id_osf = 1057087 --2018 2 eq 1507 

select *
from equipe
join drt
using(id_drt)
where id_equipe = 1507 --DRTC-III eq 61 

select osf.*
FROM 
    TB_PONTUACAO P
    INNER JOIN TB_DOM_TIPO_PONTUACAO DTP ON DTP.ID_TIPO_PONTUACAO = P.ID_TIPO_PONTUACAO
    INNER JOIN (TB_PONTUACAO_TIPO_OSF PTO 
    INNER JOIN (TB_DOM_TIPO_OSF DTO 
    INNER JOIN ORDEM_SERVICO_FISCAL OSF 
    ON OSF.TIPO_OSF = DTO.ID_TIPO_OSF) 
    ON DTO.ID_TIPO_OSF = PTO.ID_TIPO_OSF) 
    ON PTO.ID_PONTUACAO = P.ID_PONTUACAO
 where tipo_osf = 5
 and cd_pontuacao = '4.3'
 and dtc_conclusao is not null
order by dtc_conclusao desc

select *
from pgsf.ordem_servico_fiscal
where num_documento is not null
and id_osf > 1220000


select *
from pgsf.osf_servico_diverso 


select *
from ordem_servico_fiscal
where id_osf = 152622

select *
from ordem_servico_fiscal
left join osf_servico_diverso 
using(id_osf)
where num_osf in ('11000929188', '11000955187')

select *
from tb_dom_tipo_osf
0	Auditoria
1	Apoio
2	Imagem
3	Opera��o
4	Acompanhamento (n�o existe)
5	Servi�os diversos
6	Flagrante Infracional
7	Dilig�ncia OSF
8	Dilig�ncia outros

 FROM 
    TB_PONTUACAO P
    INNER JOIN TB_DOM_TIPO_PONTUACAO DTP ON DTP.ID_TIPO_PONTUACAO = P.ID_TIPO_PONTUACAO
    INNER JOIN (TB_PONTUACAO_TIPO_OSF PTO 
    INNER JOIN (TB_DOM_TIPO_OSF DTO 
    INNER JOIN ORDEM_SERVICO_FISCAL OSF 
    ON OSF.TIPO_OSF = DTO.ID_TIPO_OSF) 
    ON DTO.ID_TIPO_OSF = PTO.ID_TIPO_OSF) 
    ON PTO.ID_PONTUACAO = P.ID_PONTUACAO
  WHERE 
    OSF.ID_OSF = P_ID_OSF
    AND (DTP.IN_RELATAVEL = P_IN_RELATAVEL OR P_IN_RELATAVEL = -1)
    AND DTP.IN_RELACIONADO_OSF = 1
    
    
    
    

select *
from tb_pontuacao_tipo_osf o
join tb_pontuacao p
using(id_pontuacao)
join tb_dom_tipo_osf t
using(id_tipo_osf)
where id_tipo_osf = 7


select *
from ordem_servico_fiscal
join tb_pontuacao_tipo_osf
on tipo_osf = id_tipo_osf
join tb_pontuacao
using(id_pontuacao)
join tb_dom_tipo_osf
using(id_tipo_osf)
where num_osf in ('11000929188', '11000955187')
and cd_pontuacao = '4.3'




-------- Abaixo estudo do tipo 129

select *
from tb_pontuacao
where cd_pontuacao = 'SP - s/ pont'
where id_pontuacao in (128, 386)

select *
from TB_PONTUACAO_RELACIONAMENTO pr
join tb_pontuacao po
using(ID_PONTUACAO)
where po.CD_PONTUACAO = '4.3'


select *
from ordem_servico_fiscal osf
join osf_executante osfe
on osfe.id_osf = osf.ID_OSF
and osf.num_osf in ('01100152179','03001237177')
join osf_servico_diverso osfd
on osfd.id_osf = osf.id_osf
join tb_pontuacao_servico_diverso psd
on psd.ID_SERVICO_DIVERSO = osfd.id_servico_diverso



select dr.nom_drt, eq.nom_equipe, osf.NUM_OSF, osf.DTC_CONCLUSAO, fi.NOM_FISCAL, osf.id_osf
from ordem_servico_fiscal osf
join osf_servico_diverso osfd
on osfd.id_osf = osf.id_osf
and osfd.id_servico_diverso = 129
and osf.tipo_osf = 5--in (5,8)
and osf.dtc_conclusao is not null
join tb_pontuacao_servico_diverso psd
on psd.ID_SERVICO_DIVERSO = osfd.id_servico_diverso
join osf_executante osfe
on osfe.id_osf = osf.ID_OSF
and (osfe.DTC_FIM is null or osfe.DTC_FIM > osf.DTC_CONCLUSAO)
join fiscal fi
on fi.NUM_FISCAL = osfe.NUM_FISCAL
join equipe_membro eqm
on eqm.NUM_FISCAL = osfe.NUM_FISCAL
and eqm.DTC_FIM_MEMBRO is null
join equipe eq
on eq.id_equipe = eqm.ID_EQUIPE
join drt dr
on dr.id_drt = eq.ID_DRT
order by osf.dtc_conclusao desc

select *
from osf_servico_diverso
where id_servico_diverso = 129

select *
from tb_pontuacao_servico_diverso psd
join tb_pontuacao p
on p.id_pontuacao = psd.id_pontuacao
and p.cd_pontuacao = '4.3'