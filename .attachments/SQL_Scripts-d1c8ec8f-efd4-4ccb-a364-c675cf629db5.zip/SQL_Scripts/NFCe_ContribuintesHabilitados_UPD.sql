﻿ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
ADD [tipoCredContribuinte]		TINYINT		  NOT NULL DEFAULT 2
	,[tipoEmissaoContribuinte]	TINYINT		  NOT NULL DEFAULT 1
	,[credVoluntarioHabilitado]	BIT			  NULL
	,[dataCredenciamento]		DATETIME	  NULL

IF Exists(SELECT 1 FROM sys.objects WHERE OBJECT_NAME(OBJECT_ID) LIKE 'CK_ContribuintesHabilitados_indObrig') AND Exists(SELECT 1 FROM sys.objects WHERE OBJECT_NAME(OBJECT_ID) LIKE 'CK_ContribuintesHabilitados_dVigObrig')
BEGIN
	DECLARE @DefaultTipoCredContribuinte AS VARCHAR(500)
	DECLARE @DefaultTipoEmissaoContribuinte AS VARCHAR(500)

	SET @DefaultTipoCredContribuinte = (SELECT object_name(cdefault) AS 'DefaultName'
									 FROM syscolumns
									 WHERE [id] = object_id('[NFCeOut].[ContribuintesHabilitados]')
									 AND [name] = 'tipoCredContribuinte')
								
	SET @DefaultTipoEmissaoContribuinte = (SELECT object_name(cdefault) AS 'DefaultName' 
								 FROM syscolumns
								 WHERE [id] = object_id('[NFCeOut].[ContribuintesHabilitados]')
								 AND [name] = 'tipoEmissaoContribuinte')


	EXEC ('ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
		   DROP CONSTRAINT [CK_ContribuintesHabilitados_dVigObrig]
						   ,[CK_ContribuintesHabilitados_indObrig]
						   ,' + @DefaultTipoCredContribuinte + '
						   ,' + @DefaultTipoEmissaoContribuinte)
END
ELSE
BEGIN
	Print 'Erro'
END		
			 				
GO

ALTER TABLE [NFCeOut].[ContribuintesHabilitados] 
DROP COLUMN [indObrig],[dVigObrig],[suspensa],[ativo]

GO


--ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
--ADD CONSTRAINT DEFAULT GETDATE() FOR timestampReg 

ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
    ADD DEFAULT GETDATE() FOR [timestampReg];

ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
    ADD DEFAULT ((0)) FOR [valorNFeIlimitado];

ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
    ADD DEFAULT ((0)) FOR [ignorarCadesp];


--ALTER TABLE [NFCeOut].[ContribuintesHabilitados]
--DROP CONSTRAINT CK_timestampreg 