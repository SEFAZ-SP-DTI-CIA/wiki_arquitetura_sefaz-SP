select *
from fiscal
where num_fiscal = 250378

select *
from fiscal_origem
where num_fiscal = 250378

select *
from tb_relato_situacao
join tb_dom_situacao_relato
using(id_situacao_relato)
where 
nr_fiscal = 259930
and nr_ano = 2015
and nr_mes = 3
and in_ativo = 1
order by dt_alteracao

select *
from tb_boletim_correcao
where nr_fiscal = 259930
and nr_ano = 2015
and nr_mes = 3

select * from tb_dom_situacao_relato

select *
from equipe
where id_equipe = 871

select *
from fiscal 
where nom_fiscal = 'CAIO MOTA BLANK MACHADO NETTO'