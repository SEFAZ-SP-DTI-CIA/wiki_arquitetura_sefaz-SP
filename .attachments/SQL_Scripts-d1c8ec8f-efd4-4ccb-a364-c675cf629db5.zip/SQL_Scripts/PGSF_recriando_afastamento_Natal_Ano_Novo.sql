select *
from fiscal
where nom_fiscal like 'CARLA%'

 SELECT *
        FROM OSF_FISCAL_DIA OFD
        WHERE
              OFD.NUM_FISCAL = 44092 AND
              OFD.IN_PONTUAVEL IS NOT NULL AND
              OFD.IN_PONTUAVEL <> 0
              order by dtc_execucao desc
             
SELECT *
        FROM OUTRAS_ATIVIDADES OA    
        WHERE
              OA.NUM_FISCAL = 44092 
              AND
              IN_PONTUAVEL IS NOT NULL AND
              IN_PONTUAVEL <> 0 AND
              PR_COEFICIENTE_ATIVIDADE IS NOT NULL AND
              PR_COEFICIENTE_ATIVIDADE <> 0 
              order by dtc_execucao desc


select * from TB_PONTUACAO
where ID_PONTUACAO = 614;

select * from TB_DOM_PONTUACAO_AFASTAMENTO
where ID_PONTUACAO = 614;

select * from TB_PONTOS 
where ID_PONTUACAO = 614;

select * from TB_DOM_TIPO_PONTUACAO
where ID_TIPO_PONTUACAO IN (129,173)

--=============================================================

UPDATE TB_PONTUACAO
SET DT_INICIO_VIGENCIA = TO_DATE('24/12/2018 00:00:01', 'DD/MM/YYYY HH24:MI:SS'),
DT_FIM_VIGENCIA = TO_DATE('04/01/2019 23:59:59', 'DD/MM/YYYY HH24:MI:SS'),
DT_ALTERACAO = SYSDATE,
--ID_TIPO_PONTUACAO = 129/173
WHERE ID_PONTUACAO = 614;

UPDATE TB_PONTOS
SET DT_INICIO_VIGENCIA = TO_DATE('24/12/2018 00:00:01', 'DD/MM/YYYY HH24:MI:SS'),
    DT_FIM_VIGENCIA    = TO_DATE('04/01/2019 23:59:59', 'DD/MM/YYYY HH24:MI:SS'),
    DT_ALTERACAO       = SYSDATE
WHERE ID_PONTUACAO = 614;

COMMIT;

