--------------------------------------------------------------------------------
--verificando como est�...
--------------------------------------------------------------------------------
--1) pontuacao atribuivel a servi�os diversos j� existentes para servi�os 4.3:
select *
from Tb_Pontuacao_Servico_Diverso t1
join tb_pontuacao t2
on t1.id_pontuacao = t2.ID_PONTUACAO
where t2.id_pontuacao = 128



select *
from TB_PONTUACAO_TIPO_OSF
where id_pontuacao = 128

update TB_PONTUACAO_TIPO_OSF 
set id_tipo_osf = 8
where id_pontuacao = 128

select *
from servico_diverso
where id_servico_diverso = 395

select *
from osf_flagrante
where id_servico_diverso in (394, 395)
order by id_osf desc--853184

select *
from tb_pontuacao_relacionamento
where id_pontuacao = 128

select *
from tb_dom_tipo_pontuacao

--2) situa��o atual do banco (procurando exemplos de relatos de item 4.3 com E sem pontua��o..)
--  OSF aberta

select dr.NOM_DRT, eqp.nom_equipe, fis.nom_fiscal, osf.NUM_OSF, osf.id_osf, osf.DTC_CONCLUSAO, osd.*
from ordem_servico_fiscal osf
left join OSF_flagrante osd
on osf.id_osf = osd.ID_OSF
join osf_executante exe
on exe.id_osf = osf.id_osf
join fiscal fis
on fis.num_fiscal = exe.num_fiscal
join equipe eqp
on eqp.id_equipe = osf.ID_EQUIPE
join drt dr
on dr.ID_DRT = eqp.ID_DRT
where 
osd.id_servico_diverso in  (394, 395)
and osf.dtc_conclusao is not null
order by osf.dtc_conclusao desc;

--395 -> Regime Especial -> Tem pontua��o
--394 -> Substitui��o de GIA/DASN/STDA -> N�O tem pontua��o

-- exemplos de antes mudan�a:
--395 => DRT-07 - BAURU	  eq 23	LINO DE MORAES LEME NETO	OSF 07001387162	29/07/16 ----> OK, aparece na consulta de pontos
--394 => DRT-04 - SOROCABA	eq 12	SCHIBEL ABUD	            OSF 04002161167	29/07/16 ----> Aparece na consulta de pontos porque tem GDOC
-- ao tirar o GDOC no Debug:

--------------------------------------------------------------------------------
--mudando...
--------------------------------------------------------------------------------
alter Trigger Tr_Pontuacao_Serv_Diverso_Bi disable;
Insert Into Tb_Pontuacao_Servico_Diverso (ID_PONTUACAO_SERVICO_DIVERSO, ID_SERVICO_DIVERSO, ID_PONTUACAO, DT_INICIO_VIGENCIA, DT_FIM_VIGENCIA, ID_USUARIO_ALTERACAO, DT_ALTERACAO, ID_FATOR_CORRECAO)
Values (126, 394, 128, '01/01/1970', '31/12/9999', 'fsnagamine', Sysdate, Null);
alter trigger Tr_Pontuacao_Serv_Diverso_Bi enable;

select *
from tb_pontuacao_servico_diverso
where id_pontuacao = 128

delete Tb_Pontuacao_Servico_Diverso
where ID_PONTUACAO_SERVICO_DIVERSO = 126

--------------------------------------------------------------------------------
--testando mudan�a...
--------------------------------------------------------------------------------
-- essa � a mesma query de antes da mudan�a:
select *
from ordem_servico_fiscal osf
join OSF_SERVICO_DIVERSO osd
on osf.id_osf = osd.ID_OSF
where num_osf = '04002161167'

-- mesmos exemplos, sp�s a mudan�a:
--395 => DRT-07 - BAURU	    eq 23	LINO DE MORAES LEME NETO	OSF 07001387162	(07.001.387/16-2) 29/07/16 ----> OK, aparece na consulta de pontos
--394 => DRT-04 - SOROCABA	eq 12	SCHIBEL ABUD	            OSF 04002161167	(04.002.161/16-7) 29/07/16 ----> N�o aparece na consulta de pontos

