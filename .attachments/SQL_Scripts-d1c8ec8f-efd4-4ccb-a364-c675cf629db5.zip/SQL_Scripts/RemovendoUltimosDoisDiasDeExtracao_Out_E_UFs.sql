delete from [NFe_Out].[Extracao].[HistoricoExtracaoDW]
where id in (10658,10657)

delete from [NFe_Out_UFs].[Extracao].[HistoricoExtracaoDW]
where id in (10633,10632)