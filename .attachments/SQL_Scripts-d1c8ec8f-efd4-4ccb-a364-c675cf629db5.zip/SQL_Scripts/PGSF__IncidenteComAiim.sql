select * 
from fiscal 
where id_funcional = 179759
where num_fiscal = 336467 --182576 (tmp) 179759(dev)
--171235

select *
from osf_executante osf
join fiscal fi
on osf.num_fiscal = fi.num_fiscal
where osf.id_osf = 790066

 SELECT *
FROM TB_DADOS_AIIM AIIM 
JOIN ORDEM_SERVICO_FISCAL OSF
ON AIIM.ID_OSF = OSF.ID_OSF
JOIN AUTOR_AIIM AA 
ON AA.AIIM_ID_SEQ_AIIM = AIIM.ID_SEQ_AIIM
JOIN FISCAL F
ON F.ID_FUNCIONAL = AA.CD_ID_FUNCIONAL
LEFT JOIN (
  SELECT ID_EQUIPE, COD_EQUIPE
  FROM EQUIPE
  UNION 
  SELECT ID_EQUIPE_DEAT ID_EQUIPE, COD_EQUIPE_DEAT COD_EQUIPE
  FROM EQUIPE_DEAT
) EQUIPES ON EQUIPES.ID_EQUIPE = OSF.ID_EQUIPE
WHERE 
(NR_AIIM = 4070411) 

select *
from tb_dom_situacao_relato

select re.id_relato_situacao, re.nr_ano, re.nr_mes, re.id_equipe, re.nr_fiscal, fi.nom_fiscal, re.dt_alteracao, re.in_ativo, re.ds_observacao, re.in_bc, sr.ds_situacao_relato, re.id_situacao_relato
from pgsf.tb_relato_situacao re
join pgsf.tb_dom_situacao_relato sr
on re.id_situacao_relato = sr.id_situacao_relato
join pgsf.fiscal fi
on fi.num_fiscal = re.nr_fiscal
where 
--re.id_equipe in (80) and 
re.nr_fiscal in (15067, 15043, 14981, 85781, 336467, 84673, 5839, 87650, 23600, 15092, 15171) and
re.nr_ano = 2016
and re.nr_mes = 2
--and re.nr_fiscal = 87650
order by re.dt_alteracao

select * 
from pgsf.equipe_membro
where num_fiscal in (15067, 15043, 14981, 85781, 336467, 84673, 5839, 87650, 23600, 15092, 15171)
and dtc_inicio_membro >= '01-02-2016'
and (dtc_fim_membro >= '01-02-2016' or dtc_fim_membro is null)
