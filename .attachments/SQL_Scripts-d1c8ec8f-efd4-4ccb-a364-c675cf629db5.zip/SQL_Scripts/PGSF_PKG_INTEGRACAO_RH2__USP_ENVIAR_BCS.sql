 --CDU 15
  PROCEDURE USP_ENVIAR_BCS
  ( 
    P_NR_FISCAL IN NUMBER := -1,
    P_NR_MES IN NUMBER := -1,
    P_NR_ANO IN NUMBER := -1,
    CUR_OUT IN OUT SYS_REFCURSOR
  ) AS  
  BEGIN    
    
    DECLARE
    
      MSG_RESP VARCHAR(1000);      
      
      --QUERY PARA ATUALIZAÇÃO DO STATUS, VIA CHAMADA DA PROC USP_ATUALIZAR_STATUS_BC
        
        CURSOR CUR_IN IS
        
          SELECT
            BC.ID_BC,          
            BC.QN_PONTOS_APOS - BC.QN_PONTOS_ANTES DELTA_PTS,
            BC.QN_QUOTAS_APOS - BC.QN_QUOTAS_ANTES DELTA_QTS
          FROM
            TB_BOLETIM_CORRECAO BC JOIN TB_RELATO_SITUACAO RS ON 
                (BC.NR_FISCAL = RS.NR_FISCAL AND BC.NR_MES = RS.NR_MES AND BC.NR_ANO = RS.NR_ANO)
          WHERE RS.ID_SITUACAO_RELATO = 70 
            AND RS.IN_ATIVO = 1
            AND RS.NR_ANO >= 2015
            AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
            AND (RS.NR_FISCAL = P_NR_FISCAL OR P_NR_FISCAL = -1)
            AND (RS.NR_MES = P_NR_MES OR P_NR_MES = -1)
            AND (RS.NR_ANO = P_NR_ANO OR P_NR_ANO = -1);
          
      REC_BC CUR_IN%ROWTYPE;
        
      BEGIN
      
        --QUERY QUE SERÁ RETORNADA PELA PROC, VIA REFCURSOR
        OPEN CUR_OUT FOR
        SELECT 
          BC.ID_BC,
          BC.NR_BC,
          BC.NR_FISCAL,
          
          BC.NR_MES,
          BC.NR_ANO,
          F.NOM_FISCAL,
          F.NUM_RG,
          F.NUM_VINCULO,
          'FDT' FUNCAO,
          
          EQUIPE.ID_DRT,
          EQUIPE.ID_UA_DRT,
          EQUIPE.COD_NF,
          RMA.DS_POSTO_FISCAL,
          RMA.ID_EQUIPE,
          EQUIPE.COD_EQUIPE,
          
          BC.QN_PONTOS_ANTES,
          BC.QN_QUOTAS_ANTES,
          BC.QN_DIAS_FDT_ANTES,
          BC.QN_PONTOS_APOS,
          BC.QN_QUOTAS_APOS,
          BC.QN_DIAS_FDT_APOS,
          BC.IN_MOTIVO_AIIM,
          BC_AIIM.DS_NR_AIIM_FORMATADO NR_AIIM,
          BC_AIIM.DS_NR_OSF_FORMATADO NR_OSF,
          0 IN_ERRO_DIGITACAO,
          0 IN_EQUIVOCO,
          BC.IN_MOTIVO_PONTUACAO,
          
          RS.DS_OBSERVACAO,
            
          FR.NOM_FISCAL NOM_RESPONSAVEL,
          BC.DS_FUNCAO_RESPONSAVEL_HOMOL FUNCAO_RESPONSAVEL,
          RS.DT_ALTERACAO DT_HOMOLOGACAO
            
        FROM
          TB_BOLETIM_CORRECAO BC JOIN TB_RMA RMA ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) LEFT JOIN          
          TB_BC_AIIM BC_AIIM ON BC.ID_BC = BC_AIIM.ID_BC JOIN 
          TB_RELATO_SITUACAO RS ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND 
              (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE)) JOIN
          (SELECT * FROM TB_RELATO_SITUACAO WHERE IN_HOMOLOG_RMA = 1) RSRMA ON (RSRMA.NR_FISCAL = RMA.NR_FISCAL AND RSRMA.NR_MES = RMA.NR_MES AND RSRMA.NR_ANO = RMA.NR_ANO) JOIN
          FISCAL F ON RMA.NR_FISCAL = F.NUM_FISCAL LEFT JOIN
          FISCAL FR ON RSRMA.NR_FISCAL_RESP = FR.NUM_FISCAL JOIN         
            
          
            (SELECT			
                D.ID_DRT,
                D.ID_UA_ERGON ID_UA_DRT,
                UR.CD_UNIDADE_RESPONSAVEL || ' - ' || DS_UNIDADE_RESPONSAVEL COD_NF,
                ED.COD_EQUIPE_DEAT COD_EQUIPE,
                ED.ID_EQUIPE_DEAT  ID_EQUIPE
              FROM EQUIPE_DEAT ED
                JOIN UNIDADE_RESPONSAVEL UR ON ED.ID_UNIDADE_RESPONSAVEL = UR.ID_UNIDADE_RESPONSAVEL
                LEFT JOIN (UNIDADE_RESPONSAVEL_ORIGEM URO
                    JOIN (SELECT * FROM ORIGEM WHERE (ID_TIPO_ORIGEM = 1 OR ID_TIPO_ORIGEM = 2)) O ON URO.ID_ORIGEM = O.ID_ORIGEM
                    JOIN ORIGEM_DRT OD ON O.ID_ORIGEM = OD.ID_ORIGEM
                    JOIN DRT D ON D.ID_DRT = OD.ID_DRT            
                ) ON UR.ID_UNIDADE_RESPONSAVEL = URO.ID_UNIDADE_RESPONSAVEL
            UNION
              SELECT
                DRT.ID_DRT,
                DRT.ID_UA_ERGON ID_UA_DRT,
                NF.COD_NF,
                EQ.COD_EQUIPE,
                EQ.ID_EQUIPE
              FROM EQUIPE EQ
                JOIN NF ON NF.ID_NF = EQ.ID_NF 
                JOIN DRT ON DRT.ID_DRT = NF.ID_DRT) EQUIPE ON EQUIPE.ID_EQUIPE = RMA.ID_EQUIPE          
          
          
        WHERE RS.ID_SITUACAO_RELATO = 70
          AND RS.IN_ATIVO = 1
          AND RS.NR_ANO >= 2015
          AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
          AND (RS.NR_FISCAL = P_NR_FISCAL OR P_NR_FISCAL = -1)
          AND (RS.NR_MES = P_NR_MES OR P_NR_MES = -1)
          AND (RS.NR_ANO = P_NR_ANO OR P_NR_ANO = -1);
        
        
        OPEN CUR_IN;
          
          LOOP
          
            FETCH CUR_IN INTO REC_BC;
            EXIT WHEN CUR_IN%NOTFOUND;
            
            --DBMS_OUTPUT.PUT_LINE(REC_BC);
            
            USP_ATUALIZAR_STATUS_BC(REC_BC.ID_BC, 80, '', msg_resp);

                     
            
          END LOOP;          
        CLOSE cur_in;
        
      END;
      
    END USP_ENVIAR_BCS;