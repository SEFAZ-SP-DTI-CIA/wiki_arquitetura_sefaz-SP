--## PRODUCAO ##################################################################
select * from PGSF.TB_RMA
where
(nr_fiscal = 90065  and nr_ano = 2016 and nr_mes =  9) OR
(nr_fiscal = 87303  and nr_ano = 2017 and nr_mes =  4) OR
(nr_fiscal = 57207  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 16874  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 94599  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 25000  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 85367  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 31000  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 172252 and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 15274  and nr_ano = 2018 and nr_mes = 12)
order by nr_fiscal, nr_ano, nr_mes


select NR_FISCAL,ID_RMA,NR_ANO,NR_MES,QN_TOTAL_QUOTAS,QN_TOTAL_PONTOS,ID_RELATO_SITUACAO_HOMOL,ID_EQUIPE,DS_POSTO_FISCAL,DS_FUNCAO_RESPONSAVEL_HOMOL from PGSF.TB_RMA
where
nr_ano = 2018 and nr_mes =  12
and nr_fiscal in (33707,246399,320940,170644,246399,320940)

in (5712,5736,5839,10306,14968,14981,15018,15043,15067,15092,15262,15456,15535,15663,15699,15857,15869,16254,16278,16280,16849,16874,17210,19656,20002,22345,23600,24299,25000,25139,25929,26867,28281,28888,28955,29017,29029,29182,29431,29662,29686,29765,29947,30240,30329,30561,31498,31826,32089,32934,32983,32995,33070,33410,33707,44596,51199,51989,57207,57633,61648,80801,84582,84673,84843,85124,85173,85628,85756,85781,85884,86748,86839,87303,87583,87650,87819,88381,88400,88411,88447,89440,90065,93169,93546,93637,93820,94599,94666,94782,95245,95282,95543,95634,96067,96304,96500,170644,170670,170681,170802,170826,170929,171314,171430,171533,171995,172069,172872,172914,173165,173219,173232,173360,173440,173475,173554,173621,240889,245942,246399,246545,246739,247616,248700,248773,249297,249479,249583,249789,249900,250652,250767,251152,259886,319070,319172,320368,320460,320903,320940,321828,333600,334896,335311,335414,336017,336546,336777,339900)
order by nr_fiscal, nr_ano, nr_mes




select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS'), nr_ano, nr_mes
from pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
where
id_relato_situacao = 696735

(id_equipe = 80 and nr_mes = 9 and nr_ano = 2016) OR
nr_fiscal in (90065)  and nr_ano = 2016 and nr_mes =  9
order by dt_alteracao




--(nr_fiscal = 90065  and nr_ano = 2016 and nr_mes =  9)-- OR
--(nr_fiscal = 87303  and nr_ano = 2017 and nr_mes =  4)-- OR
--(nr_fiscal = 57207  and nr_ano = 2017 and nr_mes =  9)-- OR
--(nr_fiscal = 16874  and nr_ano = 2017 and nr_mes =  9)-- OR
--(nr_fiscal = 94599  and nr_ano = 2018 and nr_mes = 12)-- OR
--(nr_fiscal = 25000  and nr_ano = 2018 and nr_mes = 12)-- OR
--(nr_fiscal = 85367  and nr_ano = 2018 and nr_mes = 12)-- OR
--(nr_fiscal = 31000  and nr_ano = 2018 and nr_mes = 12)-- OR
(nr_fiscal = 172252 and nr_ano = 2018 and nr_mes = 12)-- OR
--(nr_fiscal = 15274  and nr_ano = 2018 and nr_mes = 12)
order by nr_fiscal, dt_alteracao

select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS'), nr_ano, nr_mes
from pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
where
(id_equipe = 1507 and nr_ano = 2018 and nr_mes = 12) OR
(id_equipe = 87 and nr_mes = 9 and nr_ano = 2016) OR
(id_equipe = 87 and nr_mes = 4 and nr_ano = 2017) OR
(id_equipe = 204 and nr_mes = 9 and nr_ano = 2017) OR
(id_equipe = 203 and nr_mes = 9 and nr_ano = 2017) OR
(id_equipe = 80 and nr_mes = 9 and nr_ano = 2016) OR
(id_equipe = 1221 and nr_mes = 4 and nr_ano = 2017) OR
(id_equipe = 1507 and nr_mes = 12 and nr_ano = 2018) OR
(id_equipe = 83 and nr_mes = 9 and nr_ano = 2017) OR
(id_equipe = 196 and nr_mes = 9 and nr_ano = 2017) OR
(id_equipe = 199 and nr_mes = 12 and nr_ano = 2018)
order by id_equipe, dt_alteracao


















select * from pgsf.fiscal
where num_fiscal in (90065,87303,57207,16874,94599,25000,85367,31000,172252,15274)

select drt.NOM_DRT, eq.NOM_EQUIPE, id_equipe, num_fiscal, fi.nom_fiscal, em.dtc_inicio_membro, em.dtc_fim_membro
from pgsf.fiscal fi
join PGSF.EQUIPE_MEMBRO em
using(NUM_FISCAL)
join pgsf.equipe eq
using(id_equipe)
join PGSF.DRT
using(ID_DRT)
where 
num_fiscal in (171533,90065)
and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('30/09/2016','DD/MM/YYYY') and dtc_fim_membro > to_date('01/09/2016','DD/MM/YYYY')))

select drt.NOM_DRT, eq.NOM_EQUIPE, id_equipe, num_fiscal, fi.nom_fiscal, em.dtc_inicio_membro, em.dtc_fim_membro
from pgsf.fiscal fi
join PGSF.EQUIPE_MEMBRO em
using(NUM_FISCAL)
join pgsf.equipe eq
using(id_equipe)
join PGSF.DRT
using(ID_DRT)
where 
id_equipe = 80
and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('30/09/2016','DD/MM/YYYY') and dtc_fim_membro > to_date('01/09/2016','DD/MM/YYYY')))

(num_fiscal = 90065  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('30/09/2016','DD/MM/YYYY') and dtc_fim_membro > to_date('01/09/2016','DD/MM/YYYY')))) OR
(num_fiscal = 87303  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('30/04/2017','DD/MM/YYYY') and dtc_fim_membro > to_date('01/04/2017','DD/MM/YYYY')))) OR
(num_fiscal = 57207  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('30/09/2017','DD/MM/YYYY') and dtc_fim_membro > to_date('01/09/2017','DD/MM/YYYY')))) OR
(num_fiscal = 16874  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('30/09/2017','DD/MM/YYYY') and dtc_fim_membro > to_date('01/09/2017','DD/MM/YYYY')))) OR
(num_fiscal = 94599  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('31/12/2018','DD/MM/YYYY') and dtc_fim_membro > to_date('01/12/2018','DD/MM/YYYY')))) OR
(num_fiscal = 25000  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('31/12/2018','DD/MM/YYYY') and dtc_fim_membro > to_date('01/12/2018','DD/MM/YYYY')))) OR
(num_fiscal = 85367  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('31/12/2018','DD/MM/YYYY') and dtc_fim_membro > to_date('01/12/2018','DD/MM/YYYY')))) OR
(num_fiscal = 31000  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('31/12/2018','DD/MM/YYYY') and dtc_fim_membro > to_date('01/12/2018','DD/MM/YYYY')))) OR
(num_fiscal = 172252 and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('31/12/2018','DD/MM/YYYY') and dtc_fim_membro > to_date('01/12/2018','DD/MM/YYYY')))) OR
(num_fiscal = 15274  and (dtc_fim_membro is null or (dtc_inicio_membro < to_date('31/12/2018','DD/MM/YYYY') and dtc_fim_membro > to_date('01/12/2018','DD/MM/YYYY'))))
order by nom_fiscal

NOM_DRT, NOM_EQUIPE, ID_EQUIPE, NUM_FISCAL, NOM_FISCAL, DTC_INICIO_MEMBRO, DTC_FIM_MEMBRO
DRTC-III - S�O PAULO	61	1507	94599	ELIANE DE FATIMA VARELA RAMOS	01/08/18	
DRTC-III - S�O PAULO	21	199	25000	EUCLERIO JOS� CERUTTI DA SILVA	01/03/19	
DRTC-III - S�O PAULO	61	1507	25000	EUCLERIO JOS� CERUTTI DA SILVA	01/08/18	31/01/19
DRTC-III - S�O PAULO	61	1507	85367	FERNANDO RAMALHO PARANHOS	01/08/18	
DRT-14 - OSASCO	36	1221	87303	FL�VIO EDUARDO DI MONACO	04/04/17	
DRT-14 - OSASCO	31	87	87303	FL�VIO EDUARDO DI MONACO	01/05/16	03/04/17
DRTC-III - S�O PAULO	32	204	57207	GILBERTO ADAS	01/07/16	10/09/17
DRTC-III - S�O PAULO	12	196	57207	GILBERTO ADAS	01/03/19	
DRTC-III - S�O PAULO	31	203	57207	GILBERTO ADAS	11/09/17	28/02/19
DRTC-III - S�O PAULO	61	1507	31000	JORGE CARLOS SANTOS DE DEUS	01/08/18	
DRTC-III - S�O PAULO	61	1507	172252	ODETE KHALED TAHA	01/10/18	25/12/18
DRT-14 - OSASCO	21	83	16874	ROBERTO AMUNDSON AILY	08/10/18	
DRTC-III - S�O PAULO	32	204	16874	ROBERTO AMUNDSON AILY	03/07/17	10/09/17
DRTC-III - S�O PAULO	31	203	16874	ROBERTO AMUNDSON AILY	11/09/17	03/04/18
DRT-14 - OSASCO	11	80	90065	ROSANA APARECIDA DUQUE	20/09/16	
DRT-14 - OSASCO	31	87	90065	ROSANA APARECIDA DUQUE	16/05/16	19/09/16
DRTC-III - S�O PAULO	61	1507	15274	VERA REGINA LELLIS VIEIRA RIBEIRO	01/08/18	06/01/19


select *
FROM pgsf.TB_RMA
where 
--nr_fiscal = 94599 and
nr_ano = 2018 and nr_mes = 12
order by id_rma desc

select *
FROM pgsf.TB_RMA
where 
id_rma between 165528 and 167235
order by id_rma

select nr_fiscal, id_relato_situacao, id_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS')
from pgsf.tb_relato_situacao
where dt_alteracao between to_date('24/02/2019 00:00','DD/MM/YYYY HH24:MI') and to_date('25/02/2019 23:59','DD/MM/YYYY HH24:MI')
order by dt_alteracao

select to_number(to_char(dt_alteracao, 'DD')), to_number(to_char(dt_alteracao, 'HH24')), count(1)
from pgsf.tb_relato_situacao
where dt_alteracao between to_date('25/02/2019','DD/MM/YYYY') and to_date('12/02/2019','DD/MM/YYYY')
group by to_number(to_char(dt_alteracao, 'DD')), to_number(to_char(dt_alteracao, 'HH24'))
ORDER BY to_number(to_char(dt_alteracao, 'DD')), to_number(to_char(dt_alteracao, 'HH24'))



select *
from pgsf.TB_BOLETIM_CORRECAO
where NR_FISCAL = 57207
and nr_ano = 2017
and nr_mes = 9
--ID_BC, NR_BC, NR_FISCAL, NR_ANO, NR_MES, QN_PONTOS_ANTES, QN_QUOTAS_ANTES, QN_DIAS_FDT_ANTES, QN_PONTOS_APOS, QN_QUOTAS_APOS, QN_DIAS_FDT_APOS, IN_MOTIVO_AIIM, IN_MOTIVO_PONTUACAO, DS_FUNCAO_RESPONSAVEL_HOMOL, ID_RELATO_SITUACAO_HOMOL
--31040	 1	    57207   	2017    9       1892        	0	             30                 1892	        0	            3                   0	            1               1	Assistente de Inspetor	    1532822

select *
from pgsf.TB_BOLETIM_CORRECAO
where 
(nr_fiscal = 90065  and nr_ano = 2016 and nr_mes =  9) OR
(nr_fiscal = 87303  and nr_ano = 2017 and nr_mes =  4) OR
(nr_fiscal = 57207  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 16874  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 94599  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 25000  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 85367  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 31000  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 172252 and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 15274  and nr_ano = 2018 and nr_mes = 12)

select *
FROM pgsf.TB_RMA
where nr_ano = 2018 and nr_mes = 3
and nr_fiscal = 94599

25000,
85367,
31000,
172252,
15274)

select rsA.nr_fiscal, rsA.nr_mes, rsA.nr_ano, rsA.id_situacao_relato, to_char(rsA.dt_alteracao, 'DD/MM/YYYY HH24:MM'), rsB.nr_fiscal, rsB.nr_mes, rsB.nr_ano, rsB.id_situacao_relato, to_char(rsB.dt_alteracao, 'DD/MM/YYYY HH24:MM')
from pgsf.tb_relato_situacao rsA
join pgsf.tb_relato_situacao rsB
on rsA.nr_ano = rsB.nr_ano
and rsA.nr_mes = rsB.nr_mes
and rsA.nr_fiscal = rsB.nr_fiscal
and rsA.dt_alteracao < rsB.dt_alteracao
where 
rsB.id_situacao_relato = 25
and 
rsA.id_situacao_relato = 60
and
rsB.dt_alteracao = (select min(dt_alteracao) from pgsf.tb_relato_situacao where nr_ano = rsB.nr_ano and nr_mes = rsB.nr_mes and nr_fiscal = rsB.nr_fiscal and dt_alteracao > rsA.dt_alteracao)

--id_situacao_relato = 25 and
--nr_fiscal = 86645 and 
nr_fiscal = 17787 and 
nr_ano = 2018 and nr_mes = 12
order by dt_alteracao


select *
FROM pgsf.TB_RMA
where nr_ano = 2018 
AND   nr_mes in (3,12)
AND   nr_fiscal = 94599

SELECT rs.nr_fiscal, rs.nr_mes, rs.id_relato_situacao, id_situacao_relato, sr.ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS')
FROM  pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
WHERE nr_ano = 2018 
AND   nr_mes in (3,12)
AND   nr_fiscal = 94599
ORDER BY dt_alteracao


select *
from  pgsf.tb_relato_situacao
where nr_ano = 2018 
AND   nr_fiscal = 94599
AND   nr_mes = 3
ORDER BY dt_alteracao




SELECT RS.ID_RELATO_SITUACAO, RS.ID_SITUACAO_RELATO, BC.ID_RELATO_SITUACAO_HOMOL, RMA.ID_RMA
FROM pgsf.TB_BOLETIM_CORRECAO BC 
JOIN pgsf.TB_RMA RMA 
ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) 
JOIN  pgsf.TB_RELATO_SITUACAO RS 
ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE))
WHERE 
  RS.ID_SITUACAO_RELATO = 61 and
  (
(RS.nr_fiscal = 90065  and RS.nr_ano = 2016 and RS.nr_mes =  9) OR
(RS.nr_fiscal = 87303  and RS.nr_ano = 2017 and RS.nr_mes =  4) OR
(RS.nr_fiscal = 57207  and RS.nr_ano = 2017 and RS.nr_mes =  9) OR
(RS.nr_fiscal = 16874  and RS.nr_ano = 2017 and RS.nr_mes =  9)
)
--ID_RELATO_SITUACAO, ID_SITUACAO_RELATO, ID_RELATO_SITUACAO_HOMOL, ID_RMA
--1518602           	61              	1532822	                139966
--1518613	            61	                1532823	                139970
--1522499	            61	                1532824	                131874
--1522499	            61	                1483092	                131874
--1527087	            61	                1532821	                118667

SELECT id_relato_situacao, nr_ano, nr_mes, nr_fiscal, id_situacao_relato
FROM pgsf.TB_RELATO_SITUACAO
where id_relato_situacao in
(1532822,
1532823,
1532824,
1483092,
1532821)
order by nr_fiscal;

SELECT *
FROM pgsf.TB_RELATO_SITUACAO
where id_relato_situacao in
(1532824,
1483092,
1522499
)
order by nr_fiscal;

SELECT id_relato_situacao, nr_ano, nr_mes, nr_fiscal, id_situacao_relato
FROM pgsf.TB_RELATO_SITUACAO
where id_relato_situacao in
(1518602,
1518613,
1522499,
1527087)
order by nr_fiscal



select * from pgsf.tb_rma
where id_rma = 139966
--ID_RELATO_SITUACAO_HOMOL = 1339153



 SELECT
    BC.ID_BC,          
    BC.QN_PONTOS_APOS - BC.QN_PONTOS_ANTES DELTA_PTS,
    BC.QN_QUOTAS_APOS - BC.QN_QUOTAS_ANTES DELTA_QTS
  FROM
    pgsf.TB_BOLETIM_CORRECAO BC JOIN pgsf.TB_RELATO_SITUACAO RS ON 
        (BC.NR_FISCAL = RS.NR_FISCAL AND BC.NR_MES = RS.NR_MES AND BC.NR_ANO = RS.NR_ANO)
  WHERE RS.ID_SITUACAO_RELATO = 70 
    AND RS.IN_ATIVO = 1
    AND RS.NR_ANO >= 2015
    AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
    AND (RS.NR_FISCAL = 57207 OR 57207 = -1)
    AND (RS.NR_MES = 9 OR 9 = -1)
    AND (RS.NR_ANO = 2017 OR 2017 = -1);



select *
from pgsf.TB_RELATO_SITUACAO RS
  WHERE 
  --RS.ID_SITUACAO_RELATO = 70 
    RS.IN_ATIVO = 1
    AND RS.NR_ANO >= 2015
    AND RS.NR_FISCAL = 57207
    AND RS.NR_MES = 9
    AND RS.NR_ANO = 2017


select *
from pgsf.tb_dom_situacao_relato

--ID_SITUACAO_RELATO, DS_SITUACAO_RELATO
--1                 	Em elabora��o
--5	                    Devolvido para corre��o pela aprova��o
--6	                    Devolvido para corre��o pela Homologa��o
--10	                Fechado
--20	                Aprovado
--25	                Pronto para ser Homologado
--30	                Homologado
--40	                Pronto para ser enviado ao RH
--49	                Devolvido para corre��o pelo RH - Aguardando Notifica��o
--50	                Enviado para o RH
--60	                Averbado
--61	                BC em andamento em outra equipe
--70	                BC pronto para ser enviado ao RH
--79	                BC devolvido para corre��o pelo RH - Aguardando Notifica��o
--80	                BC enviado para o RH
--90	                BC Averbado
--48	                Devolvido para corre��o pelo RH
--78	                BC devolvido para corre��o pelo RH


select *
from pgsf.TB_BOLETIM_CORRECAO BC 
where id_bc = 31040   

select *
from pgsf.TB_RMA RMA
where id_rma = 139966


SELECT RS.ID_RELATO_SITUACAO, BC.ID_RELATO_SITUACAO_HOMOL, RMA.ID_RMA
FROM pgsf.TB_BOLETIM_CORRECAO BC 
JOIN pgsf.TB_RMA RMA 
ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) 
JOIN  pgsf.TB_RELATO_SITUACAO RS 
ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE))
WHERE 
--RS.ID_SITUACAO_RELATO = 70 AND 
  RS.IN_ATIVO = 1 AND 
  --AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
  (RS.NR_FISCAL = 57207)
  AND (RS.NR_MES = 9)
  AND (RS.NR_ANO = 2017);

--ID_RELATO_SITUACAO, ID_RELATO_SITUACAO_HOMOL, ID_BC,  ID_RMA
-- 1518602	           1532822	                 31040   139966



select drt.NOM_DRT, ID_EQUIPE, eq.NOM_EQUIPE, fi.nom_fiscal, fi.email, num_fiscal, em.dtc_inicio_membro, em.dtc_fim_membro
from pgsf.fiscal fi
join pgsf.EQUIPE_MEMBRO em
using(NUM_FISCAL)
join pgsf.equipe eq
using(id_equipe)
join pgsf.DRT
using(ID_DRT)
where (DTC_FIM_MEMBRO is null OR (DTC_FIM_MEMBRO > to_date('01/09/2016','DD/MM/YYYY') and DTC_INICIO_MEMBRO < to_date('30/09/2018','DD/MM/YYYY')))
and num_fiscal in (4306, 5323, 5426, 5591, 5736, 5839, 5980, 11682, 13230, 13307, 14968, 14981, 15018, 15043, 15067, 15092, 15160, 15262, 15274, 15456, 15535, 15663, 15699, 15857, 15882, 16254, 16278, 16280, 16369, 16849, 17210, 18354, 18822, 18858, 19656, 19784, 20002, 20312, 20348, 20490, 20725, 21481, 21780, 21882, 21973, 22345, 22527, 22680, 23430, 23519, 23600, 23910, 24457, 24743, 25139, 25723, 25784, 25851, 25863, 26016, 26650, 26818, 27136, 27318, 27320, 27896, 28037, 28281, 28955, 29029, 29169, 30688, 32089, 32995, 33707, 33732, 51989, 57189, 57633, 61648, 81441, 84582, 84661, 84673, 84843, 85045, 85173, 85756, 85781, 85811, 86165, 86244, 86311, 86580, 86748, 87108, 87110, 87303, 87364, 87390, 87479, 87650, 87856, 88381, 90065, 93169, 93492, 93546, 93637, 93730, 94289, 94400, 94666, 94782, 95245, 95397, 95543, 95555, 96225, 96304, 96407, 96500, 170498, 170504, 170644, 170802, 170929, 170991, 171247, 171533, 171557, 171995, 172069, 172070, 172227, 172422, 172501, 172586, 172616, 172914, 172951, 173165, 173359, 173360, 173372, 173475, 173621, 173761, 173815, 246399, 246454, 246545, 246650, 246739, 246971, 247446, 247616, 248440, 248773, 248827, 249327, 249479, 249753, 249777, 249789, 250500, 250690, 250986, 251152, 251292, 251991, 259886, 313893, 318921, 320940, 333107, 333545, 333790, 334264, 334896, 335311, 335414, 335440, 336017, 336182, 336431, 336546)

select aa.num_fiscal, b.num_fiscal, aa.id_equipe, b.id_equipe, aa.dtc_inicio_membro, b.dtc_inicio_membro, aa.dtc_fim_membro, b.dtc_fim_membro
from pgsf.EQUIPE_MEMBRO aa
join pgsf.EQUIPE_MEMBRO b
on aa.num_fiscal = b.num_fiscal
and aa.dtc_inicio_membro < b.dtc_inicio_membro
where (aa.DTC_FIM_MEMBRO is null OR (aa.DTC_FIM_MEMBRO > to_date('01/09/2016','DD/MM/YYYY') and aa.DTC_INICIO_MEMBRO < to_date('30/09/2018','DD/MM/YYYY')))
and (b.DTC_FIM_MEMBRO is null OR (b.DTC_FIM_MEMBRO > to_date('01/09/2016','DD/MM/YYYY') and b.DTC_INICIO_MEMBRO < to_date('30/09/2018','DD/MM/YYYY')))




select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS'), nr_ano, nr_mes
from pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
where
id_equipe in (80,87,153,164,181,186,1209,1221,1222) and nr_mes = 9 and nr_ano = 2016
order by dt_alteracao


select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS'), nr_ano, nr_mes
from pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
where
nr_fiscal in (4306, 5323, 5426, 5591, 5736, 5839, 5980, 11682, 13230, 13307, 14968, 14981, 15018, 15043, 15067, 15092, 15160, 15262, 15274, 15456, 15535, 15663, 15699, 15857, 15882, 16254, 16278, 16280, 16369, 16849, 17210, 18354, 18822, 18858, 19656, 19784, 20002, 20312, 20348, 20490, 20725, 21481, 21780, 21882, 21973, 22345, 22527, 22680, 23430, 23519, 23600, 23910, 24457, 24743, 25139, 25723, 25784, 25851, 25863, 26016, 26650, 26818, 27136, 27318, 27320, 27896, 28037, 28281, 28955, 29029, 29169, 30688, 32089, 32995, 33707, 33732, 51989, 57189, 57633, 61648, 81441, 84582, 84661, 84673, 84843, 85045, 85173, 85756, 85781, 85811, 86165, 86244, 86311, 86580, 86748, 87108, 87110, 87303, 87364, 87390, 87479, 87650, 87856, 88381, 90065, 93169, 93492, 93546, 93637, 93730, 94289, 94400, 94666, 94782, 95245, 95397, 95543, 95555, 96225, 96304, 96407, 96500, 170498, 170504, 170644, 170802, 170929, 170991, 171247, 171533, 171557, 171995, 172069, 172070, 172227, 172422, 172501, 172586, 172616, 172914, 172951, 173165, 173359, 173360, 173372, 173475, 173621, 173761, 173815, 246399, 246454, 246545, 246650, 246739, 246971, 247446, 247616, 248440, 248773, 248827, 249327, 249479, 249753, 249777, 249789, 250500, 250690, 250986, 251152, 251292, 251991, 259886, 313893, 318921, 320940, 333107, 333545, 333790, 334264, 334896, 335311, 335414, 335440, 336017, 336182, 336431, 336546)
and (nr_mes = 9 and nr_ano = 2016)


select *
from pgsf.fiscal fi
join pgsf.EQUIPE_MEMBRO em
using(NUM_FISCAL)
join pgsf.equipe eq
using(id_equipe)
join pgsf.DRT
using(ID_DRT)
where (DTC_FIM_MEMBRO is null OR (DTC_FIM_MEMBRO > to_date('01/09/2016','DD/MM/YYYY') and DTC_INICIO_MEMBRO < to_date('30/09/2018','DD/MM/YYYY')))
and id_equipe in (80,87,153,164,181,186,1209,1221,1222)


