--## DEV #######################################################################
SELECT 
  BC.ID_BC,
  BC.NR_BC,
  BC.NR_FISCAL,
  
  BC.NR_MES,
  BC.NR_ANO,
  F.NOM_FISCAL,
  F.NUM_RG,
  F.NUM_VINCULO,
  'FDT' FUNCAO,
  
  EQUIPE.ID_DRT,
  EQUIPE.ID_UA_DRT,
  EQUIPE.COD_NF,
  RMA.DS_POSTO_FISCAL,
  RMA.ID_EQUIPE,
  EQUIPE.COD_EQUIPE,
  
  BC.QN_PONTOS_ANTES,
  BC.QN_QUOTAS_ANTES,
  BC.QN_DIAS_FDT_ANTES,
  BC.QN_PONTOS_APOS,
  BC.QN_QUOTAS_APOS,
  BC.QN_DIAS_FDT_APOS,
  BC.IN_MOTIVO_AIIM,
  BC_AIIM.DS_NR_AIIM_FORMATADO NR_AIIM,
  BC_AIIM.DS_NR_OSF_FORMATADO NR_OSF,
  0 IN_ERRO_DIGITACAO,
  0 IN_EQUIVOCO,
  BC.IN_MOTIVO_PONTUACAO,
  
  RS.DS_OBSERVACAO,
	
  FR.NOM_FISCAL NOM_RESPONSAVEL,
  BC.DS_FUNCAO_RESPONSAVEL_HOMOL FUNCAO_RESPONSAVEL,
  RS.DT_ALTERACAO DT_HOMOLOGACAO
	
FROM
  TB_BOLETIM_CORRECAO BC JOIN TB_RMA RMA ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) LEFT JOIN          
  TB_BC_AIIM BC_AIIM ON BC.ID_BC = BC_AIIM.ID_BC JOIN 
  TB_RELATO_SITUACAO RS ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND 
	  (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE)) JOIN
  (SELECT * FROM TB_RELATO_SITUACAO WHERE IN_HOMOLOG_RMA = 1) RSRMA ON (RSRMA.NR_FISCAL = RMA.NR_FISCAL AND RSRMA.NR_MES = RMA.NR_MES AND RSRMA.NR_ANO = RMA.NR_ANO) JOIN
  FISCAL F ON RMA.NR_FISCAL = F.NUM_FISCAL LEFT JOIN
  FISCAL FR ON RSRMA.NR_FISCAL_RESP = FR.NUM_FISCAL JOIN         
	
  
	(SELECT			
		D.ID_DRT,
		D.ID_UA_ERGON ID_UA_DRT,
		UR.CD_UNIDADE_RESPONSAVEL || ' - ' || DS_UNIDADE_RESPONSAVEL COD_NF,
		ED.COD_EQUIPE_DEAT COD_EQUIPE,
		ED.ID_EQUIPE_DEAT  ID_EQUIPE
	  FROM EQUIPE_DEAT ED
		JOIN UNIDADE_RESPONSAVEL UR ON ED.ID_UNIDADE_RESPONSAVEL = UR.ID_UNIDADE_RESPONSAVEL
		LEFT JOIN (UNIDADE_RESPONSAVEL_ORIGEM URO
			JOIN (SELECT * FROM ORIGEM WHERE (ID_TIPO_ORIGEM = 1 OR ID_TIPO_ORIGEM = 2)) O ON URO.ID_ORIGEM = O.ID_ORIGEM
			JOIN ORIGEM_DRT OD ON O.ID_ORIGEM = OD.ID_ORIGEM
			JOIN DRT D ON D.ID_DRT = OD.ID_DRT            
		) ON UR.ID_UNIDADE_RESPONSAVEL = URO.ID_UNIDADE_RESPONSAVEL
	UNION
	  SELECT
		DRT.ID_DRT,
		DRT.ID_UA_ERGON ID_UA_DRT,
		NF.COD_NF,
		EQ.COD_EQUIPE,
		EQ.ID_EQUIPE
	  FROM EQUIPE EQ
		JOIN NF ON NF.ID_NF = EQ.ID_NF 
		JOIN DRT ON DRT.ID_DRT = NF.ID_DRT) EQUIPE ON EQUIPE.ID_EQUIPE = RMA.ID_EQUIPE          
  
  
WHERE RS.ID_SITUACAO_RELATO = 70
  AND RS.IN_ATIVO = 1
  AND RS.NR_ANO >= 2015
  AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
  AND (RS.NR_FISCAL = 57451)
  AND (RS.NR_MES = 1)
  AND (RS.NR_ANO = 2017);

 
select nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MM')
from tb_relato_situacao
JOIN  tb_dom_situacao_relato sr
USING (id_situacao_relato)
where 
nr_fiscal in (57130,86130,55946,87730,56689,57918,86840,85586,58467,58479,87340) and 
--nr_fiscal = 90065 and 
nr_ano = 2017 and nr_mes = 1
order by dt_alteracao

select *
from TB_BOLETIM_CORRECAO
where 
(nr_fiscal = 90065  and nr_ano = 2016 and nr_mes =  9) OR
(nr_fiscal = 87303  and nr_ano = 2017 and nr_mes =  4) OR
(nr_fiscal = 57207  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 16874  and nr_ano = 2017 and nr_mes =  9)
--ID_RELATO_SITUACAO_HOMOL = 1337090

select *
FROM TB_RMA
where nr_ano = 2017 and nr_mes = 1
and nr_fiscal in (84788,57130,86130,55946,87730,56689,57918,86840,85586,58467,58479,87340)
126469
126472
126475
126470
126473
126478
126479
126476
126471
126477
126480
126474

select drt.NOM_DRT, eq.NOM_EQUIPE, fi.nom_fiscal, fi.email, num_fiscal
from fiscal fi
join EQUIPE_MEMBRO em
using(NUM_FISCAL)
join equipe eq
using(id_equipe)
join DRT
using(ID_DRT)
where DTC_FIM_MEMBRO is null
and nom_fiscal in
('CLAYTON DE LIMA MONTIP�',
'EDIO CERATI JUNIOR',
'FL�VIO DE SOUZA QUINT�O',
'IDESIO ALVES',
'JO�O ALBERTO CORR�A',
'JOS� PINTO PINHEIRO NETO',
'JOS� ROBERTO FACIOLI',
'M�RCIO MOTTA ROSMANINHO',
'MARCOS ELIDIO FERNANDES FERRAZZO',
'PAULO SCUDELLER DA SILVA',
'PEDRO LUIS QUAGLIATO GALR�O',
'VALMIRO PIETROBOM DE MORAES')
and num_fiscal in 
(90065,
87303,
57207, 
16874,
94599,
25000,
85367,
31000,
172252,
15274)




--## PRODUCAO ##################################################################


select nr_fiscal, id_relato_situacao, id_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MM')
from pgsf.tb_relato_situacao
where nr_fiscal = 90065 and 
nr_ano = 2016 and nr_mes = 9
order by dt_alteracao


select drt.NOM_DRT, eq.NOM_EQUIPE, fi.nom_fiscal
from pgsf.fiscal fi
join PGSF.EQUIPE_MEMBRO em
using(NUM_FISCAL)
join pgsf.equipe eq
using(id_equipe)
join PGSF.DRT
using(ID_DRT)
where num_fiscal = 94599
and DTC_FIM_MEMBRO is null

select *
FROM pgsf.TB_RMA
where 
--nr_fiscal = 94599 and
nr_ano = 2018 and nr_mes = 12
order by id_rma desc

select *
FROM pgsf.TB_RMA
where 
id_rma between 165528 and 167235
order by id_rma

select nr_fiscal, id_relato_situacao, id_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS')
from pgsf.tb_relato_situacao
where dt_alteracao between to_date('24/02/2019 00:00','DD/MM/YYYY HH24:MI') and to_date('25/02/2019 23:59','DD/MM/YYYY HH24:MI')
order by dt_alteracao

select to_number(to_char(dt_alteracao, 'DD')), to_number(to_char(dt_alteracao, 'HH24')), count(1)
from pgsf.tb_relato_situacao
where dt_alteracao between to_date('25/02/2019','DD/MM/YYYY') and to_date('12/02/2019','DD/MM/YYYY')
group by to_number(to_char(dt_alteracao, 'DD')), to_number(to_char(dt_alteracao, 'HH24'))
ORDER BY to_number(to_char(dt_alteracao, 'DD')), to_number(to_char(dt_alteracao, 'HH24'))



select *
from pgsf.TB_BOLETIM_CORRECAO
where NR_FISCAL = 57207
and nr_ano = 2017
and nr_mes = 9
--ID_BC, NR_BC, NR_FISCAL, NR_ANO, NR_MES, QN_PONTOS_ANTES, QN_QUOTAS_ANTES, QN_DIAS_FDT_ANTES, QN_PONTOS_APOS, QN_QUOTAS_APOS, QN_DIAS_FDT_APOS, IN_MOTIVO_AIIM, IN_MOTIVO_PONTUACAO, DS_FUNCAO_RESPONSAVEL_HOMOL, ID_RELATO_SITUACAO_HOMOL
--31040	 1	    57207   	2017    9       1892        	0	             30                 1892	        0	            3                   0	            1               1	Assistente de Inspetor	    1532822

select *
from pgsf.TB_BOLETIM_CORRECAO
where 
(nr_fiscal = 90065  and nr_ano = 2016 and nr_mes =  9) OR
(nr_fiscal = 87303  and nr_ano = 2017 and nr_mes =  4) OR
(nr_fiscal = 57207  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 16874  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 94599  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 25000  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 85367  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 31000  and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 172252 and nr_ano = 2018 and nr_mes = 12) OR
(nr_fiscal = 15274  and nr_ano = 2018 and nr_mes = 12)

select *
FROM pgsf.TB_RMA
where nr_ano = 2018 and nr_mes = 3
and nr_fiscal = 94599

25000,
85367,
31000,
172252,
15274)

select rsA.nr_fiscal, rsA.nr_mes, rsA.nr_ano, rsA.id_situacao_relato, to_char(rsA.dt_alteracao, 'DD/MM/YYYY HH24:MM'), rsB.nr_fiscal, rsB.nr_mes, rsB.nr_ano, rsB.id_situacao_relato, to_char(rsB.dt_alteracao, 'DD/MM/YYYY HH24:MM')
from pgsf.tb_relato_situacao rsA
join pgsf.tb_relato_situacao rsB
on rsA.nr_ano = rsB.nr_ano
and rsA.nr_mes = rsB.nr_mes
and rsA.nr_fiscal = rsB.nr_fiscal
and rsA.dt_alteracao < rsB.dt_alteracao
where 
rsB.id_situacao_relato = 25
and 
rsA.id_situacao_relato = 60
and
rsB.dt_alteracao = (select min(dt_alteracao) from pgsf.tb_relato_situacao where nr_ano = rsB.nr_ano and nr_mes = rsB.nr_mes and nr_fiscal = rsB.nr_fiscal and dt_alteracao > rsA.dt_alteracao)

--id_situacao_relato = 25 and
--nr_fiscal = 86645 and 
nr_fiscal = 17787 and 
nr_ano = 2018 and nr_mes = 12
order by dt_alteracao


select *
FROM pgsf.TB_RMA
where nr_ano = 2018 
AND   nr_mes in (3,12)
AND   nr_fiscal = 94599

SELECT rs.nr_fiscal, rs.nr_mes, rs.id_relato_situacao, id_situacao_relato, sr.ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS')
FROM  pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
WHERE nr_ano = 2018 
AND   nr_mes in (3,12)
AND   nr_fiscal = 94599
ORDER BY dt_alteracao


select *
from  pgsf.tb_relato_situacao
where nr_ano = 2018 
AND   nr_fiscal = 94599
AND   nr_mes = 3
ORDER BY dt_alteracao




SELECT RS.ID_RELATO_SITUACAO, RS.ID_SITUACAO_RELATO, BC.ID_RELATO_SITUACAO_HOMOL, RMA.ID_RMA
FROM pgsf.TB_BOLETIM_CORRECAO BC 
JOIN pgsf.TB_RMA RMA 
ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) 
JOIN  pgsf.TB_RELATO_SITUACAO RS 
ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE))
WHERE 
  RS.ID_SITUACAO_RELATO = 61 and
  (
(RS.nr_fiscal = 90065  and RS.nr_ano = 2016 and RS.nr_mes =  9) OR
(RS.nr_fiscal = 87303  and RS.nr_ano = 2017 and RS.nr_mes =  4) OR
(RS.nr_fiscal = 57207  and RS.nr_ano = 2017 and RS.nr_mes =  9) OR
(RS.nr_fiscal = 16874  and RS.nr_ano = 2017 and RS.nr_mes =  9)
)
--ID_RELATO_SITUACAO, ID_SITUACAO_RELATO, ID_RELATO_SITUACAO_HOMOL, ID_RMA
--1518602           	61              	1532822	                139966
--1518613	            61	                1532823	                139970
--1522499	            61	                1532824	                131874
--1522499	            61	                1483092	                131874
--1527087	            61	                1532821	                118667

SELECT id_relato_situacao, nr_ano, nr_mes, nr_fiscal, id_situacao_relato
FROM pgsf.TB_RELATO_SITUACAO
where id_relato_situacao in
(1532822,
1532823,
1532824,
1483092,
1532821)
order by nr_fiscal;

SELECT *
FROM pgsf.TB_RELATO_SITUACAO
where id_relato_situacao in
(1532824,
1483092,
1522499
)
order by nr_fiscal;

SELECT id_relato_situacao, nr_ano, nr_mes, nr_fiscal, id_situacao_relato
FROM pgsf.TB_RELATO_SITUACAO
where id_relato_situacao in
(1518602,
1518613,
1522499,
1527087)
order by nr_fiscal



select * from pgsf.tb_rma
where id_rma = 139966
--ID_RELATO_SITUACAO_HOMOL = 1339153



 SELECT
    BC.ID_BC,          
    BC.QN_PONTOS_APOS - BC.QN_PONTOS_ANTES DELTA_PTS,
    BC.QN_QUOTAS_APOS - BC.QN_QUOTAS_ANTES DELTA_QTS
  FROM
    pgsf.TB_BOLETIM_CORRECAO BC JOIN pgsf.TB_RELATO_SITUACAO RS ON 
        (BC.NR_FISCAL = RS.NR_FISCAL AND BC.NR_MES = RS.NR_MES AND BC.NR_ANO = RS.NR_ANO)
  WHERE RS.ID_SITUACAO_RELATO = 70 
    AND RS.IN_ATIVO = 1
    AND RS.NR_ANO >= 2015
    AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
    AND (RS.NR_FISCAL = 57207 OR 57207 = -1)
    AND (RS.NR_MES = 9 OR 9 = -1)
    AND (RS.NR_ANO = 2017 OR 2017 = -1);



select *
from pgsf.TB_RELATO_SITUACAO RS
  WHERE 
  --RS.ID_SITUACAO_RELATO = 70 
    RS.IN_ATIVO = 1
    AND RS.NR_ANO >= 2015
    AND RS.NR_FISCAL = 57207
    AND RS.NR_MES = 9
    AND RS.NR_ANO = 2017


select *
from pgsf.tb_dom_situacao_relato

--ID_SITUACAO_RELATO, DS_SITUACAO_RELATO
--1                 	Em elabora��o
--5	                    Devolvido para corre��o pela aprova��o
--6	                    Devolvido para corre��o pela Homologa��o
--10	                Fechado
--20	                Aprovado
--25	                Pronto para ser Homologado
--30	                Homologado
--40	                Pronto para ser enviado ao RH
--49	                Devolvido para corre��o pelo RH - Aguardando Notifica��o
--50	                Enviado para o RH
--60	                Averbado
--61	                BC em andamento em outra equipe
--70	                BC pronto para ser enviado ao RH
--79	                BC devolvido para corre��o pelo RH - Aguardando Notifica��o
--80	                BC enviado para o RH
--90	                BC Averbado
--48	                Devolvido para corre��o pelo RH
--78	                BC devolvido para corre��o pelo RH


select *
from pgsf.TB_BOLETIM_CORRECAO BC 
where id_bc = 31040   

select *
from pgsf.TB_RMA RMA
where id_rma = 139966


SELECT RS.ID_RELATO_SITUACAO, BC.ID_RELATO_SITUACAO_HOMOL, RMA.ID_RMA
FROM pgsf.TB_BOLETIM_CORRECAO BC 
JOIN pgsf.TB_RMA RMA 
ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) 
JOIN  pgsf.TB_RELATO_SITUACAO RS 
ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE))
WHERE 
--RS.ID_SITUACAO_RELATO = 70 AND 
  RS.IN_ATIVO = 1 AND 
  --AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
  (RS.NR_FISCAL = 57207)
  AND (RS.NR_MES = 9)
  AND (RS.NR_ANO = 2017);

--ID_RELATO_SITUACAO, ID_RELATO_SITUACAO_HOMOL, ID_BC,  ID_RMA
-- 1518602	           1532822	                 31040   139966

