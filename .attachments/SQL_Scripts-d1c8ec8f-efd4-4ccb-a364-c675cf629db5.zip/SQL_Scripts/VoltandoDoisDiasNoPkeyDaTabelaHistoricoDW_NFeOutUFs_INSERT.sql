insert into [NFe_Out_UFs].[Extracao].[HistoricoExtracaoDW](pKeyInicial, pKeyFinal, timestampReg)
values (1035262700, 1036048277, GETDATE());
