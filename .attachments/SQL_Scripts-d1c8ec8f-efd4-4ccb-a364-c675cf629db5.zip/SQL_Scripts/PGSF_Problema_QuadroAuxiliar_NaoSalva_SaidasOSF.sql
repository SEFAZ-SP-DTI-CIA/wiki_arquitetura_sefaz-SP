
--query abaixo seleciona OSF e relatos em que um AFR ativo na OSF j� est� homologado e outro AFR tamb�m ativo na OSF n�o est� homologado
select osf.id_osf, osf.NUM_OSF, rs1.ID_RELATO_SITUACAO, rs2.ID_RELATO_SITUACAO, rs1.id_situacao_relato, sit1.DS_SITUACAO_RELATO, rs2.id_situacao_relato,  sit2.DS_SITUACAO_RELATO, rs1.nr_mes, rs1.nr_ano, rs2.nr_mes, rs2.NR_ANO, fis1.nom_fiscal, eq1.id_drt, eq1.nom_equipe, fis2.nom_fiscal, eq2.id_drt, eq2.nom_equipe
from ordem_servico_fiscal osf
join osf_executante exe1
on exe1.id_osf = osf.ID_OSF
and (exe1.DTC_FIM is null OR exe1.DTC_FIM >= osf.dtc_conclusao)
--and osf.dtc_conclusao > to_date('01-02-2017', 'dd-mm-yyyy')
join osf_executante exe2
on exe2.id_osf = osf.id_osf
and exe2.NUM_FISCAL <> exe1.NUM_FISCAL
and (exe2.DTC_FIM is null OR exe2.DTC_FIM >= osf.dtc_conclusao)
join tb_relato_situacao rs1
on rs1.nr_fiscal = exe1.NUM_FISCAL
and rs1.IN_ATIVO = 1
and rs1.ID_SITUACAO_RELATO < 60--averbado
and rs1.ID_SITUACAO_RELATO > 10--fechado
and rs1.nr_ano > 2016
and to_date('28/'||rs1.nr_mes||'/'||rs1.nr_ano, 'dd/mm/yyyy') > osf.dtc_conclusao
join tb_relato_situacao rs2
on rs2.nr_fiscal = exe2.NUM_FISCAL
and rs2.IN_ATIVO = 1
and rs1.ID_SITUACAO_RELATO < 90--averbado
and rs1.ID_SITUACAO_RELATO > 10--fechado
and rs2.nr_ano > 2016
and to_date('01/'||rs2.nr_mes||'/'||rs2.nr_ano, 'dd/mm/yyyy') < osf.dtc_conclusao
join tb_dom_situacao_relato sit1
on sit1.ID_SITUACAO_RELATO = rs1.ID_SITUACAO_RELATO
join tb_dom_situacao_relato sit2
on sit2.ID_SITUACAO_RELATO = rs2.ID_SITUACAO_RELATO
join fiscal fis1
on fis1.num_fiscal = rs1.nr_fiscal
join fiscal fis2
on fis2.num_fiscal = rs2.nr_fiscal
join equipe eq1
on eq1.id_equipe = rs1.id_equipe
join equipe eq2
on eq2.id_equipe = rs2.id_equipe
--where osf.DTC_TERMINO_ACAO > to_date('01/02/2017', 'dd/mm/yyyy')
order by osf.id_osf, exe1.ID_USUARIO

select *
from tb_rma
where nr_mes = 9
and nr_ano = 2017
and nr_fiscal = 21780

select *
from tb_relato_situacao
where dt_alteracao >= to_date('16/10/17','dd/mm/yy')

select *
from tb_relato_situacao
where nr_mes = 9
and nr_ano = 2017
and nr_fiscal in (5426,18822,25851,20312,334264,93730,21481,21973,11682,5323,170991,23519,21780)
and in_ativo = 0
order by id_relato_situacao desc

delete
from tb_relato_situacao
where dt_alteracao >= to_date('16/10/17','dd/mm/yy')

update tb_relato_situacao
set in_ativo = 1
where id_relato_situacao in (1340759,1340748,1340747,1340746,1340745,1340744,1340743,1340742,1340741,1340740,1340739,1340738,1340737)

select *
from osf_executante
where id_osf = 850294

select *
from equipe_membro
where num_fiscal in (33460,58327,68710,78107,78727,78790,78983,78995,79057,84958,86440,86542,86591,87017,87595,87777,87960,88083,93182,93194,93534,93650,93868,94241,95520,172045,172471,172793,173487,173888,319846,319974,320848,336753)
and (dtc_fim_membro is null or dtc_fim_membro > to_date('01/09/2017','dd/mm/yyyy'))
and dtc_inicio_membro < to_date('30/09/2017','dd/mm/yyyy')
order by dtc_inicio_membro desc

select *
from equipe_membro
where num_fiscal = 33460
order by dtc_inicio_membro 

select *
from equipe
where id_equipe = 116

--id_osf 905482, num osf 05001357172
--num_fiscal 58327 e  93182
--id_equipe 116
--periodo 9/2017 e 10/2017
--conclusao OSF 25/9/2017

select *
from tb_dom_situacao_relato