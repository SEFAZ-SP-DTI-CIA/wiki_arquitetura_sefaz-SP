
set serveroutput on

DECLARE 
  CUR_OUT SYS_REFCURSOR;    
  STR1 VARCHAR2(2000);
  STR2 VARCHAR2(2000);
  STR3 VARCHAR2(2000);
  STR4 VARCHAR2(2000);
  STR5 VARCHAR2(2000);
  STR6 VARCHAR2(2000);
BEGIN

    PGSF.PKG_RELATO_TAKA.USP_OBTER_FREQUENCIA_FISCAL(86104, 2016, 12, CUR_OUT);        

    
    LOOP
    FETCH CUR_OUT INTO STR1, STR2, STR3, STR4, STR5, STR6;
    EXIT WHEN CUR_OUT%NOTFOUND;    
    
    IF (LENGTH(STR6) > 0) THEN
	  dbms_output.put_line('ENCONTROU:');
      dbms_output.put_line(STR1);
      dbms_output.put_line(STR2);
      dbms_output.put_line(STR3);
      dbms_output.put_line(STR4);
      dbms_output.put_line(STR5);
      dbms_output.put_line(STR6);
	ELSE
      dbms_output.put_line('N�O ENCONTROU');
    END IF;
    END LOOP;
  CLOSE CUR_OUT;
  
END;
