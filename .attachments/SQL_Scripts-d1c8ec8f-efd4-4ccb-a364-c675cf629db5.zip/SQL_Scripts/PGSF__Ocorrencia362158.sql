-- Base XtempX => DEV
-- encontrar um relato de equipe averbada: encontrado relato de Dez/2015 da equipe DRTC-III 54 
-- usp_enviar_bcs: rodar para todos
-- usp_atualizar_status_bc (op��o "averbar" - status 90): rodar para 1+
-- devolver um BC que esteja enviado para RH, mas que n�o esteja averbado
-- usp_atualizar_status_bc (op��o "devolver" - status 79): � esperado que n�o consiga

-- * h� altera��o em 1/1/2015 que dificulta teste em relatos anteriores a essa data

---------------------------------------------------
-- Dez/2015 DRTC-III 54 (id_equipe = 214) (temp)
-- o BC 10187 dessa equipe refere-se a um fiscal que n�o fez parte de outra equipe no per�odo. Por�m a equipe possui um BC j� averbado nesse per�odo
-- N�O FOI POSS�VEL ALTERAR O STATUS DO BC 10187 POIS J� EXISTE(M) RMA(S) OU BC(S) AVERBADOS NA(S) EQUIPE(S),214. CORRE��ES DEVEM SER EFETUADAS ATRAV�S DE BC (BOLETIM DE CORRE��O).

-- Nov/2015 DRTC-I 11 (id_equipe = 134) (dev)
-- essa equipe est� com RMA averbado (status 60) nesse per�odo, com AFR que produziu pontos em outra equipe
-- simulei BC e habilitei homolga��o por debug
-- enviei BC para RH (n�o tem BC averbado nessa equipe)
-- na outra equipe, 12 da mesma DRT, tem BC averbado
-- ao executar a proc USP_ATUALIZAR_STATUS_RMA_BC, retorna a mensagem abaixo:
-- N�O FOI POSS�VEL ALTERAR O STATUS DO BC 8147 POIS J� EXISTE(M) RMA(S) OU BC(S) AVERBADOS NA(S) EQUIPE(S),173. CORRE��ES DEVEM SER EFETUADAS ATRAV�S DE BC (BOLETIM DE CORRE��O).


-- ap�s mudan�as na proc e fun��o:
-- o retorno para o caso de ter algum BC averbado na equipe muda para:
-- N�O FOI POSS�VEL ALTERAR O STATUS DO BC 8147 POIS J� EXISTE(M) BC(S) AVERBADOS NA EQUIPE EM QUEST�O: 134. CORRE��ES DEVEM SER EFETUADAS ATRAV�S DE BC (BOLETIM DE CORRE��O).
-- o retorno para o caso de n�o ter BC averbado na equipe (mesmo que tenha BC averbado em outra equipe que o AFR tenha feito parte naquele m�s):
-- O STATUS DO BC 8147 FOI ATUALIZADO COM SUCESSO.

-- terceiro teste:
-- 3 equipes em cascata: DRT-03, equipes 12 22 31 (123 126 1124), AFR UBIRACY COZENDEY SEPULVIDA (num_fiscal = 251991) (mar/2015)
-- status RMA 82988 do AFR ANT�NIO GUERRA (num_fiscal = 85021) atualizado de 50 para 60 usando proc "USP_ATUALIZAR_STATUS_RMA" em mar/2015 (faz parte da equipe 31)
-- status RMA 82023 do AFR ALEXANDRE DE ARAUJO LIMA (num_fiscal = 318910) atualizado de 50 para 60 usando proc "USP_ATUALIZAR_STATUS_RMA" em mar/2015 (faz parte da equipe 22)
-- ao tentar devolver RMA do AFR UBIRACY na equipe 12 (em que todos os relatos est�o com status 50 "Enviado ao RH"), retornou abaixo:
-- N�O FOI POSS�VEL ALTERAR O STATUS DO RMA 83023 POIS J� EXISTE(M) RMA(S) AVERBADOS NA(S) EQUIPE(S) 126,1124. CORRE��ES DEVEM SER EFETUADAS ATRAV�S DE BC (BOLETIM DE CORRE��O).

-- repetindo teste 2 com outra equipe, movendo status com proc (ao inv�s de update em BD), s� para confirmar
-- AFR LUIS ALVARO LEITE CASAGRANDE (num_fiscal = 334264) faz parte das equipes id 155 e 156 (53 e 54 da DRTC-I) em 11/2015
-- a equipe 54 tem todos os BCs prontos para envio ao RH
-- AFR DOMINIQUE CHRISTINE MIRANDA MARQUEZINI (num_fiscal = 333351) faz parte das equipes id 134 e 155 (11 e 53 da DRTC-I) em 11/2015
-- a equipe 53 tem RMAs averbados e um BC em andamento em outra equipe (para LUIS ALVARO LEITE CASAGRANDE)
-- AFR VALNEUSA RIBEIRO DOS SANTOS (num_fiscal = 23260) faz parte da equipe  155 
-- a equipe 11 tem todos os BCs prontos para envio ao RH
-- BC 8153 foi averbado da VANESSA foi averbado para o teste, usando a proc
-- AFR WANDERLEY DUARTE CASTANHEIRA (num_fiscal = 23519) s� faz parte da equipe 54 DRTC-I (id_equipe 156)
-- BC 8188 do WANDERLEY ser� enviado ao RH: sucesso
-- BC 8188 do WANDERLEY ser� devolvido pelo RH (status 79): sucesso, como esperado, mesmo tendo BCs averbados em outras equipes em que AFR da mesma equipe fa�a parte


---------------------------------------------------

select eq.nom_equipe, dr.nom_drt, re.nr_mes, re.nr_ano--, re.DT_ALTERACAO, re.id_situacao_relato, 
from tb_relato_situacao re
join equipe eq
on eq.id_equipe = re.ID_EQUIPE
join drt dr
on dr.id_drt = eq.ID_DRT
where re.nr_ano >= 2015
and   re.id_situacao_relato > 40
and eq.ID_DRT = 18
group BY eq.nom_equipe, dr.nom_drt, re.nr_mes, re.nr_ano--, re.DT_ALTERACAO desc
order by eq.nom_equipe, dr.nom_drt, re.nr_mes, re.nr_ano--, re.DT_ALTERACAO desc
;

-- listando relatos de 2015+, averbados, sem BC, em que o AFR participou de mais de uma equipe
select re.nr_fiscal,re.nr_mes, re.nr_ano, count(1) --eq.nom_equipe, dr.nom_drt, re.nr_mes, re.nr_ano, re.*
from tb_relato_situacao re
join equipe eq
on eq.id_equipe = re.ID_EQUIPE
join drt dr
on dr.id_drt = eq.ID_DRT
where re.nr_ano >= 2015
and   re.id_situacao_relato = 60 --averbado
and   concat(re.nr_ano,concat(re.nr_mes,concat(re.id_equipe, re.nr_fiscal))) not in
(
select concat(nr_ano,concat(nr_mes,concat(id_equipe, nr_fiscal)))
from tb_relato_situacao re
where re.nr_ano >= 2015
and   re.id_situacao_relato > 60 --n�o tem BC
)
group by re.nr_fiscal, re.nr_mes, re.nr_ano
having count(1) > 1
--170802	9	2015	2
--85756	10	2015	2
--11682	11	2015	2
--85021	3	2015	2
--29169	11	2015	2
--334264	11	2015	2
--85938	9	2015	2
--19930	11	2015	2
--47147	10	2015	2
--22345	11	2015	2


--order by nr_Fiscal, re.nr_mes desc, re.nr_ano desc, eq.nom_equipe, dr.nom_drt--, re.DT_ALTERACAO desc
;


select *
from tb_relato_situacao re
join equipe eq
on eq.id_equipe = re.ID_EQUIPE
where 
--re.id_equipe = 173
re.nr_fiscal = 23519
and re.nr_ano = 2015
and re.nr_mes = 11
and re.in_ativo=1
order by dt_alteracao desc
;

select * from TB_RMA
where nr_ano = 2015
and nr_mes = 11
and nr_fiscal = 23260
and id_equipe = 155


update tb_relato_situacao re
set id_situacao_relato = 50
where 
re.id_equipe in (123, 126, 1124)
and re.nr_ano = 2015
and re.nr_mes = 3
and re.in_ativo=1
and re.nr_fiscal = 23519



select bc.*
from tb_boletim_correcao bc
where bc.id_bc = 8147
-- id_relato_situacao_homol 544493

select rs.id_equipe 
from tb_relato_situacao rs
join tb_boletim_correcao bc
on rs.id_relato_situacao = bc.id_relato_situacao_homol
and bc.id_bc = 8147

select * from equipe
where id_equipe in (134,155)

select * from equipe_membro
where num_fiscal = 251991
and dtc_fim_membro is null



 SELECT  RS.NR_ANO,
                RS.NR_MES,
                RS.ID_EQUIPE,                
                RS.NR_FISCAL,
                RS.QT_DIAS_RELATADOS,
                RS.ID_SITUACAO_RELATO,
                RS.NR_FISCAL_RESP,
                RS.ID_EQUIPE_DEAT,
                RS.IN_BC
        FROM TB_BOLETIM_CORRECAO BC, TB_RELATO_SITUACAO RS
        WHERE BC.NR_FISCAL = RS.NR_FISCAL AND 
              BC.NR_MES = RS.NR_MES AND 
              BC.NR_ANO = RS.NR_ANO AND 
              BC.ID_BC = 8147 AND
              IN_ATIVO = 1;
              
              
select * from TB_BOLETIM_CORRECAO              
where nr_fiscal = 23519
and nr_mes = 11
and nr_ano = 2015
              
--procurar caso em que h� cascata em 3+ equipes:
select * 
from equipe_membro em1
join equipe_membro em2
using (dtc_inicio_membro)
where em1.id_equipe = em2.id_equipe
and em1.num_fiscal <> em2.num_fiscal
order by DTC_INICIO_MEMBRO

--04/08/15	170723	421
--04/08/15	52167	421

--14/03/15	48425	126
--14/03/15	251991	126

select *
from fiscal fi
join equipe_membro eqm
using (num_fiscal)
join equipe eq
using (id_equipe)
join drt
using (id_drt)
where num_fiscal = 23260

select * from fiscal
where nom_fiscal = 'WANDERLEY DUARTE CASTANHEIRA'

