
SELECT TOP 100 e.timestampReg, te.descricao, tr.descricao, r.valor, e.idTipoLogEPEC
  FROM NFCe_EPEC_Dados.EPEC.LogEPEC e (NOLOCK)
  JOIN NFCe_EPEC_Dados.EPEC.RegistroLogEPEC r (NOLOCK)
  on r.fkLogEPEC = e.pKey
  JOIN NFCe_EPEC_Dados.EPEC.TipoLogEPEC te (NOLOCK)
  on te.id = e.idTipoLogEPEC
  JOIN NFCe_EPEC_Dados.EPEC.TipoRegistroLogEPEC tr (NOLOCK)
  on tr.id = r.idTipoRegistroLogEPEC
  where --tr.descricao = 'MensagemDeErro' and 
  --e.idTipoLogEPEC <> 2 and
  --te.descricao = 'Servi�o de Ativacao/Desativa��o de EPEC' and
  --tr.descricao <> 'StackTrace' and
  e.timestampReg > DATEADD(day,-3, GETDATE())
  order by e.timestampReg desc

  return

  


  select * from NFCe_EPEC_Constraint.EPEC.ConfigSistema_LOG (NOLOCK)
  where dtAlteracaoReg > DATEADD(DAY,-10,GETDATE())
  order by dtAlteracaoReg desc

  select * from NFCe_EPEC_Constraint.EPEC.Dados_EPEC with (nolock)
  where timestampReg > DATEADD(day,-30,GETDATE())
  order by timestampReg desc

select top 1000 *
from NFCe_EPEC_Constraint.EPEC.ConfigSistema


select cStat, count(1) from NFCe_EPEC_Dados.EPEC.ProtocoloRejeitado
where timestampReg between '2020-01-01' and '2020-04-01'
group by cStat

DECLARE @StartDate SMALLDATETIME = '2020-04-12 00:00';
DECLARE @EndDate SMALLDATETIME   = '2020-04-12 23:59:59';
WITH cte AS
(
SELECT @startdate DateValue
UNION ALL
SELECT DATEADD (MINUTE, 1, DateValue)
FROM cte 
WHERE  DATEADD (MINUTE, 1, DateValue) < @enddate
)
SELECT c.DateValue as minuto, COUNT(p.chNFCe) AS protocolos
FROM cte c
LEFT JOIN NFCE_EPEC_CONSTRAINT.EPEC.Dados_EPEC p (NOLOCK)
ON c.DateValue = cast(p.timestampReg AS SMALLDATETIME)
GROUP BY c.DateValue
ORDER BY c.DateValue ASC
OPTION (MAXRECURSION 0, MAXDOP 4)



select top 200 * from NFCe_EPEC_Dados.EPEC.ProtocoloRejeitado order by pKey desc
select top 200 * from [NFCe_EPEC_XML].[EPEC].[ProtocoloRejeitadoXml] order by timestampReg desc

select top 100 SUBSTRING(r.chNFCe, 26,9), CAST(DECOMPRESS(x.evento) AS XML).value('(/evento/@versao)[1]', 'char(9)')
from [NFCe_EPEC_Dados].[EPEC].[ProtocoloRejeitado] r
join [NFCe_EPEC_XML].[EPEC].[ProtocoloRejeitadoXml] x
on x.pKey = r.pKey and x.timestampReg = r.timestampReg
order by r.timestampReg desc

select top 10 c.pKey, c.timestampReg, cast(decompress(x.evento) as xml)
from NFCe_EPEC_Constraint.EPEC.EPEC_Constraint c
JOIN NFCe_EPEC_XML.EPEC.EventoXml x
on x.pKey = c.pKey
order by c.timestampReg desc

select top 10 * 
from NFCe_EPEC_Dados.EPEC.ValidacaoCertificado
order by timestampReg desc

select * 
from NFCe_EPEC_Dados.EPEC.ConciliacaoPendente p
join NFCE_EPEC_CONSTRAINT.EPEC.Dados_EPEC d
on d.pKey = p.pKey