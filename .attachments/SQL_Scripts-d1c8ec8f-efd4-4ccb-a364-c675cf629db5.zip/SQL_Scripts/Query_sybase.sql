--update ods.tb_dsod_nfe_controle_execucao set cod_status = 1; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 1;
--update ods.tb_dsod_nfe_controle_execucao set cod_status = 2; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 2;
--update ods.tb_dsod_nfe_controle_execucao set cod_status = 5; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 5;
--update ods.tb_dsod_nfe_controle_execucao set cod_status = 0; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 0;
commit;
select * from ods.tb_dsod_nfe_controle_execucao
select * from ods.tb_dsod_nfeuf_controle_execucao

commit;select * from ods.tb_dsod_nfce_controle_execucao

commit;select * from ods.tb_dsod_mdfe_controle_execucao
commit; select * from ods.tb_dsod_mdfe_tmp_ide

commit;select * from ods.tb_dsod_ccc_controle_execucao



select * from ods.tb_dsod_nfeuf_reextracao_ip_transmissor



select count(1)
from ods.tb_dsod_mdfe_ide




select * from ods.tb_dsod_nfe_tmp_doc_fiscal

select * from ods.tb_dsod_nfe_tmp_transmissorv
select * from ods.tb_dsod_nfce_tmp_doc_fiscal_prod_rastreab		


select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod

select count(1) from ods.tb_dsod_nfce_tmp_doc_fiscal_prot_rec

select * from ods.tb_dsod_nfe_tmp_forma_pagto

commit;
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec      

commit;
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec      noholdlock
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prod   noholdlock
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal   noholdlock

select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec      noholdlock
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod   noholdlock
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal   noholdlock


select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod   noholdlock
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal   noholdlock


select * from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret  noholdlock
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr noholdlock
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_transp        noholdlock


select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen;
select * from ods.tb_dsod_nfe_tmp_evt_pedido_corindus
select * from ods.tb_dsod_nfe_tmp_evt_pedido_corindus_item

select * from ods.tb_dsod_nfe_tmp_partilha_icms

SELECT CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal, * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL
SELECT CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal, * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NOT NULL

SELECT * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL
SELECT * FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao IS NULL
order by chave_acesso_nota_fiscal desc

commit;
SELECT COUNT(1) FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL --
SELECT COUNT(1) FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao > '2018-08-08'
commit;
SELECT COUNT(1) FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao IS NULL


SELECT COUNT(1) FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao > '2018-08-08'
SELECT *  FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao > '2018-08-07'

order by data_extracao desc

commit;
select * from ods.tb_dsod_mdfe_tmp_eventos_gen where num_cpf      is not null
select * from ods.tb_dsod_mdfe_tmp_ide         where num_cpf_emit is not null


delete from [ods].[tb_dsod_nfe_reextracao]
commit;

SELECT * FROM [ods].[tb_dsod_nfe_reextracao] WHERE chave_acesso_nota_fiscal = 35110107576934000115550010000000010010520676

update  [ods].[tb_dsod_nfe_reextracao] 
35110107576934000115550010000000010010520676


--chave_acesso_nota_fiscal
SELECT * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao > '2018-04-09'


--select count(1) from ods.tb_dsod_nfe_reextracao

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prod
select count(1) from ods.tb_dsod_nfe_tmp_partilha_icms


commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao_prod
commit;select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao_prod

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec noholdlock

commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec     noholdlock --9405819553
commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen      noholdlock --9405819655
commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao noholdlock --9405738590
commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_cancel       noholdlock --

commit;select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec   noholdlock
commit;select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen    noholdlock
commit;select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec noholdlock
commit;select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen  noholdlock


LOAD TABLE ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen(cod_amarracao_arquivo, id_evento, ind_tipo_ambiente, num_versao_leiaute, num_versao_aplicativo, cod_est_evento, num_ano, cod_receptor, cod_status, chave_acesso_nota_fiscal, data_evento, ind_tipo_evento, num_seq_evento, num_cnpj_cpf_dest, descr_email, num_protocolo, data_registro, cod_orgao_pk, ind_tipo_dest, id_autor, ind_tp_id_autor, num_ip_transmissor, data_extracao_arquivo DATETIME('yyyy-mm-dd hh:nn:ss.sssss') NULL('00000000000000',Blanks), ind_origem, filler('\x0D\x0A')) USING CLIENT FILE 'D:/DISK19/NFeOutUFs/20180417000000-NFe_Evento_Generico.txt' DELIMITED BY '\xFF' ESCAPES OFF QUOTES OFF CHECK CONSTRAINTS ON IGNORE CONSTRAINT UNIQUE 0;

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen noholdlock
where chave_acesso_nota_fiscal = 35180372381189001001550010001630691944254837

select * from ods.ods.tb_dsod_nfe_tmp_evt_mdfe noholdlock
where cod_amarracao_arquivo = 9292227225
where cod_amarracao_arquivo = 9292227225

select * from ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit noholdlock
where cod_amarracao_arquivo = 9292227225

select chave_acesso_nota_fiscal from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen noholdlock
where ind_tipo_evento = '610510'
group by ind_tipo_evento
order by ind_tipo_evento
-- ('610500', '610501', '610510', '610511', '610514', '610515', '610550', '610552', '610554', '610610', '610611', '610614', '610615')

ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
ods.ods.tb_dsod_nfe_tmp_evt_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit
ods.tb_dsod_nfe_tmp_evt_canc_mdfe

update ods.tb_dsod_nfe_reextracao
set data_extracao = '01/01/2001'
 WHERE data_extracao is null;
commit;

SELECT DISTINCT TOP 2 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL 

select count(1) FROM ods.tb_dsod_nfe_reextracao WHERE data_extracao is null;
delete FROM ods.tb_dsod_nfe_reextracao WHERE data_extracao is null;

insert into ods.tb_dsod_nfe_reextracao (chave_acesso_nota_fiscal, ref_mes_emissao)
values
(35110900608804000178550010001501442082911075,201109),
(35121144110229000154550010000200201001680200,201211)



select data_extracao, count(1) FROM ods.tb_dsod_nfe_reextracao 
group by data_extracao

SELECT DISTINCT TOP 5000 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_reextracao WHERE data_extracao is  null;
LOAD TABLE ods.tb_dsod_nfe_tmp_evt_mdfe(cod_amarracao_arquivo, num_versao_leiaute, descr_evento, cod_orgao_autor, ind_tp_autor, num_ver_aplic, Data_extracao DATETIME('yyyy-mm-dd hh:nn:ss.sssss') NULL('00000000000000',Blanks), ind_origem, nome_arquivo, filler('\x0D\x0A')) USING CLIENT FILE 'D:/DISK/NFeOut/20180301000000-NFe_Evento_MDFe.txt' DELIMITED BY '\xFF' ESCAPES OFF QUOTES OFF CHECK CONSTRAINTS ON IGNORE CONSTRAINT UNIQUE 0;
LOAD TABLE ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen(cod_amarracao_arquivo, id_evento, ind_tipo_ambiente, num_versao_leiaute, num_versao_aplicativo, cod_est_evento, num_ano, cod_receptor, cod_status, chave_acesso_nota_fiscal, data_evento, ind_tipo_evento, num_seq_evento, num_cnpj_cpf_dest, descr_email, num_protocolo, data_registro, cod_orgao_pk, ind_tipo_dest, id_autor, ind_tp_id_autor, num_ip_transmissor, data_extracao_arquivo DATETIME('yyyy-mm-dd hh:nn:ss.sssss') NULL('00000000000000',Blanks), ind_origem, filler('\x0D\x0A')) USING CLIENT FILE 'D:/DISK/NFeOut/20180301000000-NFe_Evento_Generico.txt' DELIMITED BY '\xFF' ESCAPES OFF QUOTES OFF CHECK CONSTRAINTS ON IGNORE CONSTRAINT UNIQUE 0;

ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
ods.ods.tb_dsod_nfe_tmp_evt_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit
ods.tb_dsod_nfe_tmp_evt_canc_mdfe

commit;
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal_cancel

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal_cancel

select cod_est_evento, num_protocolo , count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
group by cod_est_evento, num_protocolo
having count(1) > 1

select *  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
where num_protocolo in (431376,445391,595789,1489659,1536442,1551955,1902430)
order by num_protocolo


select top 1 * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
where num_seq_evento > 2

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
where id_evento in ('6105001117120385389600634255002000001150102001150901', '6105001118010125799500080055001000135768100459136001', '6105001118010125799500080055001000135769100019325201', '6105001118010125799500080055001000135770100716632401', '6105001118010125799500080055001000135771100455872501', '6105001118010125799500080055001000135772100661302001', '6105001118011426305200016555001000000046104002469401', '6105001118012040056100019555001000000893120395051001', '6105001118012870622800011055001000000101150039300001', '6105001118016762037700747055001000001856100008959001', '6105001517120043604201803655000000002270100000001301', '6105001517120502562500020255020000066556100066556001', '6105001517120502562500020255020000066608100066608401', '6105001517120502562500071755020000007642100007642001', '6105001517120502562500071755020000007666100007666001', '6105001517121094065300010455001000030862100030862301', '6105001517121094065300010455001000030867100030867001', '6105001517121280538900012155001000010542100010542601', '6105001517121280538900012155001000010544100010544701', '6105001517128358377300025655001000000293100000293001', '6105001517128358377300050755001000000221100000221601', '6105002618010889353800018455001000002722120111017701', '6105005118010200340200246155010000088780100635969601', '6105005118010200340200246155010000088781100635972301', '6105005118010200340200246155012000299413100635571001', '6105005118010200340200246155012000299414100635572501', '6105005118010216598400051055002000004781155458852001', '6105005118010686600900016655001000001970100004842501', '6105005118018404610102470055101000194806172723767101', '6106103118012324395900015355001000171049100819591001', '6106103118012324395900015355001000171050100623132401', '6106103118012324395900015355001000171051100784875601', '6106103118012324395900015355001000171052100121363201', '6106103118012324395900015355001000171053100764946401', '6106103118012324395900015355001000171054100239327201', '6106103118012324395900015355001000171055100343515401', '6106103118012324395900015355001000171056100341514201', '6106103118012324395900015355001000171057100658569001', '6106103118012324395900015355001000171058100969141301', '6106103118012324395900015355001000171059100219591401', '6106103118012324395900015355001000171060100623532601', '6106103118012324395900015355001000171061100781875601', '6106103118012324395900015355001000171062100141363801', '6106103118012324395900015355001000171063100564946301')

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal_cancel


--update ods.tb_dsod_nfe_controle_execucao   set cod_status = 0
--update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 1
--commit;

--update ods.tb_dsod_mdfe_controle_execucao   set cod_status = 0


--select count(1) from ods.tb_dsod_ccc_cad_contribuinte



select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_reg_passagem_brid


select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao

select top(10) * from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret 
select top(10) * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_emit_loc_ret 

commit;
select *
from ods.tb_dsod_nfe_reextracao r



where data_extracao is null
join ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec p
on p.chave_acesso_nota_fiscal = r.chave_acesso_nota_fiscal

update ods.tb_dsod_nfe_reextracao
set data_extracao = GETDATE()
where chave_acesso_nota_fiscal < 35160899171171171115550011561149981195066938

insert into ods.tb_dsod_nfe_reextracao (chave_acesso_nota_fiscal, ref_mes_emissao)
values
(35170399171171171115550010000111751000111750, 201703)

--(35170399171171171115550011565752571195066938, 201703)

--(35161199171171171115550441563550341640030295, 201611),
--(35161299171171171115550441563650321640030298, 201612),
--(35161299171171171115550441563650341640030292, 201612)

--(35160999171171171115550011561250211195066935, 201609),
--(35161199171171171115550441563550321640030290, 201611)
--(35160899171171171115550011561250011195066939, 201608),
--(35160999171171171115550011561250191195066937, 201609)
--(35090959104422001806550080003670460384028700, 200909)
--(35160899171171171115550011561149981195066938, 201608)

commit;
select *
from ods.tb_dsod_nfe_reextracao
where data_extracao is null



select *
from ods.tb_dsod_nfe_reextracao 
WHERE data_extracao IS NULL AND chave_acesso_nota_fiscal IN (SELECT chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec)

select chave_acesso_nota_fiscal from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec

commit;
SELECT * FROM ods.tb_dsod_nfe_reextracao WHERE chave_acesso_nota_fiscal = 35110900608804000178550010001501442082911075

select *
from ods.tb_dsod_nfe_reextracao_intermediaria



--update ods.tb_dsod_nfe_reextracao set data_extracao = GETDATE() where chave_acesso_nota_fiscal < 35160899171171171115550011561149981195066938
--insert into ods.tb_dsod_nfe_reextracao(chave_acesso_nota_fiscal, ref_mes_emissao)values(35160899171171171115550011561149981195066938, 201608)

select *
from ods.tb_dsod_nfe_reextracao
WHERE data_extracao IS NOT NULL
 AND chave_acesso_nota_fiscal IN (SELECT chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec)

UPDATE ods.tb_dsod_nfe_reextracao SET data_extracao = GETDATE() WHERE data_extracao IS NULL AND chave_acesso_nota_fiscal IN (SELECT chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec)

SELECT DISTINCT TOP 10 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal 
FROM [ods].[tb_dsod_nfe_reextracao]
WHERE data_extracao IS NULL
COMMIT;


delete from ods.tb_dsod_nfe_reextracao




commit;
select * from ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal = 35110801510736000172550000000067371100067374


 
--22.646.934 - Mar 11
--22.646.944 - Set 18 (erro +10)
--31.744.843 - Abr 11
--42.033.400 - Mai 11
--52.007.070 - Jun 11
--62.203.076 - Jul 11
--72.598.831 - Ago 11
--81.545.222 - Set 11
--89.947.056 - Out 11
--98.656.524 - Nov 11
--107.144.512 - Dez 11
--115.619.007 - Jan 12
--124.837.956 - Fev 12
--135.361.243 - Mar 12
--144.852.143 - Abr 12
--155.409.515 - Mai 12
--165.120.433 - Jun 12
--175.197.968 - Jul 12
--185.463.422 - Ago 12
--194.225.819 - Set 12
--204.026.310 - Out 12
--213.526.860 - Nov 12
--222.301.594 - Dez 12
--231.910.729 - Jan 13
--241.242.432 - Fev 13
--251.653.882 - Mar 13
--263.812.737 - Abr 13
--275.839.747 - Mai 13
--287.311.235 - Jun 13
--299.783.625 - Jul 13
--312.159.315 - Ago 13
--323.687.583 - Set 13
--336.345.161 - Out 13
--348.061.231 - Nov 13
--359.104.182 - Dez 13
--370.077.891 - Jan 14
--380.648.310 - Fev 14
--391.086.722 - Mar 14
--401.399.271 - Abr 14
--411.980.450 - Mai 14
--421.597.170 - Jun 14
--432.807.258 - Jul 14
--444.891.611 - Ago 14
--456.524.358 - Set 14
--469.326.468 - Out 14
--494.124.274 - Nov 14

commit;
select count(1) from ods.tb_dsod_nfe_reextracao_ip_transmissor

select top 1 * from ods.tb_dsod_nfe_reextracao_ip_transmissor

select chave_acesso_nota_fiscal, count(1)
from ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal in
(
35141004337168000652550010066687401101588377,
35141004337168000652550010066687411101588382,
35141033200056000220550020016768441397437913,
35141033200056000220550020016768581571607020,
35141102549565000158550010000029411092000009,
35141167620377003130550010006628091006628094,
35141167620377003130550010006627961006627969,
35141106225746000180550030000250781999749216,
35141167620377003130550010006628131006628135,
35141167620377003130550010006628031006628031
)
group by chave_acesso_nota_fiscal

SELECT COUNT(1)
FROM ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal in (SELECT chave_acesso_nota_fiscal
      FROM ods.tb_dsod_nfe_reextracao_ip_transmissor
      WHERE ((chave_acesso_nota_fiscal / 100000000000000000000000000000000000000) -350000) > 1410
      GROUP BY chave_acesso_nota_fiscal
      HAVING COUNT(1) > 1)--24.715.056


select count(1)
from ods.tb_dsod_nfe_reextracao_ip_transmissor
where  chave_acesso_nota_fiscal = 35141004337168000652550010066687401101588377
