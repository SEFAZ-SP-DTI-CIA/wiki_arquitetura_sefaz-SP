update [NFe_Out_UFs].[Extracao].[HistoricoExtracaoDW]
set pKeyFinal = 1036048277
where id = 10633