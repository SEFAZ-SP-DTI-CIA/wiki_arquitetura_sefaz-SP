select *
from tb_relato_situacao rs
join equipe eq
on eq.ID_EQUIPE = rs.ID_EQUIPE
where rs.id_situacao_relato = 79
and rs.in_ativo = 1;

select *
from tb_boletim_correcao
where nr_mes = 12
and nr_ano = 2016
and nr_fiscal in (81155,
81301,
80771,
81684,
81301,
85872,
85598,
335281,
87571,
86013)
--16900 16901 16902 16903 16904 16905 16906 16907 16908

select *
from tb_relato_situacao
where id_relato_situacao in (974331,974332,974333,974334,974335,974336,974337,974338,974339,974340)


select *
from nf
where id_drt = 16

select *
from equipe  eq
join drt dr
on dr.id_drt = eq.id_drt
where 
eq.id_equipe = 11

select *
from fiscal fi
join equipe_membro eqm
on eqm.num_fiscal = fi.num_fiscal
and eqm.id_equipe = 11
and eqm.dtc_inicio_membro <= '31/12/2016'
and (eqm.dtc_fim_membro >= '01/12/2016' or dtc_fim_membro is null)
