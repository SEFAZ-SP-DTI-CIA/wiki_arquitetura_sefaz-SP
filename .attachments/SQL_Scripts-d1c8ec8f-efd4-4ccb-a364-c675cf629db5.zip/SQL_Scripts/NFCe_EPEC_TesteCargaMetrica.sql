
SELECT cast(DATEPART(hour, timestampReg) as varchar) + ':' +
       cast(DATEPART(MINUTE, timestampReg) as varchar) +':'+ 
       cast(DATEPART(SECOND, timestampReg) as varchar) Tempo
      ,count(1) Notas_Autorizadas
FROM [NFCe_EPEC_Constraint].[EPEC].[EPEC_Constraint] (NOLOCK)
where timestampReg > '2014-11-19 14:00'
group by DATEPART(hour, timestampReg)
        ,DATEPART(MINUTE, timestampReg) 
        ,DATEPART(SECOND, timestampReg)
order by DATEPART(hour, timestampReg)
        ,DATEPART(MINUTE, timestampReg) 
        ,DATEPART(SECOND, timestampReg)