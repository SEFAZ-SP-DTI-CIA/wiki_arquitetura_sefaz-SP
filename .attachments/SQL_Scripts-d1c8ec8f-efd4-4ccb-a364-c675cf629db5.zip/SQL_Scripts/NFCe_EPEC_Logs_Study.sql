SELECT datepart(month, e.timestampReg), datepart(day, e.timestampReg), datepart(hour, e.timestampReg), datepart(MINUTE, e.timestampReg), count(1)
  FROM NFCe_EPEC_Dados.EPEC.LogEPEC e (NOLOCK)
  JOIN NFCe_EPEC_Dados.EPEC.RegistroLogEPEC r (NOLOCK)
  on r.fkLogEPEC = e.pKey
  JOIN NFCe_EPEC_Dados.EPEC.TipoLogEPEC te (NOLOCK)
  on te.id = e.idTipoLogEPEC
  JOIN NFCe_EPEC_Dados.EPEC.TipoRegistroLogEPEC tr (NOLOCK)
  on tr.id = r.idTipoRegistroLogEPEC
  where timestampReg > '2019-01-01' and timestampReg < '2020-01-01' and idTipoLogEPEC <> 2 and idTipoLogEPEC <> 6 and idTipoLogEPEC <> 9 and idTipoLogEPEC < 9000 and idTipoRegistroLogEPEC < 1000 and valor not like 'Desativa��o%'  and valor not like 'Ligado em %' and valor not like 'Desligado em %'
  and valor <> 'Ativa��o Autom�tica por motivo "Detectado NFC-e offline"'
and valor <> 'Ativa��o Autom�tica por motivo "Falha verificando NFC-e online"'
and valor <> 'Ativa��o Autom�tica por motivo "Liga��o preventiva devido a falha de verifica��o em agendamento em execu��o"'
and valor <> 'Ativa��o Autom�tica por motivo "Liga��o preventiva devido a falha em banco de dados NFC-e"' 
and tr.descricao in ('MensagemDeErro', 'MensagemDeAviso')
  group by datepart(month, e.timestampReg), datepart(day, e.timestampReg), datepart(hour, e.timestampReg), datepart(MINUTE, e.timestampReg)
  order by datepart(month, e.timestampReg), datepart(day, e.timestampReg), datepart(hour, e.timestampReg), datepart(MINUTE, e.timestampReg)



    select datepart(month, dtAlteracaoReg), datepart(day, dtAlteracaoReg), datepart(hour, dtAlteracaoReg), datepart(MINUTE, dtAlteracaoReg), count(1)
	from NFCe_EPEC_Constraint.EPEC.ConfigSistema_LOG (NOLOCK)
	where parametro = 'ONLINE' and valor = 'ON' and dtAlteracaoReg > '2019-01-01'
	group by datepart(month, dtAlteracaoReg), datepart(day, dtAlteracaoReg), datepart(hour, dtAlteracaoReg), datepart(MINUTE, dtAlteracaoReg)
	order by datepart(month, dtAlteracaoReg), datepart(day, dtAlteracaoReg), datepart(hour, dtAlteracaoReg), datepart(MINUTE, dtAlteracaoReg)


	return





SELECT *
  FROM NFCe_EPEC_Dados.EPEC.LogEPEC e (NOLOCK)
  JOIN NFCe_EPEC_Dados.EPEC.RegistroLogEPEC r (NOLOCK)
  on r.fkLogEPEC = e.pKey
  JOIN NFCe_EPEC_Dados.EPEC.TipoLogEPEC te (NOLOCK)
  on te.id = e.idTipoLogEPEC
  JOIN NFCe_EPEC_Dados.EPEC.TipoRegistroLogEPEC tr (NOLOCK)
  on tr.id = r.idTipoRegistroLogEPEC
  where timestampReg > '2019-01-01' and timestampReg < '2019-10-01' and idTipoLogEPEC <> 2 and idTipoLogEPEC <> 6 and idTipoLogEPEC <> 9 and idTipoLogEPEC < 9000 and idTipoRegistroLogEPEC < 1000 and valor not like 'Desativa��o%'  and valor not like 'Ligado em %' and valor not like 'Desligado em %'
  and valor <> 'Ativa��o Autom�tica por motivo "Detectado NFC-e offline"'
and valor <> 'Ativa��o Autom�tica por motivo "Falha verificando NFC-e online"'
and valor <> 'Ativa��o Autom�tica por motivo "Liga��o preventiva devido a falha de verifica��o em agendamento em execu��o"'
and valor <> 'Ativa��o Autom�tica por motivo "Liga��o preventiva devido a falha em banco de dados NFC-e"' 
    order by e.timestampReg 


  SELECT valor, count(1)
  FROM NFCe_EPEC_Dados.EPEC.LogEPEC e (NOLOCK)
  JOIN NFCe_EPEC_Dados.EPEC.RegistroLogEPEC r (NOLOCK)
  on r.fkLogEPEC = e.pKey
  JOIN NFCe_EPEC_Dados.EPEC.TipoLogEPEC te (NOLOCK)
  on te.id = e.idTipoLogEPEC
  JOIN NFCe_EPEC_Dados.EPEC.TipoRegistroLogEPEC tr (NOLOCK)
  on tr.id = r.idTipoRegistroLogEPEC
  where --tr.descricao  MensagemDeErro and 
  timestampReg > '2019-01-01' and valor like 'Ativa��o Autom�tica%'
  group by valor



  select * from NFCe_EPEC_Constraint.EPEC.ConfigSistema_LOG (NOLOCK)
  where dtAlteracaoReg between '2019-05-21' and '2019-05-22'
  order by dtAlteracaoReg desc

  select * from NFCe_EPEC_Constraint.EPEC.Dados_EPEC with (nolock)
  where timestampReg > DATEADD(DAY,-3,GETDATE())
  order by timestampReg desc

select top 1000 *
from NFCe_EPEC_Constraint.EPEC.ConfigSistema



DECLARE @StartDate SMALLDATETIME = '2019-08-16 00:00';
DECLARE @EndDate SMALLDATETIME   = '2019-08-20 00:00';
WITH cte AS
(
SELECT @startdate DateValue
UNION ALL
SELECT DATEADD (MINUTE, 1, DateValue)
FROM cte 
WHERE  DATEADD (MINUTE, 1, DateValue) < @enddate
)
SELECT c.DateValue as minuto, COUNT(p.parametro) AS protocolos
FROM cte c
LEFT JOIN NFCe_EPEC_Constraint.EPEC.ConfigSistema_LOG p (NOLOCK)
ON c.DateValue = cast(p.dtAlteracaoReg AS SMALLDATETIME)
AND p.parametro = 'ONLINE'
and p.valor = 'OFF'
GROUP BY c.DateValue
ORDER BY c.DateValue ASC
OPTION (MAXRECURSION 0, MAXDOP 4)
