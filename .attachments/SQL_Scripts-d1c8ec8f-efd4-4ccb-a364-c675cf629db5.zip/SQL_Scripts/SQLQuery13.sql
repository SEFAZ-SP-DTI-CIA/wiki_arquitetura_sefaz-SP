USE [NFCe_EPEC_Dados]
GO

/****** Object:  StoredProcedure [EPEC].[usp_EPECInsert]    Script Date: 08/04/2020 16:07:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [EPEC].[usp_EPECInsert]
    -- Dados Eventos
     @nroProtocolo       BIGINT            OUTPUT
    ,@timestampOffsetReg DATETIMEOFFSET(7) OUTPUT
    ,@idEvento   VARCHAR(52)
    ,@verAplic   VARCHAR(20)
    ,@tpAmb      TINYINT
    ,@versao     VARCHAR(5)
    ,@cOrgao     TINYINT
    ,@idReceptor TINYINT
    ,@cStat      INT
    ,@chNFCe     VARCHAR(44)
    ,@tpEvento   VARCHAR(6)
    ,@nSeqEvento TINYINT
    ,@evento     VARBINARY(MAX) = NULL
    ,@dhEvento   DATETIMEOFFSET(7)

    -- dados do EPEC
    ,@valorTotal        DECIMAL (15, 2)
    ,@valorICMS         DECIMAL (15, 2)
    ,@dhEmi             DATETIMEOFFSET(7)
    ,@ieEmit            CHAR(14)
    ,@idDest            VARCHAR (20)  = NULL
    ,@tipoDestinatario  TINYINT       = NULL
    ,@ufDest            CHAR (2)      = NULL
    ,@pKeyLote          BIGINT

    -- Dados de auditoria da transmiss�o de NFe
    ,@ipOrigem            VARCHAR(15)
    ,@certificado         VARBINARY(MAX)
    ,@thumbprint          CHAR(40)
    ,@dataExpCertificado  DATETIME
    ,@tempoProcessamento  BIGINT
    ,@justificativa       NVARCHAR(255)

    -- Ano retornado
    ,@ano CHAR(2) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        SET @timestampOffsetReg = SYSDATETIMEOFFSET();

        DECLARE @timestampReg DATETIME = @timestampOffsetReg;
        SET @ano = RIGHT(CONVERT(varchar(4),year(@timestampReg)), 2);
        SET @nroProtocolo = 0;

        BEGIN TRAN                
            IF (@cStat = 136)--EPEC Autorizado
            BEGIN
                EXEC [EPEC].[usp_GetAutonumber] @nroProtocolo OUTPUT, @timestampReg;

                INSERT INTO [EPEC].[Protocolo]
                    (idReceptor
                    ,ufProtocolo
                    ,anoProtocolo
                    ,nroProtocolo
                    ,tpAmb
                    ,verAplic
                    ,timestampOffsetReg
                    ,timestampReg
                    ,versao)
                VALUES 
                    (@idReceptor
                    ,35 -- UF SP
                    ,RIGHT(CONVERT(varchar(4),year(@timestampReg)), 2)
                    ,@nroProtocolo
                    ,@tpAmb
                    ,@verAplic
                    ,@timestampOffsetReg
                    ,@timestampReg
                    ,@versao);

                DECLARE @pKey BIGINT = SCOPE_IDENTITY();
                
                INSERT INTO [NFCe_EPEC_Constraint].[EPEC].[EPEC_Constraint]
                    (pKey
                    ,cnpjEmit
                    ,numero
                    ,serie
                    ,idReceptor
                    ,ano
                    ,cStat
                    ,timestampReg)
                VALUES
                    (@pKey
                    ,SUBSTRING(@chNFCe,7,14)
                    ,SUBSTRING(@chNFCe,26,9)
                    ,SUBSTRING(@chNFCe,23,3)
                    ,@idReceptor
                    ,SUBSTRING(@chNFCe,3,2)
                    ,@cStat
                    ,@timestampReg);

                INSERT INTO [NFCe_EPEC_Constraint].[EPEC].[Dados_EPEC]
                        ([pKey]
                        ,[chNFCe]
                        ,[valorTotal]
                        ,[valorICMS]
                        ,[dhEmi]
                        ,[ieEmit]
                        ,[idDest]
                        ,[tipoDestinatario]
                        ,[ufDest]
                        ,[timestampReg])
                    VALUES
                        (@pKey
                        ,@chNFCe
                        ,@valorTotal
                        ,@valorICMS
                        ,@dhEmi
                        ,@ieEmit
                        ,@idDest
                        ,@tipoDestinatario
                        ,@ufDest
                        ,@timestampReg);

                INSERT INTO [NFCe_EPEC_XML].[EPEC].[EventoXml]
                            (pKey, evento, timestampReg)
                    VALUES (@pKey, @evento, @timestampReg);
                                
                EXEC [EPEC].[usp_DadosTransmissaoInsert] @pKey, @ipOrigem, @certificado, @thumbprint,
                                                            @dataExpCertificado, @timestampReg, @tempoProcessamento;
        
                insert into [EPEC].[ConciliacaoPendente]
                    (pKey)
                    values
                    (@pKey);
            END
            ELSE
            BEGIN
                INSERT INTO [EPEC].[ProtocoloRejeitado]
                       ([pKeyLote]
                       ,[cnpj]
                       ,[cStat]
                       ,[justificativa]
                       ,[chNFCe]
                       ,[timestampOffsetReg]
                       ,[timestampReg])
                 VALUES
                       (@pKeyLote
                       ,SUBSTRING(@chNFCe, 7, 14)
                       ,@cStat
                       ,@justificativa
                       ,@chNFCe
                       ,@timestampOffsetReg
                       ,@timestampReg)

                DECLARE @pKeyRejeitado BIGINT = SCOPE_IDENTITY();

                INSERT INTO [NFCe_EPEC_XML].[EPEC].[ProtocoloRejeitadoXml]
                       ([pKey]
                       ,[evento]
                       ,[timestampReg]
                       ,[mes])
                 VALUES
                       (@pKeyRejeitado
                       ,@evento
                       ,@timestampReg
                       ,DATEPART(MONTH,@timestampReg))
            END
        COMMIT        
    END TRY
    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
        BEGIN
            ROLLBACK
        END;
        DECLARE @lMsgErro varchar(1024)
        SET @lMsgErro = 'A seguinte excecao ocorreu durante a execucao:'
                        + ' Error=['      + ISNULL(cast(ERROR_NUMBER() as varchar(50)), '')
                        + ']; Severity=[' + ISNULL(cast(ERROR_SEVERITY() as varchar(50)), '')
                        + ']; State=['    + ISNULL(cast(ERROR_STATE() as varchar(50)), '')
                        + ']; Proc=['     + ISNULL(ERROR_PROCEDURE(), '')
                        + ']; Line=['     + ISNULL(cast(ERROR_LINE() as varchar(50)), '')
                        + ']; Message=['  + ISNULL(ERROR_MESSAGE(), '') + ']';
        THROW 80005, @lMsgErro, 1; -- error_number, message, state
        RETURN;
    END CATCH
END
GO


