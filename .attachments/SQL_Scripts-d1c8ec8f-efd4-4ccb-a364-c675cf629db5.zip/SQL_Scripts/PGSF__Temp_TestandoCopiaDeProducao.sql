select max(ID_SEQ_AIIM) from TB_DADOS_AIIM;
select max(AIIM_ID_SEQ_AIIM) from AUTOR_AIIM;

select eq.*
from equipe_membro eqm
join fiscal fi
using (num_fiscal)
join equipe eq
on eq.id_equipe = eqm.id_equipe
where fi.nom_fiscal like 'FABR�CIO TORRES%'
--JUL/2016
--DRT-05 Equipe 31


--tentativa de homologar gerou erro:
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_LEO", line 556
select max(id_relato_situacao)
from tb_relato_situacao
--660318

--2a tentativa: 
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_MARCELO", line 1053
select max(id_rma)
from TB_RMA
--113280

--3a tentativa:
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_MARCELO", line 481
select max(ID_RATEIO_FISCAL)
from TB_CALCULO_RATEIO_FISCAL
--126458

--4a tentativa:
--ORA-06512: em "PGSF_TEMP.PKG_CALCULO_PRODUTIVIDADE", line 1487
select max(ID_CALCULO_CONCLUSAO)
from TB_CALCULO_CONCLUSAO
--997772

--5a tentativa:
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_TAKA", line 2186
select max(ID_CALCULO_BASE_CALCULO)
from TB_CALCULO_BASE_CALCULO
--1067504

--6a tentantiva:
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_MARCELO", line 604
select max(ID_RATEIO_EQUIPE)
from TB_CALCULO_RATEIO_EQUIPE
--12674

--7a tentativa:
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_TAKA", line 2370
select max(ID_DISTR_PONTOS_CONCLUSAO)
from TB_DISTR_PONTOS_CONCLUSAO
--1491541

--8a tentativa:
--ORA-06512: em "PGSF_TEMP.PKG_RELATO_MARCELO", line 1606
select max(ID_AIIM_PAGAMENTO)
from TB_AIIM_PAGAMENTO
--97793

--9a tentativa:
--ORA-00001: restri��o exclusiva (PGSF_TEMP.PK_RA) violada
select max(ID_RA)
from TB_RA
--118947