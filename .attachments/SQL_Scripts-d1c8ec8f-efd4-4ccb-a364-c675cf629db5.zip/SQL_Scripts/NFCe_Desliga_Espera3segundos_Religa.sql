-- DESLIGA NFC-e
UPDATE [NFCe_Out_Constraint].[NFCeOut].[ConfigSistema]
SET valor = 'OFF'
WHERE parametro = 'ONLINE'

-- Aguarda 3 segundos para o caso de ter notas no meio do processamento
WAITFOR DELAY '00:00:03'

-- Aqui faz os procedimentos para mudar sinonimo da base XML e inserir um novo registro na PeriodoPkeys
--...
---

-- RELIGA NFC-e
UPDATE [NFCe_Out_Constraint].[NFCeOut].[ConfigSistema]
SET valor = 'ON'
WHERE parametro = 'ONLINE'
