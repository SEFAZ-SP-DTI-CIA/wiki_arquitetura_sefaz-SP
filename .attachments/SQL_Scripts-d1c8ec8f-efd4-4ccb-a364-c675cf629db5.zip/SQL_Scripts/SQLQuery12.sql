
USE [NFCe_EPEC_XML];
GO

PRINT N'Starting rebuilding table [EPEC].[ProtocoloRejeitadoXml]...';
GO

BEGIN TRANSACTION;

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

SET XACT_ABORT ON;

CREATE TABLE [EPEC].[tmp_ms_xx_ProtocoloRejeitadoXml] (
    [pKey]         BIGINT          NOT NULL,
    [evento]       VARBINARY (MAX) NOT NULL,
    [timestampReg] DATETIME        DEFAULT (GETDATE()) NOT NULL,
    [mes]          SMALLINT        DEFAULT (DATEPART(MONTH, GETDATE())) NOT NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_ProtocoloRejeitadoXml1] PRIMARY KEY CLUSTERED ([pKey] ASC, [timestampReg] ASC, [mes] ASC)
) ON [PS_Part_03_Mes] ([mes]);

IF EXISTS (SELECT TOP 1 1 
           FROM   [EPEC].[ProtocoloRejeitadoXml])
    BEGIN
        INSERT INTO [EPEC].[tmp_ms_xx_ProtocoloRejeitadoXml] ([pKey], [evento], [timestampReg], [mes])
        SELECT   [pKey],
				 [protocoloXml],
                 [timestampReg],
                 [mes]
        FROM     [EPEC].[ProtocoloRejeitadoXml]
        ORDER BY [pKey] ASC, [timestampReg] ASC, [mes] ASC;
    END

DROP TABLE [EPEC].[ProtocoloRejeitadoXml];

EXECUTE sp_rename N'[EPEC].[tmp_ms_xx_ProtocoloRejeitadoXml]', N'ProtocoloRejeitadoXml';

EXECUTE sp_rename N'[EPEC].[tmp_ms_xx_constraint_PK_ProtocoloRejeitadoXml1]', N'PK_ProtocoloRejeitadoXml', N'OBJECT';

COMMIT TRANSACTION;

SET TRANSACTION ISOLATION LEVEL READ COMMITTED;


GO
PRINT N'Refreshing [EPEC].[usp_LimpezaProtocoloRejeitadosXML_JOB]...';


GO
EXECUTE sp_refreshsqlmodule N'[EPEC].[usp_LimpezaProtocoloRejeitadosXML_JOB]';


GO
PRINT N'Update complete.';


GO
