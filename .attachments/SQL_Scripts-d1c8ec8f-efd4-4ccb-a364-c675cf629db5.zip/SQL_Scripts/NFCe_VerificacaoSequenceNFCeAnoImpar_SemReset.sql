USE NFCe_Out
GO

SELECT start_value, current_value, increment, * 
FROM sys.sequences  
WHERE name = 'ProtocoloAnoImpar'


