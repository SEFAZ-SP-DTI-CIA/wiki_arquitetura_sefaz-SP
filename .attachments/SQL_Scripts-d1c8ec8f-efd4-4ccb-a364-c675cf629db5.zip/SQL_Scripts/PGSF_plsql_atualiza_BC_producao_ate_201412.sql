
DECLARE
    TYPE cur_typ IS REF CURSOR;
    c cur_typ;
    c2 cur_typ;
    query_str VARCHAR2(1000);
BEGIN

    OPEN c FOR
      SELECT 
      'insert into pgsf.tb_relato_situacao (id_relato_situacao, nr_ano, nr_mes, id_equipe, nr_fiscal, qt_dias_relatados, id_situacao_relato, dt_alteracao, id_usuario, nr_fiscal_resp, in_ativo, id_equipe_deat, ds_observacao, in_bc) values   (pgsf.sq_relato_situacao.nextval,' ||
      nr_ano || ', ' ||
      nr_mes || ', ' ||
      DECODE(id_equipe, null, 'null', id_equipe) || ', ' ||
      nr_fiscal || ', ' ||
      qt_dias_relatados || ', ' ||
      80 || ', ' ||
      'sysdate' || ', ''' ||
      'RH' || ''', ' ||
      nr_fiscal_resp || ', ' ||
      1 || ', ' ||
      DECODE(id_equipe_deat, null, 'null', id_equipe_deat) || ', ' ||
      '''BC enviado manualmente pelos nucleos de RH ao DRH''' || ', ' || 
      in_bc || ')'
      from
             pgsf.tb_relato_situacao sit
      where
           sit.in_ativo = 1 AND
           sit.id_situacao_relato = 70 AND
           sit.nr_ano < 2015;
         
    LOOP
        FETCH c INTO query_str;
        EXIT WHEN c%NOTFOUND;
        EXECUTE IMMEDIATE query_str;
    END LOOP;     
    COMMIT;
    
    OPEN c2 FOR
      select 
        'insert into pgsf.tb_relato_situacao (id_relato_situacao, nr_ano, nr_mes, id_equipe, nr_fiscal, qt_dias_relatados, id_situacao_relato, dt_alteracao, id_usuario, nr_fiscal_resp, in_ativo, id_equipe_deat, ds_observacao, in_bc) values   (pgsf.sq_relato_situacao.nextval,' ||
            nr_ano || ', ' ||
            nr_mes || ', ' ||
            DECODE(sit.id_equipe, null, 'null', sit.id_equipe) || ', ' ||
            nr_fiscal || ', ' ||
            qt_dias_relatados || ', ' ||
            90 || ', ' ||
            'sysdate' || ', ''' ||
            'RH' || ''', ' ||
            nr_fiscal_resp || ', ' ||
            1 || ', ' ||
            DECODE(id_equipe_deat, null, 'null', id_equipe_deat) || ', ' ||
            '''BCs Averbados pelo processo manual do RH (BC em papel)''' || ', ' || 
            in_bc || ')'
        from
               pgsf.tb_relato_situacao sit
        where
             sit.in_ativo = 1 AND
             sit.id_situacao_relato = 80 AND
             sit.nr_ano < 2015;
         
    LOOP
        FETCH c2 INTO query_str;
        EXIT WHEN c2%NOTFOUND;
        EXECUTE IMMEDIATE query_str;
    END LOOP;     
    COMMIT;
    
    
END;
  