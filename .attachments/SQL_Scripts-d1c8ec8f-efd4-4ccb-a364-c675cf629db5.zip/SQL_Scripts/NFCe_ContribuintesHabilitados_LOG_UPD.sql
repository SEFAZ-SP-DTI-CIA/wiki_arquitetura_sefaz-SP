﻿ALTER TABLE [NFCeOut].[ContribuintesHabilitados_LOG] 
DROP COLUMN [indObrig],[dVigObrig],[suspensa],[ativo]

GO

ALTER TABLE [NFCeOut].[ContribuintesHabilitados_LOG]
ADD [tipoCredContribuinte]		TINYINT		  NOT NULL DEFAULT 2
	,[tipoEmissaoContribuinte]	TINYINT		  NOT NULL DEFAULT 1
	,[credVoluntarioHabilitado]	BIT			  NULL
	,[dataCredenciamento]		DATETIME	  NULL


DECLARE @DefaultTipoCredContribuinte AS VARCHAR(500)
DECLARE @DefaultTipoEmissaoContribuinte AS VARCHAR(500)

SET @DefaultTipoCredContribuinte = (SELECT object_name(cdefault) AS 'DefaultName'
									FROM syscolumns
									WHERE [id] = object_id('[NFCeOut].[ContribuintesHabilitados_LOG]')
									AND [name] = 'tipoCredContribuinte')
								
SET @DefaultTipoEmissaoContribuinte = (SELECT object_name(cdefault) AS 'DefaultName' 
								FROM syscolumns
								WHERE [id] = object_id('[NFCeOut].[ContribuintesHabilitados_LOG]')
								AND [name] = 'tipoEmissaoContribuinte')


EXEC ('ALTER TABLE [NFCeOut].[ContribuintesHabilitados_LOG]
		DROP CONSTRAINT ' + @DefaultTipoCredContribuinte + '
						,' + @DefaultTipoEmissaoContribuinte)
