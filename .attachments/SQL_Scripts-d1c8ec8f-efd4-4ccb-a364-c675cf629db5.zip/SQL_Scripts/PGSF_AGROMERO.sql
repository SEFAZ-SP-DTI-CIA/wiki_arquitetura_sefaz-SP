select *
from pgsf.fiscal
where nom_fiscal like '%ROMERO%'--246200
select *
from pgsf.equipe_membro
where num_fiscal = 246200
select * from pgsf.equipe where id_equipe = 1257 --equipe 61
select * from pgsf.drt where id_drt = 16 -- DRTC-I
select * from pgsf.tb_relato_situacao where nr_fiscal = 246200
