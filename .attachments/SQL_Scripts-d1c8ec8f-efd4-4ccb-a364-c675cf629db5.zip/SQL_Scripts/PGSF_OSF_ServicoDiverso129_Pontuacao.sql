
select *
from PGSF.ORDEM_SERVICO_FISCAL
where NUM_SP_S_PAPEL is not null


select fi.nom_fiscal, eq.nom_equipe, eq.id_drt, osf.dtc_conclusao, osf.num_osf, osf.id_osf
from pgsf.ordem_servico_fiscal osf
join pgsf.tb_pontuacao_tipo_osf tosf
on (tosf.id_tipo_osf = osf.tipo_osf)
join pgsf.tb_pontuacao po
using(id_pontuacao)
join pgsf.osf_executante osfe
on osfe.id_osf = osf.ID_OSF
join pgsf.equipe_membro eqm
using(num_fiscal)
join pgsf.fiscal fi
using(num_fiscal)
join pgsf.equipe eq
on eq.id_equipe = eqm.id_equipe
where po.CD_PONTUACAO = '4.3'
and osf.tipo_osf = 5
and osf.num_ua is null
and osf.dtc_conclusao is not null
and eqm.dtc_fim_membro is null
order by osf.dtc_emissao desc



select fi.nom_fiscal, eq.nom_equipe, eq.id_drt, osf.dtc_conclusao, osf.num_osf, osf.id_osf
from ordem_servico_fiscal osf
join tb_pontuacao_tipo_osf tosf
on (tosf.id_tipo_osf = osf.tipo_osf)
join tb_pontuacao po
using(id_pontuacao)
join osf_executante osfe
on osfe.id_osf = osf.ID_OSF
join equipe_membro eqm
using(num_fiscal)
join fiscal fi
using(num_fiscal)
join equipe eq
on eq.id_equipe = eqm.id_equipe
where po.CD_PONTUACAO = '4.3'
and osf.tipo_osf = 5
and osf.num_ua is null
and osf.dtc_conclusao is not null
and eqm.dtc_fim_membro is null
order by osf.dtc_emissao desc

select *
from forma_acionamento 

select *
from ordem_servico_fiscal osf
join forma_acionamento ac
using(id_forma_aciona)
left join osf_servico_diverso osd
using(id_osf)
where id_osf = 1061944



--########################################################
--criando fake:
update ordem_servico_fiscal
set NUM_SP_S_PAPEL = 'SFP-EXP-2019/26043'
where id_osf = 1061944

update ordem_servico_fiscal
set NUM_SP_S_PAPEL = null
where id_osf = 1061944

update ordem_servico_fiscal
set id_forma_aciona = 1 --era 3
where id_osf = 1061944


delete from osf_servico_diverso 
where id_osf = 1061944
--1061944	129	"AIIM 4.115.257-8 Emitida a pedido da DRT e autorizada pelo Supervisor DEAT Setoriais."		jagrebola	01/01/12	31/12/18
--########################################################

select *
from tb_pontuacao_tipo_osf
join tb_pontuacao
using(id_pontuacao)
where --id_tipo_osf = 5 and
CD_PONTUACAO = '4.3'

select *
from tb_pontuacao
where cd_pontuacao = 'SP - s/ pont'
where id_pontuacao in (128, 386)

select *
from TB_PONTUACAO_RELACIONAMENTO pr
join tb_pontuacao po
using(ID_PONTUACAO)
where po.CD_PONTUACAO = '4.3'


select *
from ordem_servico_fiscal osf
join osf_executante osfe
on osfe.id_osf = osf.ID_OSF
and osf.num_osf in ('01100152179','03001237177')
join osf_servico_diverso osfd
on osfd.id_osf = osf.id_osf
join tb_pontuacao_servico_diverso psd
on psd.ID_SERVICO_DIVERSO = osfd.id_servico_diverso



select dr.nom_drt, eq.nom_equipe, osf.NUM_OSF, osf.DTC_CONCLUSAO, fi.NOM_FISCAL, osf.id_osf
from ordem_servico_fiscal osf
join osf_servico_diverso osfd
on osfd.id_osf = osf.id_osf
and osfd.id_servico_diverso = 129
and osf.tipo_osf = 5--in (5,8)
and osf.dtc_conclusao is not null
join tb_pontuacao_servico_diverso psd
on psd.ID_SERVICO_DIVERSO = osfd.id_servico_diverso
join osf_executante osfe
on osfe.id_osf = osf.ID_OSF
and (osfe.DTC_FIM is null or osfe.DTC_FIM > osf.DTC_CONCLUSAO)
join fiscal fi
on fi.NUM_FISCAL = osfe.NUM_FISCAL
join equipe_membro eqm
on eqm.NUM_FISCAL = osfe.NUM_FISCAL
and eqm.DTC_FIM_MEMBRO is null
join equipe eq
on eq.id_equipe = eqm.ID_EQUIPE
join drt dr
on dr.id_drt = eq.ID_DRT
order by osf.dtc_conclusao desc

select *
from osf_servico_diverso
where id_servico_diverso = 129

select *
from tb_pontuacao_servico_diverso psd
join tb_pontuacao p
on p.id_pontuacao = psd.id_pontuacao
and p.cd_pontuacao = '4.3'