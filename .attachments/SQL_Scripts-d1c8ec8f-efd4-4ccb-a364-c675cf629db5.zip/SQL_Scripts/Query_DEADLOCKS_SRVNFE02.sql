SELECT *
  FROM [ADM_BDADOS].[dbo].[SQLDeadlockEvents]
  WHERE dbo.SQLDeadlockEvents.AlertTime BETWEEN '2018-05-10 13:40:00' AND '2018-05-10 15:40:00'
  AND dbo.SQLDeadlockEvents.DatabaseName = 'DB_NFeIntegra'