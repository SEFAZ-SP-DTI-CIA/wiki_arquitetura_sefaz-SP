select *
from tb_pontuacao
where id_pontuacao = 614 --1.6 dt_fim_vigencia = 31/12/9999 dt_inicio_vigencia = 01/01/1970

select *
from tb_pontuacao
where id_pontuacao = 40 --5.4 dt_fim_vigencia = 31/12/9999 dt_inicio_vigencia = 01/01/1970

update tb_pontuacao
set dt_inicio_vigencia = to_date('31/12/9999', 'DD/MM/YYYY')
,dt_fim_vigencia = to_date('31/12/9999', 'DD/MM/YYYY')
--set dt_fim_vigencia = to_date('31/12/9999', 'DD/MM/YYYY')
where id_pontuacao = 614

UPDATE TB_PONTOS
SET dt_inicio_vigencia = to_date('31/12/9999', 'DD/MM/YYYY'),
    dt_fim_vigencia = to_date('31/12/9999', 'DD/MM/YYYY')
WHERE id_pontuacao = 614;


select *
from tb_pontos
--where id_pontuacao = 363
where id_pontuacao = 40

--lembrar de voltar a tb_pontos tamb�m

select *
from tb_pontos
where id_pontuacao = 363
where id_pontuacao = 40

update tb_pontos
set dt_inicio_vigencia = to_date('01/01/1970', 'DD/MM/YYYY')
,dt_fim_vigencia = to_date('31/12/9999', 'DD/MM/YYYY')
where id_pontuacao = 363

update tb_pontos
set dt_inicio_vigencia = to_date('01/01/1970', 'DD/MM/YYYY')
,dt_fim_vigencia = to_date('31/12/9999', 'DD/MM/YYYY')
where id_pontuacao = 40