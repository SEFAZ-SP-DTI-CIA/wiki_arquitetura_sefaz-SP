select *
from fiscal fi
join EQUIPE_MEMBRO em
using(NUM_FISCAL)
join equipe eq
using(id_equipe)
join DRT
using(ID_DRT)
where DTC_FIM_MEMBRO is null
and nom_fiscal in
('CARLOS ALBERTO PANIGASSI')
drt equi fiscal
18	208	93352

select *
from tb_boletim_correcao
where nr_fiscal = 93352
and nr_ano = 2014
and nr_mes = 2




    SELECT
          BC.ID_BC,
          BC.NR_BC,
          BC.NR_FISCAL,
          BC.NR_ANO,
          BC.NR_MES,
          RMA.ID_EQUIPE,
          RMA.DS_POSTO_FISCAL,
          BC.QN_PONTOS_ANTES,
          BC.QN_QUOTAS_ANTES,
          BC.QN_DIAS_FDT_ANTES,
          BC.QN_PONTOS_APOS,
          BC.QN_QUOTAS_APOS,
          BC.QN_DIAS_FDT_APOS,
          BC.IN_MOTIVO_AIIM,
          BC.IN_MOTIVO_PONTUACAO,
          BC.DS_FUNCAO_RESPONSAVEL_HOMOL,
          BC_AIIM.DS_NR_AIIM_FORMATADO,
          BC_AIIM.DS_NR_OSF_FORMATADO
        FROM
          TB_BOLETIM_CORRECAO BC 
          LEFT JOIN TB_RMA RMA
            ON (BC.NR_FISCAL = RMA.NR_FISCAL 
            AND BC.NR_MES = RMA.NR_MES 
            AND BC.NR_ANO = RMA.NR_ANO)
          LEFT JOIN TB_BC_AIIM BC_AIIM ON BC.ID_BC = BC_AIIM.ID_BC
        WHERE
          BC.NR_FISCAL = 93352 AND
          BC.NR_ANO = 2014 AND
          BC.NR_MES = 2 AND
          (BC.NR_BC = -1 OR -1 = -1);
          
          
          select *
          from TB_BOLETIM_CORRECAO 
          WHERE
          NR_FISCAL = 93352 AND
          NR_ANO = 2014 AND
          NR_MES = 2 ;

          select *
          from TB_RMA
          WHERE
          NR_FISCAL = 93352 AND
          NR_ANO = 2014 AND
          NR_MES = 2 
          --RMA acima n�o existia e foir criado "fake" abaixo

          select *
          from TB_RMA
          WHERE id_rma > 52761 and id_rma < 52861 --procurando quais RMAs foram apagados, para recriar


          insert into TB_RMA (ID_RMA,NR_FISCAL,NR_ANO,NR_MES,QN_TOTAL_QUOTAS,QN_TOTAL_PONTOS,ID_RELATO_SITUACAO_HOMOL,ID_EQUIPE,DS_POSTO_FISCAL,DS_FUNCAO_RESPONSAVEL_HOMOL) 
          values ('52830','93352','2014','2','0','2980','225189','214','POSTO FISCAL DA CAPITAL - PFC - 10 - BUTANTA','Assistente de Inspetor');

          
          
          
          
          
          
          
          select *
          from tb_relato_situacao rs
          join tb_dom_situacao_relato sr
          using(id_situacao_relato)
          where
          NR_FISCAL = 93352 AND
          NR_ANO = 2014 AND
          NR_MES = 2 
          order by dt_alteracao