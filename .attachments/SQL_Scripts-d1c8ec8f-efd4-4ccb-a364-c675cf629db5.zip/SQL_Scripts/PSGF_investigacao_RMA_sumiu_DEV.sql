--## DEV #######################################################################
SELECT 
  BC.ID_BC,
  BC.NR_BC,
  BC.NR_FISCAL,
  
  BC.NR_MES,
  BC.NR_ANO,
  F.NOM_FISCAL,
  F.NUM_RG,
  F.NUM_VINCULO,
  'FDT' FUNCAO,
  
  EQUIPE.ID_DRT,
  EQUIPE.ID_UA_DRT,
  EQUIPE.COD_NF,
  RMA.DS_POSTO_FISCAL,
  RMA.ID_EQUIPE,
  EQUIPE.COD_EQUIPE,
  
  BC.QN_PONTOS_ANTES,
  BC.QN_QUOTAS_ANTES,
  BC.QN_DIAS_FDT_ANTES,
  BC.QN_PONTOS_APOS,
  BC.QN_QUOTAS_APOS,
  BC.QN_DIAS_FDT_APOS,
  BC.IN_MOTIVO_AIIM,
  BC_AIIM.DS_NR_AIIM_FORMATADO NR_AIIM,
  BC_AIIM.DS_NR_OSF_FORMATADO NR_OSF,
  0 IN_ERRO_DIGITACAO,
  0 IN_EQUIVOCO,
  BC.IN_MOTIVO_PONTUACAO,
  
  RS.DS_OBSERVACAO,
	
  FR.NOM_FISCAL NOM_RESPONSAVEL,
  BC.DS_FUNCAO_RESPONSAVEL_HOMOL FUNCAO_RESPONSAVEL,
  RS.DT_ALTERACAO DT_HOMOLOGACAO
	
FROM
  TB_BOLETIM_CORRECAO BC JOIN TB_RMA RMA ON (BC.NR_FISCAL = RMA.NR_FISCAL AND BC.NR_MES = RMA.NR_MES AND BC.NR_ANO = RMA.NR_ANO) LEFT JOIN          
  TB_BC_AIIM BC_AIIM ON BC.ID_BC = BC_AIIM.ID_BC JOIN 
  TB_RELATO_SITUACAO RS ON (RMA.NR_FISCAL = RS.NR_FISCAL AND RMA.NR_MES = RS.NR_MES AND RMA.NR_ANO = RS.NR_ANO AND 
	  (RS.ID_EQUIPE = RMA.ID_EQUIPE OR RS.ID_EQUIPE_DEAT = RMA.ID_EQUIPE)) JOIN
  (SELECT * FROM TB_RELATO_SITUACAO WHERE IN_HOMOLOG_RMA = 1) RSRMA ON (RSRMA.NR_FISCAL = RMA.NR_FISCAL AND RSRMA.NR_MES = RMA.NR_MES AND RSRMA.NR_ANO = RMA.NR_ANO) JOIN
  FISCAL F ON RMA.NR_FISCAL = F.NUM_FISCAL LEFT JOIN
  FISCAL FR ON RSRMA.NR_FISCAL_RESP = FR.NUM_FISCAL JOIN         
	
  
	(SELECT			
		D.ID_DRT,
		D.ID_UA_ERGON ID_UA_DRT,
		UR.CD_UNIDADE_RESPONSAVEL || ' - ' || DS_UNIDADE_RESPONSAVEL COD_NF,
		ED.COD_EQUIPE_DEAT COD_EQUIPE,
		ED.ID_EQUIPE_DEAT  ID_EQUIPE
	  FROM EQUIPE_DEAT ED
		JOIN UNIDADE_RESPONSAVEL UR ON ED.ID_UNIDADE_RESPONSAVEL = UR.ID_UNIDADE_RESPONSAVEL
		LEFT JOIN (UNIDADE_RESPONSAVEL_ORIGEM URO
			JOIN (SELECT * FROM ORIGEM WHERE (ID_TIPO_ORIGEM = 1 OR ID_TIPO_ORIGEM = 2)) O ON URO.ID_ORIGEM = O.ID_ORIGEM
			JOIN ORIGEM_DRT OD ON O.ID_ORIGEM = OD.ID_ORIGEM
			JOIN DRT D ON D.ID_DRT = OD.ID_DRT            
		) ON UR.ID_UNIDADE_RESPONSAVEL = URO.ID_UNIDADE_RESPONSAVEL
	UNION
	  SELECT
		DRT.ID_DRT,
		DRT.ID_UA_ERGON ID_UA_DRT,
		NF.COD_NF,
		EQ.COD_EQUIPE,
		EQ.ID_EQUIPE
	  FROM EQUIPE EQ
		JOIN NF ON NF.ID_NF = EQ.ID_NF 
		JOIN DRT ON DRT.ID_DRT = NF.ID_DRT) EQUIPE ON EQUIPE.ID_EQUIPE = RMA.ID_EQUIPE          
  
  
WHERE RS.ID_SITUACAO_RELATO = 70
  AND RS.IN_ATIVO = 1
  AND RS.NR_ANO >= 2015
  AND RS.ID_RELATO_SITUACAO = BC.ID_RELATO_SITUACAO_HOMOL
  AND (RS.NR_FISCAL = 57451)
  AND (RS.NR_MES = 1)
  AND (RS.NR_ANO = 2017);

 
select nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MM')
from tb_relato_situacao
JOIN  tb_dom_situacao_relato sr
USING (id_situacao_relato)
where 
nr_fiscal in (57130,86130,55946,87730,56689,57918,86840,85586,58467,58479,87340) and 
--nr_fiscal = 90065 and 
nr_ano = 2017 and nr_mes = 1
order by dt_alteracao

select *
from TB_BOLETIM_CORRECAO
where 
(nr_fiscal = 90065  and nr_ano = 2016 and nr_mes =  9) OR
(nr_fiscal = 87303  and nr_ano = 2017 and nr_mes =  4) OR
(nr_fiscal = 57207  and nr_ano = 2017 and nr_mes =  9) OR
(nr_fiscal = 16874  and nr_ano = 2017 and nr_mes =  9)
--ID_RELATO_SITUACAO_HOMOL = 1337090

select *
FROM TB_RMA
where nr_ano = 2017 and nr_mes = 1
and nr_fiscal in (84788,57130,86130,55946,87730,56689,57918,86840,85586,58467,58479,87340)
126469
126472
126475
126470
126473
126478
126479
126476
126471
126477
126480
126474

select drt.NOM_DRT, eq.NOM_EQUIPE, fi.nom_fiscal, fi.email, num_fiscal
from fiscal fi
join EQUIPE_MEMBRO em
using(NUM_FISCAL)
join equipe eq
using(id_equipe)
join DRT
using(ID_DRT)
where DTC_FIM_MEMBRO is null
and nom_fiscal in
('CLAYTON DE LIMA MONTIP�',
'EDIO CERATI JUNIOR',
'FL�VIO DE SOUZA QUINT�O',
'IDESIO ALVES',
'JO�O ALBERTO CORR�A',
'JOS� PINTO PINHEIRO NETO',
'JOS� ROBERTO FACIOLI',
'M�RCIO MOTTA ROSMANINHO',
'MARCOS ELIDIO FERNANDES FERRAZZO',
'PAULO SCUDELLER DA SILVA',
'PEDRO LUIS QUAGLIATO GALR�O',
'VALMIRO PIETROBOM DE MORAES')
and num_fiscal in 
(90065,
87303,
57207, 
16874,
94599,
25000,
85367,
31000,
172252,
15274)

--------------------------------------------------------------------------------
select drt.NOM_DRT, eq.NOM_EQUIPE, fi.nom_fiscal, fi.email, num_fiscal, em.dtc_inicio_membro, em.dtc_fim_membro
from fiscal fi
join EQUIPE_MEMBRO em
using(NUM_FISCAL)
join equipe eq
using(id_equipe)
join DRT
using(ID_DRT)
where (DTC_FIM_MEMBRO is null 
OR DTC_FIM_MEMBRO between to_date('01/03/2019','DD/MM/YYYY') and to_date('31/03/2019','DD/MM/YYYY') 
OR DTC_INICIO_MEMBRO between to_date('01/03/2019','DD/MM/YYYY') and to_date('31/03/2019','DD/MM/YYYY'))
and nom_fiscal in
('CARLOS ALBERTO CELANI','ERLEY BRIGNOLI DE MEDEIROS','FELIPE VIANA DE PAULA','FUMIO IWAMOTO','HERIVELTO AZAEL ARCHANGELO','HEVERTON JOSE MORENO NUCCI','JOS� EDUARDO DA COSTA ISSA','JOS� EDUARDO DE CARVALHO CAMPOS',
'JOS� GON�ALVES DA SILVA','MARIA CONCEI��O APARECIDA SOARES ENOMOTO LINDAU','MARIA DOMITILA LUVIZOTTO LOLLI','MARIA TEREZA DAHER DE ALBUQUERQUE','MILTON AUGUSTO PAOLIELLO PEREIRA',
'OSVALDO RODRIGUES ORIQUI','RICARDO CASTRO DOS SANTOS','OTAVIANO SANT''ANNA NETO')

select *
FROM TB_RMA
where nr_ano = 2019 and nr_mes = 3
and nr_fiscal in
(86451,32090,55995,56677,56938,56951,57451,85719,85940,86736,87753,93601,93870,93960,171260,192731,86736)
--averbado:
--126490	32090	2019	3	0	0	1337248	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126491	55995	2019	3	0	0	1337249	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126489	56677	2019	3	0	0	1337247	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126484	56938	2019	3	0	0	1337242	101		DEAT/AFIAC
--126486	56951	2019	3	0	0	1337244	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126485	57451	2019	3	0	0	1337243	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126488	85719	2019	3	0	0	1337246	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126492	85940	2019	3	0	0	1337250	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126481	86451	2019	3	0	0	1337239	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126495	86736	2019	3	0	0	1337253	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126482	87753	2019	3	0	0	1337240	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126487	93601	2019	3	0	0	1337245	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126493	93870	2019	3	0	0	1337251	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126496	93960	2019	3	0	0	1337254	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126494	171260	2019	3	0	0	1337252	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC
--126483	192731	2019	3	0	0	1337241	101	POSTO FISCAL 10 - CAMPINAS	DEAT/AFIAC


select nom_fiscal, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MM')
from tb_relato_situacao rs
JOIN  tb_dom_situacao_relato sr
USING (id_situacao_relato)
JOIN fiscal fi
on fi.num_fiscal = rs.nr_fiscal
where 
nr_fiscal in (86451,32090,55995,56677,56938,56951,57451,85719,85940,86736,87753,93601,93870,93960,171260,192731, 86736) and 
nr_ano = 2019 and nr_mes = 3
order by nr_fiscal, dt_alteracao


--------------------------------------------------------------------------------

select id_equipe, count(1)
from equipe_membro
where dtc_fim_membro is null
group by id_equipe
order by count(1)


select drt.NOM_DRT, ID_EQUIPE, eq.NOM_EQUIPE, fi.nom_fiscal, fi.email, num_fiscal, em.dtc_inicio_membro, em.dtc_fim_membro
from fiscal fi
join EQUIPE_MEMBRO em
using(NUM_FISCAL)
join equipe eq
using(id_equipe)
join DRT
using(ID_DRT)
where (DTC_FIM_MEMBRO is null 
OR DTC_FIM_MEMBRO between to_date('01/11/2018','DD/MM/YYYY') and to_date('30/11/2018','DD/MM/YYYY') 
OR DTC_INICIO_MEMBRO between to_date('01/11/2018','DD/MM/YYYY') and to_date('30/11/2018','DD/MM/YYYY'))
and id_equipe in (9,1209)

(15043,66944,73195,181824,251437,321026)
DRT-08 - S�O JOS� DO RIO PRETO	9	33	CLOVIS PAES DE AZEVEDO NETO	cpnazevedo@fazenda.sp.gov.br	15043	28/02/19	01/03/19
DRT-08 - S�O JOS� DO RIO PRETO	9	33	JO�O FRANCISCO DE FREITAS	jfdfreitas@fazenda.sp.gov.br	66944	01/12/13	
DRT-08 - S�O JOS� DO RIO PRETO	9	33	JORGE BECHARA ABIB	jbabib@fazenda.sp.gov.br	73195	01/10/13	
DRT-08 - S�O JOS� DO RIO PRETO	9	33	MARCELO CHERUBINI DE LIMA	mclima@fazenda.sp.gov.br	181824	01/09/14	
DRT-08 - S�O JOS� DO RIO PRETO	9	33	MARCIO EDUARDO SANCHES	mesanches@fazenda.sp.gov.br	251437	01/10/13	
DRT-08 - S�O JOS� DO RIO PRETO	9	33	IAN CARDOSO SETTA	icsetta@fazenda.sp.gov.br	321026	14/10/13	


delete from equipe_membro
where id_equipe = 1209 and num_fiscal = 15043
and dtc_inicio_membro = '02/03/19'

select * from equipe_membro
where id_equipe in (9, 1209) and num_fiscal = 15043

update equipe_membro
set dtc_fim_membro = to_date('31/08/2018','DD/MM/YYYY')
where num_fiscal = 15043 and id_equipe = 1209

insert into equipe_membro(num_fiscal, dtc_inicio_membro, id_equipe, dtc_fim_membro, dtc_atualizacao, usuario)
values(15043, to_date('01/09/2018','DD/MM/YYYY'), 9, to_date('02/09/2018','DD/MM/YYYY'), to_date('29/02/2020','DD/MM/YYYY'), 'fsnagamine')

insert into equipe_membro(num_fiscal, dtc_inicio_membro, id_equipe, dtc_atualizacao, usuario)
values(15043, to_date('03/09/2018','DD/MM/YYYY'), 1209, to_date('29/02/2020','DD/MM/YYYY'), 'fsnagamine')



select *
FROM TB_RMA
where nr_ano = 2018 and nr_mes = 9
and
(
nr_fiscal in (15043,246545,251152,170802)
or
nr_fiscal in (15043,66944,73195,181824,251437,321026)
)

Antes de devolver relato do DANIEL MASSAO MAKITA (Mar):
ID_RMA, NR_FISCAL, NR_ANO, NR_MES, QN_TOTAL_QUOTAS, QN_TOTAL_PONTOS, ID_RELATO_SITUACAO_HOMOL, ID_EQUIPE, DS_POSTO_FISCAL, DS_FUNCAO_RESPONSAVEL_HOMOL
126509	15043	2019	3	0	0	1337391	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126512	170802	2019	3	0	0	1337394	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126510	246545	2019	3	0	0	1337392	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126511	251152	2019	3	0	0	1337393	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC

Antes de devolver relato do CLOVIS PAES DE AZEVEDO NETO (Fev):
126513	15043	2019	2	0	0	1337428	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126516	170802	2019	2	0	0	1337431	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126514	246545	2019	2	0	0	1337429	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126515	251152	2019	2	0	0	1337430	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
Ap�s Segunda Homologa��o (e antes de gerar BC na outra equipe do CLOVIS):
126517	15043	2019	2	0	0	1337446	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126520	170802	2019	2	0	0	1337449	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126518	246545	2019	2	0	0	1337447	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC
126519	251152	2019	2	0	0	1337448	1209	POSTO FISCAL 10 - OSASCO	DEAT/AFIAC


select *
from equipe_membro
where num_fiscal in (15043,170802,246545,251152)


select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MM:SS')
from tb_relato_situacao rs
JOIN  tb_dom_situacao_relato sr
USING (id_situacao_relato)
JOIN fiscal fi
on fi.num_fiscal = rs.nr_fiscal
where 
(
nr_fiscal in (15043,246545,251152,170802)
or
nr_fiscal in (15043,66944,73195,181824,251437,321026)
) and 
nr_ano = 2018 and nr_mes = 9
order by dt_alteracao



select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MM:SS')
from tb_relato_situacao rs
JOIN  tb_dom_situacao_relato sr
USING (id_situacao_relato)
JOIN fiscal fi
on fi.num_fiscal = rs.nr_fiscal
where 
(
nr_fiscal in (15043,246545,251152,170802)
or
nr_fiscal in (15043,66944,73195,181824,251437,321026)
) and 
nr_ano = 2018 and nr_mes = 9
order by dt_alteracao
