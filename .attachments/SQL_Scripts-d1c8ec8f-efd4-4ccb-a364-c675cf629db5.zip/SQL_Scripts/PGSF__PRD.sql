select * 
from PGSF.FISCAL FIS
join PGSF.EQUIPE_MEMBRO EQM
using(num_fiscal)
join PGSF.EQUIPE EQP
using (ID_EQUIPE)
join PGSF.DRT D
USING(ID_DRT)
where nom_fiscal = 'ILSO FERNANDES DOS SANTOS'
and D.NOM_DRT = 'DRT-05 - CAMPINAS'
--and EQM.DTC_FIM_MEMBRO is null

select *
from PGSF.INSPETORES ins
join PGSF.FISCAL fis
using (num_fiscal)
where dtc_fim is null
and id_Drt = 4

select *
from pgsf.equipe_membro
where num_fiscal = 71599
order by dtc_inicio_membro

select *
from pgsf.tb_relato_situacao
order by dt_alteracao desc


select *
from pgsf.tb_relato_situacao
where nr_fiscal = 71599
order by dt_alteracao desc


select id_equipe, nr_fiscal, id_relato_situacao, id_situacao_relato, ds_situacao_relato, to_char(dt_alteracao, 'DD/MM/YYYY HH24:MI:SS'), nr_ano, nr_mes
from pgsf.tb_relato_situacao rs
JOIN  pgsf.tb_dom_situacao_relato sr
USING (id_situacao_relato)
where nr_fiscal = 71599
order by dt_alteracao desc



select * from pgsf.outras_atividades

select *
from pgsf.TEMP_PROD_MENSAL

SELECT 
DRT.NOM_DRT,
NF.COD_NF,
EQ.NOM_EQUIPE,
FI.NOM_FISCAL,
SUBSTR(FI.EMAIL,0,INSTR(FI.EMAIL,'@')-1),
RMA.NR_ANO,
RMA.NR_MES,
RMA.QN_TOTAL_PONTOS,
RMA.QN_TOTAL_QUOTAS,
RMA.QN_TOTAL_PONTOS+RMA.QN_TOTAL_QUOTAS
FROM
PGSF.TB_RMA RMA
JOIN PGSF.FISCAL FI
ON FI.NUM_FISCAL = RMA.NR_FISCAL
JOIN PGSF.EQUIPE EQ
ON EQ.ID_EQUIPE = RMA.ID_EQUIPE
JOIN PGSF.NF
ON NF.ID_NF = EQ.ID_NF
JOIN PGSF.DRT
ON DRT.ID_DRT = EQ.ID_DRT
WHERE
RMA.NR_ANO = 2017 AND
RMA.NR_MES >= 1;




select *
from pgsf.fiscal 
join pgsf.equipe_membro
using (num_fiscal)
join pgsf.equipe
using (id_equipe)
where nom_fiscal like 'FELIPE VIANA %'
and dtc_fim_membro is null

select *--to_char(dt_inicio_vigencia, 'dd-mon-yyyy hh.mi.ss')
from pgsf.tb_pontuacao
where id_pontuacao = 614

select *--to_char(dt_inicio_vigencia, 'dd-mon-yyyy hh.mi.ss')
from pgsf.tb_pontos
where id_pontuacao = 614

select to_char(dt_fim_vigencia, 'dd-mon-yyyy hh.mi.ss')
from pgsf.tb_pontuacao
where id_pontuacao = 614;
select to_char(dt_inicio_vigencia, 'DD/MM/YYYY HH12:MI:SS')
from pgsf.tb_pontos
where id_pontuacao = 614
