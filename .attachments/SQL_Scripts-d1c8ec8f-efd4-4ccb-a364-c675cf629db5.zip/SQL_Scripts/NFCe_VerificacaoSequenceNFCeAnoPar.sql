USE NFCe_Out
GO

SELECT start_value, current_value, increment, * 
FROM sys.sequences  
WHERE name = 'ProtocoloAnoPar'

-- Se o "current_value" for diferente de '1', rodar os comandos a seguir
-- ALTER SEQUENCE [NFCeOut].[ProtocoloAnoPar]
-- RESTART WITH 1;

