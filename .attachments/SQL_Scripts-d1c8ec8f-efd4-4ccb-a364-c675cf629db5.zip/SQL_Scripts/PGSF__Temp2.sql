select *
from tb_pontuacao 
where  ds_pontuacao like '%Reuni�o%'


where id_pontuacao = 76
select *
from outras_atividades
where num_fiscal = 86785
and dtc_execucao > '01/06/2016'
and dtc_execucao < '30/06/2016'

update tb_pontuacao
set dt_fim_vigencia = to_date('31/12/9999','DD/MM/YYYY')
where dt_fim_vigencia = to_date('30/05/2016','DD/MM/YYYY')

select *
from tb_pontos
where dt_fim_vigencia < '31/12/9999';


select *
from ordem_servico_fiscal
where num_osf = 08001480161
or num_osf = 	08000721168;

update ordem_servico_fiscal
set id_situacao_osf = 8, dtc_limite_fim = null, dtc_termino_acao = null, dtc_conclusao = null
where num_osf = 08001480161


select *
from tb_relato_situacao
where nr_ano = 2016
and nr_mes = 6
and nr_fiscal = 86785
and dt_alteracao > '01/01/2017'

delete tb_relato_situacao
where nr_ano = 2016
and nr_mes = 6
and nr_fiscal = 86785
and dt_alteracao > '01/01/2017'


select *
from pgsf.osf_fiscal_dia
where num_fiscal = 86785
and dtc_execucao > '01/06/2016'
and dtc_execucao < '01/07/2016'

select situacao.des_situacao_osf, osf.*
from ordem_servico_fiscal osf
join situacao_osf situacao
on osf.id_situacao_osf = situacao.id_situacao_osf
where num_osf = 08001480161

select *
from historico_situacao_osf
where id_osf = 852862

update historico_situacao_osf
set dtc_historico = to_date('28/06/2016','DD/MM/YYYY')
where id_osf = 852862
and id_situacao_osf = 1

insert into historico_situacao_osf(dtc_historico, id_osf, id_situacao_osf)
values(to_date('29/06/2016','DD/MM/YYYY'), 852862, 8)

select *
from fiscal 
where nom_fiscal like '%NARDELLI'

