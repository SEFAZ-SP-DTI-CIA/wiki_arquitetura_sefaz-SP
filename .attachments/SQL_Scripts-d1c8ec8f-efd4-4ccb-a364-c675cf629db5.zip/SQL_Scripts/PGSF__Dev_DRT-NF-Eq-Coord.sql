select dtc_inicio_membro,extract(month from dtc_inicio_membro) from equipe_coord
where dtc_inicio_membro is nul

select unique dr.cod_drt, nu.cod_nf, eq.nom_equipe, fi.nom_fiscal
from drt dr
join equipe eq
using (id_drt)
join nf nu
using (id_nf)
join equipe_coord ec
on eq.id_equipe = ec.id_equipe
join fiscal fi
using (num_fiscal)
where 
ec.dtc_fim_coord is null
order by dr.cod_drt, nu.cod_nf, eq.nom_equipe, fi.nom_fiscal