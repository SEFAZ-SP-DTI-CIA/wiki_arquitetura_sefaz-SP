select top 10 *
from ETL_NFE.DWCCC.ResultadoProcessamento (NOLOCK)
order by dataProcessamento desc


select top 10 *
from ETL_NFE.DWCCC.LogErros
--.ResultadoProcessamento (NOLOCK)
