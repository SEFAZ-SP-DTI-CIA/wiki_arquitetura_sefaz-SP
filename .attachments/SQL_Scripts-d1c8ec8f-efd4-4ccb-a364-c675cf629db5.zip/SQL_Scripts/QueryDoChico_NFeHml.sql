USE DB_NFeIntegra
GO

SELECT TOP 5 '' as '[NFeEventos].[LOG_XML]', LOXM_DT_Timestamp, *, CONVERT(XML, LOXM_TX_XML_Request) as Req, CONVERT(XML, LOXM_TX_XML_Response) as Resp 
  FROM [NFeEventos].[LOG_XML] (NOLOCK)
 ORDER BY LOXM_CD_XML DESC

--2018-03-09 09:48:18.5850000 -03:00
SELECT TOP 5 '' as '[NFeEventos].[EVENTO_REJEITADO]', EVT_DT_TIMESTAMP_REG, *
FROM [NFeEventos].[EVENTO_REJEITADO] (NOLOCK)
ORDER BY EVT_CD_EVENTO DESC

SELECT TOP 5 '' as '[NFeEventos].[EVENTO_REJEITADO_XML]',  *, CONVERT(XML, EVX_MM_EVENTO) as ev
FROM [NFeEventos].[EVENTO_REJEITADO_XML] (NOLOCK)
ORDER BY EVT_CD_EVENTO DESC


-- Eventos de Alerta de Irregularidade Fiscal recebidos
SELECT TOP 10 * 
  FROM [NFe_Out_UFs].[NFeEventos].[Evento] (nolock)
 WHERE tpEvento in (400101, 400104, 400105, 400120, 400121, 500100, 500101, 500104, 500105, 400100, 400200, 400201)

-- Eventos MDF-e - BT2017.002
SELECT tpEvento, count(tpEvento)
  FROM [NFe_Out_UFs].[NFeEventos].[Evento] (nolock)
 --WHERE tpEvento in (610510, 610511, 610514, 610515, 610550, 610552, 610554, 610610, 610611, 610614, 610615, 610500, 610501 ) -- TODOS
 WHERE tpEvento in (610510, 610511, 610514, 610515, 610552, 610554, 610614, 610615) -- S� os novos
 GROUP BY tpEvento

SELECT tpEvento, count(tpEvento)
  FROM [NFe_Out].[NFeEventos].[Evento_Constraint] (nolock)
 WHERE tpEvento in (400101, 400104, 400105, 400120, 400121, 500100, 500101, 500104, 500105, 400100, 400200, 400201)
 GROUP BY tpEvento

 SELECT TOP 10 '' AS '[dbo].[REGISTROS_LOTE_ERRO]', *
  FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] (nolock)
 --WHERE pkey > 37489452 -- pkey de produ��o a partir de 2017
   --WHERE pkey > 38206428 -- pkey de produ��o a partir de 2018
 WHERE pkey > 328934980 -- pkey de homologa��o a partir de 2017
 --WHERE pkey > 329143723 -- pkey de homologa��o a partir de 2018
   AND erro like 'Tipo de Evento: %'
 ORDER BY pKey DESC

 SELECT '' AS '[dbo].[REGISTROS_LOTE_ERRO]', erro, count(erro)
  FROM [NFe_Out_UFs].[dbo].[REGISTROS_LOTE_ERRO] (nolock)
 WHERE pkey > 37489452 -- pkey de produ��o a partir de 2017
   --WHERE pkey > 38206428 -- pkey de produ��o a partir de 2018
 --WHERE pkey > 328934980 -- pkey de homologa��o a partir de 2017
 --WHERE pkey > 329143723 -- pkey de homologa��o a partir de 2018
   AND erro like 'Tipo de Evento: %'
 GROUP BY erro