select *
from inspetores