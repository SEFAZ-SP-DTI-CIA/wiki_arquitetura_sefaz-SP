insert into autor_aiim(aiim_id_seq_aiim, cd_id_funcional) values (279597, 131064);
insert into autor_aiim(aiim_id_seq_aiim, cd_id_funcional) values (279597, 131386);
insert into autor_aiim(aiim_id_seq_aiim, cd_id_funcional) values (279597, 170290);
insert into autor_aiim(aiim_id_seq_aiim, cd_id_funcional) values (279597, 165580);
