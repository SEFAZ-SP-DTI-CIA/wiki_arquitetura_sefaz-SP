use ccc
go

 select *
 from [CCC].[Contribuinte]
 where indCreditoPresum is not null and ind63TM is not null and indContribTeste is not null and indContribTeste = 1

declare @qtdRegistros int = 1
declare @GUID_EXECUTION UNIQUEIDENTIFIER = null
declare @horarioLimite  DATETIME = '2020-04-15 11:30:04'

 select * from [CCC].[Contribuinte] where indCreditoPresum is not null and ind63TM is not null
 select top (@qtdRegistros) * from  [DW].[Queue] WHERE timestampReg <= @horarioLimite ORDER BY NSUCCCMovto asc

  select * from  [DW].[Queue] WHERE NSUCCCMovto = 86410501


 delete from [DW].[Queue] where NSUCCCMovto < 86410501
--insert into [DW].[Queue](NSUCCC,NSUCCCMovto,timestampReg)values(13369108, 86410501, '2020-04-15 11:30:03.700')



    DECLARE @DW_Queue TABLE  
    (  
        [pKey]         BIGINT,
        [NSUCCC]       BIGINT,
        [NSUCCCMovto]  BIGINT,
        [timestampReg] DATETIME
    )
  
    IF (@GUID_EXECUTION IS NULL) 
    BEGIN
        SET @GUID_EXECUTION = NEWID()
    END


        ;WITH fila AS(
            SELECT TOP (@qtdRegistros) pkey, NSUCCC, NSUCCCMovto, timestampReg
              FROM [DW].[Queue] WITH (READPAST, ROWLOCK, UPDLOCK)
             WHERE timestampReg <= @horarioLimite
             ORDER BY NSUCCCMovto desc--asc
        )
        DELETE FROM fila
        OUTPUT  
            DELETED.pKey, 
            DELETED.NSUCCC, 
            DELETED.NSUCCCMovto,
            DELETED.timestampReg   
        INTO @DW_Queue (pKey,
                        NSUCCC,
                        NSUCCCMovto,
                        timestampReg)

        /* vers�o antiga sem ORDER BY 
        DELETE TOP (@qtdRegistros) 
        FROM  
            [DW].[Queue] WITH (READPAST) 
        OUTPUT  
            DELETED.pKey, 
            DELETED.NSUCCC, 
            DELETED.NSUCCCMovto,
            DELETED.timestampReg   
        INTO @DW_Queue (pKey,
                        NSUCCC,
                        NSUCCCMovto,
                        timestampReg)
        */ 

        SELECT 
            [pKey]
           ,[NSUCCC]
           ,[NSUCCCMovto]
           ,[timestampReg]
           ,0
           ,GETDATE()
           ,@GUID_EXECUTION
        FROM @DW_Queue

        SELECT
               ISNULL(c.[pkey]            ,ch.[pkey]            ) AS [pkey]        
              ,ISNULL(c.[cUF]             ,ch.[cUF]             ) AS [cUF]         
              ,ISNULL(c.[tpInscMF]        ,ch.[tpInscMF]        ) AS [tpInscMF]    
              ,ISNULL(c.[InscMF]          ,ch.[InscMF]          ) AS [InscMF]      
              ,ISNULL(c.[IE]              ,ch.[IE]              ) AS [IE]          
              ,ISNULL(c.[indContribTeste] ,ch.[indContribTeste] ) AS [indContribTeste]          
              ,ISNULL(c.[cSitIE]          ,ch.[cSitIE]          ) AS [cSitIE]      
              ,ISNULL(c.[dSit]            ,ch.[dSit]            ) AS [dSit]        
              ,ISNULL(c.[cSitCNPJ]        ,ch.[cSitCNPJ]        ) AS [cSitCNPJ]    
              ,ISNULL(c.[cSitCADESP]      ,ch.[cSitCADESP]      ) AS [cSitCADESP]  
              ,ISNULL(c.[tpIE]            ,ch.[tpIE]            ) AS [tpIE] 
              ,ISNULL(c.[xNome]           ,ch.[xNome]           ) AS [xNome]       
              ,ISNULL(c.[xFant]           ,ch.[xFant]           ) AS [xFant]       
              ,ISNULL(c.[UFEnder]         ,ch.[UFEnder]         ) AS [UFEnder]     
              ,ISNULL(c.[regTrib]         ,ch.[regTrib]         ) AS [regTrib]
              ,ISNULL(c.[CNAE]            ,ch.[CNAE]            ) AS [CNAE]        
              ,ISNULL(c.[dIniAtiv]        ,ch.[dIniAtiv]        ) AS [dIniAtiv]    
              ,ISNULL(c.[dBaixa]          ,ch.[dBaixa]          ) AS [dBaixa]      
              ,ISNULL(c.[indCreditoPresum],ch.[indCreditoPresum]) AS [indCreditoPresum]      
              ,ISNULL(c.[IEUnica]         ,ch.[IEUnica]         ) AS [IEUnica]     
              ,ISNULL(c.[IEAtual]         ,ch.[IEAtual]         ) AS [IEAtual]     
              ,ISNULL(c.[indAtuaEndereco] ,ch.[indAtuaEndereco] ) AS [indAtuaEndereco]
              ,ISNULL(c.[xLgr]            ,ch.[xLgr]            ) AS [xLgr]        
              ,ISNULL(c.[nro]             ,ch.[nro]             ) AS [nro]         
              ,ISNULL(c.[xCpl]            ,ch.[xCpl]            ) AS [xCpl]        
              ,ISNULL(c.[xBairro]         ,ch.[xBairro]         ) AS [xBairro]     
              ,ISNULL(c.[cMun]            ,ch.[cMun]            ) AS [cMun]        
              --,[end_xMun]                                     
              ,ISNULL(c.[CEP]             ,ch.[CEP]             ) AS [CEP]         
              ,ISNULL(c.[indAtua]         ,ch.[indAtua]         ) AS [indAtua]     
              ,ISNULL(c.[dInc]            ,ch.[dInc]            ) AS [dInc]        
              ,ISNULL(c.[NSUCCC]          ,ch.[NSUCCC]          ) AS [NSUCCC]      
              ,ISNULL(c.[dAtu]            ,ch.[dAtu]            ) AS [dAtu]        
              ,ISNULL(c.[NSUCCCMovto]     ,ch.[NSUCCCMovto]     ) AS [NSUCCCMovto] 
              ,ISNULL(c.[dhResp]          ,ch.[dhResp]          ) AS [dhResp]      
              ,@GUID_EXECUTION AS GUID                          
              ,ISNULL(c.[indIEDestOpc]    ,ch.[indIEDestOpc]    ) AS [indIEDestOpc]
              ,ISNULL(c.[porte]           ,ch.[porte]           ) AS [porte]       
              ,ISNULL(c.[ind55]           ,ch.[ind55]           ) AS [ind55]       
              ,ISNULL(c.[inf55dCreden]    ,ch.[inf55dCreden]    ) AS [inf55dCreden]
              ,ISNULL(c.[ind65]           ,ch.[ind65]           ) AS [ind65]       
              ,ISNULL(c.[inf65dCreden]    ,ch.[inf65dCreden]    ) AS [inf65dCreden]
              ,ISNULL(c.[inf57dCreden]    ,ch.[inf57dCreden]    ) AS [inf57dCreden]
              ,ISNULL(c.[ind5701]         ,ch.[ind5701]         ) AS [ind5701]     
              ,ISNULL(c.[ind5702]         ,ch.[ind5702]         ) AS [ind5702]     
              ,ISNULL(c.[ind5703]         ,ch.[ind5703]         ) AS [ind5703]     
              ,ISNULL(c.[ind5704]         ,ch.[ind5704]         ) AS [ind5704]     
              ,ISNULL(c.[ind5705]         ,ch.[ind5705]         ) AS [ind5705]     
              ,ISNULL(c.[ind5706]         ,ch.[ind5706]         ) AS [ind5706]     
              ,ISNULL(c.[ind67]           ,ch.[ind67]           ) AS [ind67]       
              ,ISNULL(c.[inf67dCreden]    ,ch.[inf67dCreden]    ) AS [inf67dCreden]
              ,ISNULL(c.[ind63]           ,ch.[ind63]           ) AS [ind63]       
              ,ISNULL(c.[ind63TM]         ,ch.[ind63TM]         ) AS [ind63TM]
              ,ISNULL(c.[inf63dCreden]    ,ch.[inf63dCreden]    ) AS [inf63dCreden]
              ,ISNULL(c.[ind66]           ,ch.[ind66]           ) AS [ind66]       
              ,ISNULL(c.[inf66dCreden]    ,ch.[inf66dCreden]    ) AS [inf66dCreden]   
          FROM @DW_Queue AS q 
          LEFT JOIN [CCC].[Contribuinte] AS c WITH (ROWLOCK) -- n�o pode usar nolock pelo risco de aparecer duas vezes o mesmo contribuinte na leitura suja
            ON  q.[NSUCCC]      = c.[NSUCCC] 
            AND q.[NSUCCCMovto] = c.[NSUCCCMovto]
          LEFT JOIN [CCC].[ContribuinteHistorico] AS ch WITH (ROWLOCK) -- n�o pode usar nolock pelo risco de aparecer duas vezes o mesmo contribuinte na leitura suja
            ON  q.[NSUCCC]      = ch.[NSUCCC] 
            AND q.[NSUCCCMovto] = ch.[NSUCCCMovto]


