select em.DTC_INICIO_MEMBRO, em.DTC_FIM_MEMBRO, e.NOM_EQUIPE, d.NOM_DRT, n.COD_NF, f.NOM_FISCAL
select *
from EQUIPE_DEAT_MEMBRO em
join FISCAL f
on em.NUM_FISCAL = f.NUM_FISCAL
and f.NOM_FISCAL like 'GERALDO%'
join EQUIPE e
ON e.ID_EQUIPE = em.ID_EQUIPE
join NF n
on n.ID_NF=e.ID_NF
join DRT d
on d.ID_DRT = e.ID_DRT

select * from FISCAL
where nom_fiscal='EMERSON PICASSO FURQUIM'

select *
from NF
where ID_NF=280

select * 
FROM FISCAL
where NUM_FISCAL=25267

select * 
FROM INSPETORES
where num_fiscal = 25267

select * 
FROM ASSISTENTE_INSPETOR
where num_fiscal = 25267


select * 
FROM INSPETORES
where num_fiscal = 25267

select * 
FROM EQUIPE_MEMBRO e
where e.

select * 
FROM EQUIPE_MEMBRO_AUDIT e
where e.NUM_FISCAL=319561

select * 
FROM EQUIPE_DEAT_MEMBRO e
where e.NUM_FISCAL=319561

select * 
FROM EQUIPE_DEAT_MEMBRO_AUDIT e
where e.NUM_FISCAL=319561

select * 
FROM EQUIPE_DEAT_MEMBRO_AUTORIZACAO e
where e.NUM_FISCAL=319561

