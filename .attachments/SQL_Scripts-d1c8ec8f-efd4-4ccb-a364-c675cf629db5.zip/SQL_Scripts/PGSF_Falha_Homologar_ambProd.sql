select * from tb_dom_situacao_relato

select *
from TB_RELATO_SITUACAO rs
join tb_dom_situacao_relato sr
using(id_situacao_relato)
where
in_ativo = 1
and id_equipe = 1222
and nr_fiscal = 248440

and id_equipe = 1222
and nr_ano = 2018
and nr_mes = 1
order by nr_fiscal
--equipe 102 2017-2


select drt.nom_drt, equipe.nom_equipe
from equipe
join drt
using(id_drt)
where id_equipe = 1222

select *
from TB_BOLETIM_CORRECAO
where id_bc = 21153

SELECT SQ_BC.NEXTVAL AS ID_BC
    FROM DUAL;

select * from equipe_membro where num_fiscal = 248440; 
update equipe_membro 
set dtc_fim_membro = to_date('31/10/2017','DD/MM/YYYY')
where num_fiscal = 248440 and id_equipe = 1222

insert into equipe_membro (NUM_FISCAL,DTC_INICIO_MEMBRO,ID_EQUIPE,DTC_FIM_MEMBRO,DTC_ATUALIZACAO,USUARIO) 
values ('248440',to_date('01/11/17','DD/MM/RR'),'83',null,to_date('01/11/17','DD/MM/RR'),'mtsuzuki'); 

select *
from pgsf.ordem_servico_fiscal
where num_osf in
(14001134147,
14007305158,
14001511162,
14001692168,
14001759160,
14001760162,
14002307165,
14002513166,
14002514167,
14002515163,
14003162167,
14003163163,
14004004160,
14003674170,
14005691171,
14005745179)


CREATE GLOBAL TEMPORARY TABLE temp_table_pgsf
ON COMMIT PRESERVE ROWS 
AS SELECT DISTINCT DA.ID_OSF 
       FROM pgsf.TB_DADOS_AIIM DA
       WHERE DA.NR_AIIM IN
        (SELECT DISTINCT DA2.NR_AIIM
          FROM 
            pgsf.TB_DADOS_AIIM DA2
            INNER JOIN (pgsf.OSF_EXECUTANTE OE
            LEFT JOIN pgsf.EQUIPE_MEMBRO EM ON EM.NUM_FISCAL = OE.NUM_FISCAL
            LEFT JOIN pgsf.EQUIPE_DEAT_MEMBRO EDM ON EDM.NUM_FISCAL = OE.NUM_FISCAL)
            ON OE.ID_OSF = DA2.ID_OSF
          WHERE
            (EM.ID_EQUIPE = 1222 OR EDM.ID_EQUIPE_DEAT = 1222)
            AND ((EM.DTC_INICIO_MEMBRO <= to_date('2018-01-30', 'YYYY-MM-DD') AND (EM.DTC_FIM_MEMBRO >= to_date('2018-01-01', 'YYYY-MM-DD') OR EM.DTC_FIM_MEMBRO IS NULL))
            OR (EDM.DTC_INICIO <= to_date('2018-01-30', 'YYYY-MM-DD') AND (EDM.DTC_FIM >= to_date('2018-01-01', 'YYYY-MM-DD') OR EDM.DTC_FIM IS NULL)))
            AND DA2.DT_PRIM_NOTIF_ENV_DEC >= to_date('2018-01-01', 'YYYY-MM-DD')
            AND DA2.DT_PRIM_NOTIF_ENV_DEC <= to_date('2018-01-30', 'YYYY-MM-DD'));

INSERT INTO temp_table_pgsf
    (SELECT DISTINCT OSF.ID_OSF 
      FROM pgsf.ORDEM_SERVICO_FISCAL OSF
        INNER JOIN (pgsf.OSF_EXECUTANTE OE
        LEFT JOIN pgsf.EQUIPE_MEMBRO EM ON EM.NUM_FISCAL = OE.NUM_FISCAL
        LEFT JOIN pgsf.EQUIPE_DEAT_MEMBRO EDM ON EDM.NUM_FISCAL = OE.NUM_FISCAL)
        ON OE.ID_OSF = OSF.ID_OSF
      WHERE
        (EM.ID_EQUIPE = 1222 OR EDM.ID_EQUIPE_DEAT = 1222)
        AND ((EM.DTC_INICIO_MEMBRO <= to_date('2018-01-30', 'YYYY-MM-DD') AND (EM.DTC_FIM_MEMBRO >= to_date('2018-01-01', 'YYYY-MM-DD') OR EM.DTC_FIM_MEMBRO IS NULL))
          OR (EDM.DTC_INICIO <= to_date('2018-01-30', 'YYYY-MM-DD') AND (EDM.DTC_FIM >= to_date('2018-01-01', 'YYYY-MM-DD') OR EDM.DTC_FIM IS NULL)))
        AND OSF.DTC_CONCLUSAO >= to_date('2018-01-01', 'YYYY-MM-DD')
        AND OSF.DTC_CONCLUSAO <= to_date('2018-01-30', 'YYYY-MM-DD'));
        

SELECT *
 FROM pgsf.TB_DADOS_AIIM AIIM
      INNER JOIN (pgsf.AUTOR_AIIM AA INNER JOIN pgsf.FISCAL F ON TO_NUMBER(F.ID_FUNCIONAL) = AA.CD_ID_FUNCIONAL)
        ON AIIM.ID_SEQ_AIIM = AA.AIIM_ID_SEQ_AIIM        
      LEFT JOIN pgsf.TB_AUTOR_AIIM_2 TAA ON TAA.ID_TB_DADOS_AIIM = AIIM.ID_TB_DADOS_AIIM AND TAA.NUM_FISCAL = F.NUM_FISCAL
      LEFT JOIN pgsf.TB_DEDUCAO_AIIM TDA ON AIIM.NR_AIIM = TDA.NR_AIIM AND TDA.IN_ATIVO = 1      
    WHERE EXISTS
      (SELECT 'X' FROM temp_table_pgsf TMP WHERE TMP.ID_OSF = AIIM.ID_OSF);

select * from AIIMWEB.vw_dsaw_dados_afr_aiim



variable rc refcursor;
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 567904, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 789751, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 843844, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 832727, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 834734, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 847093, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 835480, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 835481, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 847089, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 847097, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 855686, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 855687, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 868365, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 951931, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 979819, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)
execute PKG_CALCULO_PRODUTIVIDADE.USP_OSF_VIEW_SEL(5, -1, -1, 979168, to_date('01-01-2018', 'DD-MM-YYYY'), to_date('31-01-2018', 'DD-MM-YYYY'),  :rc)