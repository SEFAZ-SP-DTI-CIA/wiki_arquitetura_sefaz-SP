UPDATE tb_pontuacao
SET id_tipo_pontuacao = 129
WHERE id_tipo_pontuacao = 173
AND ds_pontuacao <> 'FALTA ABONADA';