use NFCe_Out
go

DECLARE @timestamp DATETIME = '2020-04-07 14:59:56.260'
DECLARE @dataCorte DATETIME = DATEADD(MINUTE, -2, @timestamp)
DECLARE @pKeyAnterior bigint = 1002951670
DECLARE @minpKey bigint = 1002951671
DECLARE @maxpKey bigint = 1002955753

--op��o original
SELECT p.pKey, cnpjEmit, nc.cStat AS cStat, p.timestampReg
FROM [NFCeOut].[Protocolo] AS p (NOLOCK)
INNER JOIN [NFCe_Out_Constraint].[NFCeOut].[NFCe_Constraint] AS nc (NOLOCK)
ON      p.pKey         = nc.fkProtocolo
    AND p.timestampReg = nc.timestampReg
WHERE p.pKey between @minpKey and @maxpKey
    AND p.timestampReg between @dataCorte and @timestamp
	order by pKey desc

--op��o nova
SELECT pKey, timestampReg INTO #CteProtocolo
FROM [NFCeOut].[Protocolo] (NOLOCK)
WHERE pKey         between @minpKey   and @maxpKey
    AND timestampReg between @dataCorte and @timestamp
SELECT cte.pkey, nc.cnpjEmit, nc.cStat AS cStat, cte.timestampReg
FROM #CteProtocolo as cte
INNER JOIN [NFCe_Out_Constraint].[NFCeOut].[NFCe_Constraint] AS nc (NOLOCK)
ON  cte.pKey         = nc.fkProtocolo
AND cte.timestampReg = nc.timestampReg
order by pKey desc

DROP TABLE #CteProtocolo
