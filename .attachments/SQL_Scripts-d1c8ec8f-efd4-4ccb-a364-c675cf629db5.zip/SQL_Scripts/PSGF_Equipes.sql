select *
from equipe
wher id_equipe = 214


select drt.NOM_DRT, eq.NOM_EQUIPE, fi.nom_fiscal, fi.email, num_fiscal
from fiscal fi
join EQUIPE_MEMBRO em
using(NUM_FISCAL)
join equipe eq
using(id_equipe)
join DRT
using(ID_DRT)
where DTC_FIM_MEMBRO is null
and nom_fiscal in
('CLAYTON DE LIMA MONTIP�',
'EDIO CERATI JUNIOR',
'FL�VIO DE SOUZA QUINT�O',
'IDESIO ALVES',
'JO�O ALBERTO CORR�A',
'JOS� PINTO PINHEIRO NETO',
'JOS� ROBERTO FACIOLI',
'M�RCIO MOTTA ROSMANINHO',
'MARCOS ELIDIO FERNANDES FERRAZZO',
'PAULO SCUDELLER DA SILVA',
'PEDRO LUIS QUAGLIATO GALR�O',
'VALMIRO PIETROBOM DE MORAES')
and num_fiscal in 
(90065,
87303,
57207, 
16874,
94599,
25000,
85367,
31000,
172252,
15274)

