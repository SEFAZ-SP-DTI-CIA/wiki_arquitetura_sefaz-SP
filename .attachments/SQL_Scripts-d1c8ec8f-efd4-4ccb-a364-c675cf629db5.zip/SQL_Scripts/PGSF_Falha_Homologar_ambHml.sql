select * from tb_dom_situacao_relato

select *
from TB_RELATO_SITUACAO rs
join tb_dom_situacao_relato sr
using(id_situacao_relato)
where 
in_ativo = 1
and id_equipe = 1222
order by nr_ano desc, nr_mes desc
--equipe 102 2017-2


select drt.nom_drt, equipe.nom_equipe
from equipe
join drt
using(id_drt)
where id_equipe = 1222

select *
from TB_BOLETIM_CORRECAO
where id_bc = 21153

SELECT SQ_BC.NEXTVAL AS ID_BC
    FROM DUAL;