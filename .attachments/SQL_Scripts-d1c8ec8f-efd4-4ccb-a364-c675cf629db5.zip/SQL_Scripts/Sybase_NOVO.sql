--update ods.tb_dsod_nfe_controle_execucao set cod_status = 1; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 1;
--update ods.tb_dsod_nfe_controle_execucao set cod_status = 2; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 2;
--update ods.tb_dsod_nfe_controle_execucao set cod_status = 5; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 5;
--update ods.tb_dsod_nfe_controle_execucao set cod_status = 0; update ods.tb_dsod_nfeuf_controle_execucao set cod_status = 0;
--update ods.tb_dsod_nfce_controle_execucao set cod_status = 0;
commit;select * from ods.tb_dsod_ccc_controle_execucao 
commit;select * from ods.tb_dsod_mdfe_controle_execucao
commit;select * from ods.tb_dsod_nfce_controle_execucao
commit;select * from ods.tb_dsod_cte_controle_execucao
commit;select * from ods.tb_dsod_cteos_controle_execucao
commit; select * from ods.tb_dsod_nfe_controle_execucao; select * from ods.tb_dsod_nfeuf_controle_execucao

select top 1 * from ods.tb_dsod_nfe_tmp_partilha_icms_reextracao where data_extracao_arquivo > '2020-05-21'
select count(1) from ods.tb_dsod_nfe_tmp_partilha_icms_reextracao 
select count(1) from ods.tb_dsod_nfeuf_tmp_partilha_icms_reextracao --185738 26/11 16:42


select  top 10 * from [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao < '2010-01-04'

--insert into ods.tb_dsod_cteos_controle_execucao(cod_status, data_inicio_status) values(0, getdate())

insert into ods.tb_dsod_nfe_controle_execucao (cod_status)values(0);
insert into ods.tb_dsod_nfeuf_controle_execucao (cod_status)values(0);
commit;

select top 10 * from ods.tb_dsod_nfeuf_reextracao where data_extracao = '2000-01-01'
select count(1) from ods.tb_dsod_nfeuf_reextracao where data_extracao = '2000-01-01'--451043 240133
select count(1) from ods.tb_dsod_nfeuf_reextracao where data_extracao > '2020-12-01'
select top 10 * from ods.tb_dsod_nfeuf_reextracao where data_extracao is null
select top 10 * from ods.tb_dsod_nfeuf_reextracao where chave_acesso_nota_fiscal = 11190401282343000159550040000000031235209311

commit;
select count(1) from ods.tb_dsod_mdfe_tmp_protocolo
select count(1) from ods.tb_dsod_mdfe_tmp_eventos_gen
--select dateformat(data_hora_conexao,  'YYYY-MM-DD HH:MM:SS.SSSSSSSSSS')	 from ods.tb_dsod_mdfe_tmp_ide        
select * from ods.tb_dsod_mdfe_tmp_ide



UPDATE ods.tb_dsod_nfe_reextracao SET  chave_acesso_nota_fiscal = 35200702332686001204550120000765491458172488 WHERE chave_acesso_nota_fiscal =35161199171171171115550441563550341640030295
UPDATE ods.tb_dsod_nfeuf_reextracao SET  chave_acesso_nota_fiscal = 42201107941752000520550040000555681213186707 WHERE chave_acesso_nota_fiscal = 35201181611931000390550010003660481153731812
update ods.tb_dsod_nfe_reextracao set data_extracao = null
update ods.tb_dsod_nfeuf_reextracao set data_extracao = null
commit


delete from ods.tb_dsod_nfeuf_reextracao where chave_acesso_nota_fiscal <> 42201107941752000520550040000555681213186707
commit
insert into ods.tb_dsod_nfeuf_reextracao(chave_acesso_nota_fiscal)
VALUES(33200713747117000428550010000007421000091021),
VALUES(42200702089969001005550010103352271404665353),
VALUES(43200701838723005358550010033096311280175257),
VALUES(42200780143548000120550010000680711134991416),
VALUES(42200718371881000112550010090073591001032297)
commit

VALUES(35190899171171171115550011576359551029159668),
VALUES(35190899171171171115550011576359571029159662),
VALUES(35190899171171171115550011576359591029159667),
VALUES(35190899171171171115550011576359631029159660),
VALUES(35190899171171171115550011576359671029159669),
VALUES(35190899171171171115550011576359731029159666),
VALUES(35190899171171171115550011576359811029159668),
VALUES(35190899171171171115550011576359851029159667),
VALUES(35190899171171171115550011576559531984990143),
VALUES(35190899171171171115550070019205421788793045),
VALUES(35190899171171171115550070019205441788793040),
VALUES(35190899171171171115550070019205461788793044),
VALUES(35190899171171171115550070019205481788793049),
VALUES(35190899171171171115550070019205501788793047),
VALUES(35190899171171171115550070019205521788793041),
VALUES(35190899171171171115550070019305531788793042),
VALUES(35190899171171171115550070019305551788793047),
VALUES(35190899171171171115550070019305571788793041),
VALUES(35190899171171171115550070019305591788793046),
VALUES(35190899171171171115550070019305611788793044),
VALUES(35190999171171171115550010006427861506275030),
VALUES(35190911005987000153550010000026671012814758),
VALUES(35190999171171171115550010000000061506275031),
VALUES(35190999171171171115550010000000081506275036),
VALUES(35190999171171171115550010000000101506275034),
VALUES(35190999171171171115550010000000121506275039),
VALUES(35190999171171171115550070020206061788793045),
VALUES(35190999171171171115550070020206081788793040),
VALUES(35190999171171171115550070020306091788793040),
VALUES(35190999171171171115550070020306111788793049),
VALUES(35190999171171171115550070020306131788793043),
VALUES(35190999171171171115550070020306151788793048),
VALUES(35190999171171171115550070020306171788793042),
VALUES(35190999171171171115550070020306191788793047),
VALUES(35190999171171171115550070020306211788793045),
VALUES(35190999171171171115550070020306231788793040),
VALUES(35190999171171171115550070020306251788793044),
VALUES(35190999171171171115550070020306271788793049),
VALUES(35190999171171171115550070020306311788793041),
VALUES(35190999171171171115550070020406321788793042),
VALUES(35191099171171171115550071576559571788793048),
VALUES(35191099171171171115550071576659581788793049),
VALUES(35191099171171171115550071576659601788793047),
VALUES(35191099171171171115550071576659701788793043),
VALUES(35191099171171171115550071576759641788793040),
VALUES(35191099171171171115550071576759701788793047),
VALUES(35191199171171171115550071576759721788793045),
VALUES(35191199171171171115550071576759741788793040),
VALUES(35191199171171171115550071576759761788793044),
VALUES(35191299171171171115550070021812181788793040),
VALUES(35191299171171171115550070021812201788793049),
VALUES(35191299171171171115550070021812241788793048),
VALUES(35191299171171171115550070021812261788793042),
VALUES(35191299171171171115550070021812281788793047),
VALUES(35200199171171171115550070021812871788793043),
VALUES(35200199171171171115550070021812891788793048),
VALUES(35200199171171171115550070021812911788793046),
VALUES(35200199171171171115550070021812931788793040),
VALUES(35200199171171171115550070021812951788793045),
VALUES(35200199171171171115550011576960031000002997),
VALUES(35200199171171171115550011576960051000002991),
VALUES(35200399171171171115550071577060231788793040),
VALUES(35200399171171171115550071577060211788793045),
VALUES(35200399171171171115550071577060251788793044),
VALUES(35200464555626000147550000010202886421216463),
VALUES(35200742274696002561550010044449236503448445),
VALUES(35200746389383000566550010002891576939491375),
VALUES(35200720132344000161550010072813356000000010),
VALUES(35200744367027000192550030000085736573900887),
VALUES(35200720132344000161550010072716376000000017),
VALUES(35200715436940000286550230000104156141180938),
VALUES(35200715436940000286550230000104166145604349),
VALUES(35200720132344000161550010072716936000000016),
VALUES(35200720132344000161550010072716516000000016),
VALUES(35200720132344000161550010072716656000000011),
VALUES(35200720132344000161550010072717216000000012),
VALUES(35200720132344000161550010072716796000000017),
VALUES(35200720132344000161550010072717356000000018),
VALUES(35200741916347000590550010000845546364884109),
VALUES(35200715436940000286550230000104246110731621),
VALUES(35200720132344000161550010072717076000000013),
VALUES(35200720132344000161550010072813496000000015),
VALUES(35200715436940000286550230000104346136514560),
VALUES(35200715436940000286550230000104266169657830),
VALUES(35200715436940000286550230000104336117862038),
VALUES(35200720132344000161550011072812496000000017),
VALUES(35200720132344000161550012072817586000000010),
VALUES(35200734229208000107550080000001806022428261),
VALUES(35200753113791000122555130000006436066776768),
VALUES(35200753113791000122555130000006446066776765),
VALUES(35200753113791000122555130000006486066776764),
VALUES(35200753113791000122555130000006476066776767),
VALUES(35200720132344000161550012072817716000000012),
VALUES(35200720132344000161550011072812636000000016),
VALUES(35200760500246001630550010025265626126370857),
VALUES(35200761412110052384550070000009966540290991),
VALUES(35200761412110095270550070000100026322588758),
VALUES(35200761412110004495550070000100026451515859),
VALUES(35200761412110104287550070000000026515692502),
VALUES(35200700549740000181550090000783986707608343)

commit;
update ods.tb_dsod_nfeuf_reextracao set data_extracao = '01/01/2000' where chave_acesso_nota_fiscal = 42201107941752000520550040000555681213186707

select * from ods.tb_dsod_nfeuf_reextracao where data_extracao is null
select * from ods.tb_dsod_nfeuf_reextracao where data_extracao is null
select count(1) from ods.tb_dsod_nfeuf_reextracao where data_extracao is null
select count(1) from ods.tb_dsod_nfeuf_reextracao where data_extracao is null

insert into ods.tb_dsod_nfeuf_reextracao(chave_acesso_nota_fiscal)
values(43150754083035002619551260085566811798912327)


 -- data_extracao > '2020-09-24'

update ods.tb_dsod_nfeuf_reextracao set data_extracao = null where data_extracao > '2020-09-28'


commit;
select count(1) from ods.tb_dsod_nfeuf_reextracao where data_extracao is null
select count(1) from ods.tb_dsod_nfe_reextracao where data_extracao is null

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prod

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod where cod_amarracao_arquivo in (
14358248876,
14358631263,
14358934570,
14358933067,
14359088299,
14359121392,
14359499466,
14360245172,
14360519550,
14360708195,
14361252411,
14363103250,
14363719580,
14364756625,
14364798990,
14364827399,
14364923437,
14364893966,
14364972394,
14365007422,
14365179422,
14365804805,
14365801659,
14365798534,
14365803578,
14365813289
)

commit;
select cod_amarracao_arquivo, chave_acesso_nota_fiscal from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec
where chave_acesso_nota_fiscal in
(35200549054323000157550010000170941414135757,
35200549054323000157550010000170951740554241,
35200549054323000157550010000171011942956218,
35200549054323000157550010000171021515136370,
35200549054323000157550010000171031441638919,
35200549054323000157550010000171051473864927,
35200549054323000157550010000171041080161761,
35200549054323000157550010000171061999572903,
35200549054323000157550010000171071403106033,
35200549054323000157550010000171081748796341,
35200549054323000157550010000171111484051318,
35200549054323000157550010000171091504906498,
35200549054323000157550010000171121837374569,
35200549054323000157550010000171101729492233,
35200549054323000157550010000171131313542451,
35200549054323000157550010000170911393199083,
35200508621389000102550010000066461000000109,
35200508621389000102550010000066481000000103,
35200508621389000102550010000066471000000106,
35200549054323000157550010000170921971401309,
35200549054323000157550010000170931303308028,
35200549054323000157550010000170961686492333,
35200549054323000157550010000170971337294657,
35200549054323000157550010000170981393749165,
35200549054323000157550010000170991509815824,
35200549054323000157550010000171001260937610)




commit;select count(1) from ods.tb_dsod_nfce_tmp_doc_fiscal_prod


rollback;

commit;
select * from ods.tb_dsod_mdfe_tmp_eventos_gen
select * from ods.tb_dsod_mdfe_tmp_eventos_libera_prazo_canc
select * from ods.tb_dsod_mdfe_tmp_eventos_encerramento_fisco

delete from  ods.tb_dsod_mdfe_tmp_eventos_encerramento_fisco where data_extracao < '2020-07-02 17:59'

update [ods].[tb_dsod_nfe_reextracao] set data_extracao = null where chave_acesso_nota_fiscal in (35200399171171171115550071577060251788793044,11131007987185000380550000000006921000008820,22181060409075013300550010000040411746559020,22181028053619003603550010000002281747389518,33181004738455000160550010000082151292292556,33181004738455000160550010000082161469446454)

delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_reextracao;
update [ods].[tb_dsod_nfeuf_reextracao] set data_extracao = null where chave_acesso_nota_fiscal in (35200399171171171115550071577060251788793044,11131007987185000380550000000006921000008820,22181060409075013300550010000040411746559020,22181028053619003603550010000002281747389518,33181004738455000160550010000082151292292556,33181004738455000160550010000082161469446454);
commit;select count(1) from [ods].[tb_dsod_nfeuf_reextracao] where data_extracao is  null

commit;select * from [ods].[tb_dsod_nfeuf_reextracao] where data_extracao is  null

select * from [ods].[tb_dsod_nfeuf_reextracao] where chave_acesso_nota_fiscal = 35200508621389000102550010000066461000000109

delete from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec            where chave_acesso_nota_fiscal in  (35200399171171171115550071577060251788793044,11131007987185000380550000000006921000008820,22181060409075013300550010000040411746559020,22181028053619003603550010000002281747389518,33181004738455000160550010000082151292292556,33181004738455000160550010000082161469446454)
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec          where chave_acesso_nota_fiscal in  (35200399171171171115550071577060251788793044,11131007987185000380550000000006921000008820,22181060409075013300550010000040411746559020,22181028053619003603550010000002281747389518,33181004738455000160550010000082151292292556,33181004738455000160550010000082161469446454)
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_reextracao where chave_acesso_nota_fiscal in  (35200399171171171115550071577060251788793044,11131007987185000380550000000006921000008820,22181060409075013300550010000040411746559020,22181028053619003603550010000002281747389518,33181004738455000160550010000082151292292556,33181004738455000160550010000082161469446454)

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec --delete from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec 

commit;
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec where chave_acesso_nota_fiscal = 43150754083035002619551260085566811798912327  --delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec 
--4676653 11:20

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_reextracao --delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_reextracao
select * FROM [ods].[tb_dsod_nfe_reextracao] --delete FROM [ods].[tb_dsod_nfe_reextracao] where chave_acesso_nota_fiscal = 11131007987185000380550000000006921000008820
select * FROM [ods].[tb_dsod_nfeuf_reextracao]--delete FROM [ods].[tb_dsod_nfeuf_reextracao] where chave_acesso_nota_fiscal = 35200399171171171115550071577060251788793044				

select COUNT(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_reextracao

select top 1000 * from [ods].[tb_dsod_nfeuf_tmp_doc_fiscal_transp_reextracao]
where num_placa_veiculo = ''



select top 100 * from [ods].[tb_dsod_nfeuf_reextracao]-- where chave_acesso_nota_fiscal = 11200600398268000204550010000087191001454302


insert into [ods].[tb_dsod_nfeuf_reextracao](chave_acesso_nota_fiscal)
values(35200399171171171115550071577060251788793044),
values(11131007987185000380550000000006921000008820),
values(22181060409075013300550010000040411746559020),
values(22181028053619003603550010000002281747389518),
values(33181004738455000160550010000082151292292556),
values(33181004738455000160550010000082161469446454);


--delete from  [ods].[tb_dsod_nfe_reextracao]
--delete from  [ods].[tb_dsod_nfeuf_reextracao]
--where chave_acesso_nota_fiscal = 11131007987185000380550000000006921000008820


SELECT TOP 1 * FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao IS NULL 
SELECT DISTINCT TOP 10 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL 
SELECT DISTINCT TOP 10 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao IS NULL 

SELECT CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal, * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL
SELECT CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal, * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NOT NULL 

select * FROM [ods].[tb_dsod_nfe_reextracao] WHERE chave_acesso_nota_fiscal = 35190400000326000119550010000019261000019262
commit
select count(1) from ods.tb_dsod_nfe_tmp_partilha_icms_reextracao
select count(1) from ods.tb_dsod_nfeuf_tmp_partilha_icms_reextracao--240133
select * from ods.tb_dsod_nfe_tmp_partilha_icms_reextracao


SELECT top 10 * FROM [ods].[tb_dsod_nfe_reextracao] where data_incl_ods > '2020-11-10' and  data_extracao IS not NULL --35190400000326000119550010000019261000019262


update ods.tb_dsod_nfce_controle_execucao
set cod_status = 0

commit;select count(1) from ods.tb_dsod_ccc_tmp_cad_contribuinte --12314 2020-04-15 13:38
select count(1) from ods.tb_dsod_ccc_tmp_cad_contribuinte where ind_63_tm is not null
select count(1) from ods.tb_dsod_ccc_tmp_cad_contribuinte where ind_cred_presum is not null
--truncate table  tb_dsod_ccc_tmp_cad_contribuinte

--delete from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp
--delete from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp_inf_pag
--delete from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp_comp
--delete from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp_inf_prazo
--delete from ods.tb_dsod_mdfe_tmp_ide
--delete from ods.tb_dsod_mdfe_tmp_rodov_inf_pag
--delete from ods.tb_dsod_mdfe_tmp_rodov_componentes
--delete from ods.tb_dsod_mdfe_tmp_rodov_inf_prazo
--delete from ods.tb_dsod_mdfe_tmp_rodov_contratante
commit;

select * from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp
select * from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp_inf_pag
select * from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp_comp
select * from ods.tb_dsod_mdfe_tmp_eventos_pgto_oper_transp_inf_prazo

select * from ods.tb_dsod_mdfe_tmp_ide
select * from ods.tb_dsod_mdfe_tmp_rodov_inf_pag
select * from ods.tb_dsod_mdfe_tmp_rodov_componentes
select * from ods.tb_dsod_mdfe_tmp_rodov_inf_prazo
select * from ods.tb_dsod_mdfe_tmp_rodov_contratante


select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_compr_entr_cte 
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_canc_compr_entr_cte
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_compr_entr_cte 
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_canc_compr_entr_cte

commit;
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_compr_entr_cte 
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_canc_compr_entr_cte
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_compr_entr_cte 
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_canc_compr_entr_cte



commit;select * from ods.tb_dsod_nfce_tmp_doc_fiscal_prod_medic   
commit;select * from ods.tb_dsod_nfce_tmp_doc_fiscal_dest_loc_entr
commit;select * from ods.tb_dsod_nfce_tmp_doc_fiscal_emit_loc_ret 
commit;select * from ods.tb_dsod_nfce_tmp_doc_fiscal_prod         

commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_medic
commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr
commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret
commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod
commit;select * from ods.ods.tb_dsod_nfe_tmp_partilha_icms
commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_rastreab



select * from ods.tb_dsod_nfeuf_reextracao_ip_transmissor

commit;
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen_reextracao
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen_reextracao

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cancel
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cancel_reextracao
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel_reextracao


commit;
select * from ods.tb_dsod_nfe_tmp_transmissor


select count(1)
from ods.tb_dsod_mdfe_ide

select *
from ods.


select * from ods.tb_dsod_nfe_tmp_doc_fiscal

select * from ods.tb_dsod_nfe_tmp_transmissorv
select * from ods.tb_dsod_nfce_tmp_doc_fiscal_prod_rastreab		


select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod

select count(1) from ods.tb_dsod_nfce_tmp_doc_fiscal_prot_rec

select * from ods.tb_dsod_nfe_tmp_forma_pagto

commit;
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao      

commit;
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec      noholdlock
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prod   noholdlock
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal   noholdlock

select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec      noholdlock
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod   noholdlock
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal   noholdlock


select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod   noholdlock
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal   noholdlock


select * from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret  noholdlock
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr noholdlock
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_transp        noholdlock




select count(1) from ods.tb_dsod_nfe_batimento_protocolo_evt

commit;
select * from ods.tb_dsod_nfe_tmp_evt_pedido_corindus
select * from ods.tb_dsod_nfe_tmp_evt_pedido_corindus_item


SELECT CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal, * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL
SELECT CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal, * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NOT NULL 

select * FROM [ods].[tb_dsod_nfe_reextracao] WHERE chave_acesso_nota_fiscal = 35190400000326000119550010000019261000019262
select * from ods.tb_dsod_nfe_tmp_partilha_icms_reextracao
SELECT * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL
SELECT * FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao IS NULL
order by chave_acesso_nota_fiscal desc

commit;
SELECT COUNT(1) FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL --
SELECT COUNT(1) FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao > '2018-08-08'
commit;
SELECT COUNT(1) FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao IS NULL


SELECT COUNT(1) FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao > '2018-08-08'
SELECT *  FROM [ods].[tb_dsod_nfeuf_reextracao] WHERE data_extracao > '2018-08-07'

order by data_extracao desc

--delete from [ods].[tb_dsod_nfe_reextracao]
commit;

SELECT * FROM [ods].[tb_dsod_nfe_reextracao] WHERE chave_acesso_nota_fiscal = 35110107576934000115550010000000010010520676

update  [ods].[tb_dsod_nfe_reextracao] 
35110107576934000115550010000000010010520676


--chave_acesso_nota_fiscal
SELECT * FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao > '2018-04-09'


--select count(1) from ods.tb_dsod_nfe_reextracao

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prod
select count(1) from ods.tb_dsod_nfe_tmp_partilha_icms


commit;select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao_prod
commit;select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao_prod

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec noholdlock

commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec     noholdlock --9405819553
commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen      noholdlock --9405819655
commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao noholdlock --9405738590
commit;select max(cod_amarracao_arquivo) from ods.tb_dsod_nfe_tmp_doc_fiscal_cancel       noholdlock --

commit;select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec   noholdlock
commit;select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen    noholdlock
commit;select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec noholdlock
commit;select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen  noholdlock


LOAD TABLE ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen(cod_amarracao_arquivo, id_evento, ind_tipo_ambiente, num_versao_leiaute, num_versao_aplicativo, cod_est_evento, num_ano, cod_receptor, cod_status, chave_acesso_nota_fiscal, data_evento, ind_tipo_evento, num_seq_evento, num_cnpj_cpf_dest, descr_email, num_protocolo, data_registro, cod_orgao_pk, ind_tipo_dest, id_autor, ind_tp_id_autor, num_ip_transmissor, data_extracao_arquivo DATETIME('yyyy-mm-dd hh:nn:ss.sssss') NULL('00000000000000',Blanks), ind_origem, filler('\x0D\x0A')) USING CLIENT FILE 'D:/DISK19/NFeOutUFs/20180417000000-NFe_Evento_Generico.txt' DELIMITED BY '\xFF' ESCAPES OFF QUOTES OFF CHECK CONSTRAINTS ON IGNORE CONSTRAINT UNIQUE 0;

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen noholdlock
where chave_acesso_nota_fiscal = 35180372381189001001550010001630691944254837

select * from ods.ods.tb_dsod_nfe_tmp_evt_mdfe noholdlock
where cod_amarracao_arquivo = 9292227225
where cod_amarracao_arquivo = 9292227225

select * from ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit noholdlock
where cod_amarracao_arquivo = 9292227225

select chave_acesso_nota_fiscal from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen noholdlock
where ind_tipo_evento = '610510'
group by ind_tipo_evento
order by ind_tipo_evento
-- ('610500', '610501', '610510', '610511', '610514', '610515', '610550', '610552', '610554', '610610', '610611', '610614', '610615')

ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
ods.ods.tb_dsod_nfe_tmp_evt_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit
ods.tb_dsod_nfe_tmp_evt_canc_mdfe

update ods.tb_dsod_nfe_reextracao
set data_extracao = '01/01/2001'
 WHERE data_extracao is null;
commit;

SELECT DISTINCT TOP 2 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL 

select top 100 * FROM ods.tb_dsod_nfe_reextracao WHERE data_extracao is null;
select top 100 * FROM ods.tb_dsod_nfeuf_reextracao WHERE data_extracao is null;


select count(1) FROM ods.tb_dsod_nfe_reextracao 
WHERE motivo_reextracao = 'num_id_dest, descr_email_dest'

select count(1) FROM ods.tb_dsod_nfeuf_reextracao 
WHERE motivo_reextracao = 'num_id_dest, descr_email_dest'

select count(1) FROM ods.tb_dsod_nfeuf_reextracao WHERE data_extracao is null;
delete FROM ods.tb_dsod_nfe_reextracao WHERE data_extracao is null;

insert into ods.tb_dsod_nfe_reextracao (chave_acesso_nota_fiscal, ref_mes_emissao)
values
(35110900608804000178550010001501442082911075,201109),
(35121144110229000154550010000200201001680200,201211)



select data_extracao, count(1) FROM ods.tb_dsod_nfe_reextracao 
group by data_extracao

SELECT DISTINCT TOP 5000 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_reextracao WHERE data_extracao is  null;
LOAD TABLE ods.tb_dsod_nfe_tmp_evt_mdfe(cod_amarracao_arquivo, num_versao_leiaute, descr_evento, cod_orgao_autor, ind_tp_autor, num_ver_aplic, Data_extracao DATETIME('yyyy-mm-dd hh:nn:ss.sssss') NULL('00000000000000',Blanks), ind_origem, nome_arquivo, filler('\x0D\x0A')) USING CLIENT FILE 'D:/DISK/NFeOut/20180301000000-NFe_Evento_MDFe.txt' DELIMITED BY '\xFF' ESCAPES OFF QUOTES OFF CHECK CONSTRAINTS ON IGNORE CONSTRAINT UNIQUE 0;
LOAD TABLE ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen(cod_amarracao_arquivo, id_evento, ind_tipo_ambiente, num_versao_leiaute, num_versao_aplicativo, cod_est_evento, num_ano, cod_receptor, cod_status, chave_acesso_nota_fiscal, data_evento, ind_tipo_evento, num_seq_evento, num_cnpj_cpf_dest, descr_email, num_protocolo, data_registro, cod_orgao_pk, ind_tipo_dest, id_autor, ind_tp_id_autor, num_ip_transmissor, data_extracao_arquivo DATETIME('yyyy-mm-dd hh:nn:ss.sssss') NULL('00000000000000',Blanks), ind_origem, filler('\x0D\x0A')) USING CLIENT FILE 'D:/DISK/NFeOut/20180301000000-NFe_Evento_Generico.txt' DELIMITED BY '\xFF' ESCAPES OFF QUOTES OFF CHECK CONSTRAINTS ON IGNORE CONSTRAINT UNIQUE 0;

ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
ods.ods.tb_dsod_nfe_tmp_evt_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_mdfe
ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit
ods.tb_dsod_nfe_tmp_evt_canc_mdfe

commit;
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal_cancel

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal_cancel

select cod_est_evento, num_protocolo , count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
group by cod_est_evento, num_protocolo
having count(1) > 1

select *  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
where num_protocolo in (431376,445391,595789,1489659,1536442,1551955,1902430)
order by num_protocolo


select top 1 * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
where num_seq_evento > 2

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
where id_evento in ('6105001117120385389600634255002000001150102001150901', '6105001118010125799500080055001000135768100459136001', '6105001118010125799500080055001000135769100019325201', '6105001118010125799500080055001000135770100716632401', '6105001118010125799500080055001000135771100455872501', '6105001118010125799500080055001000135772100661302001', '6105001118011426305200016555001000000046104002469401', '6105001118012040056100019555001000000893120395051001', '6105001118012870622800011055001000000101150039300001', '6105001118016762037700747055001000001856100008959001', '6105001517120043604201803655000000002270100000001301', '6105001517120502562500020255020000066556100066556001', '6105001517120502562500020255020000066608100066608401', '6105001517120502562500071755020000007642100007642001', '6105001517120502562500071755020000007666100007666001', '6105001517121094065300010455001000030862100030862301', '6105001517121094065300010455001000030867100030867001', '6105001517121280538900012155001000010542100010542601', '6105001517121280538900012155001000010544100010544701', '6105001517128358377300025655001000000293100000293001', '6105001517128358377300050755001000000221100000221601', '6105002618010889353800018455001000002722120111017701', '6105005118010200340200246155010000088780100635969601', '6105005118010200340200246155010000088781100635972301', '6105005118010200340200246155012000299413100635571001', '6105005118010200340200246155012000299414100635572501', '6105005118010216598400051055002000004781155458852001', '6105005118010686600900016655001000001970100004842501', '6105005118018404610102470055101000194806172723767101', '6106103118012324395900015355001000171049100819591001', '6106103118012324395900015355001000171050100623132401', '6106103118012324395900015355001000171051100784875601', '6106103118012324395900015355001000171052100121363201', '6106103118012324395900015355001000171053100764946401', '6106103118012324395900015355001000171054100239327201', '6106103118012324395900015355001000171055100343515401', '6106103118012324395900015355001000171056100341514201', '6106103118012324395900015355001000171057100658569001', '6106103118012324395900015355001000171058100969141301', '6106103118012324395900015355001000171059100219591401', '6106103118012324395900015355001000171060100623532601', '6106103118012324395900015355001000171061100781875601', '6106103118012324395900015355001000171062100141363801', '6106103118012324395900015355001000171063100564946301')

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal_cancel



select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_reg_passagem_brid


select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao

select top(10) * from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret 
select top(10) * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_emit_loc_ret 

commit;
select *
from ods.tb_dsod_nfe_reextracao r



where data_extracao is null
join ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec p
on p.chave_acesso_nota_fiscal = r.chave_acesso_nota_fiscal

update ods.tb_dsod_nfe_reextracao
set data_extracao = GETDATE()
where chave_acesso_nota_fiscal < 35160899171171171115550011561149981195066938

insert into ods.tb_dsod_nfe_reextracao (chave_acesso_nota_fiscal, ref_mes_emissao)
values
(35170399171171171115550010000111751000111750, 201703)

commit;
select *
from ods.tb_dsod_nfe_reextracao
where data_extracao is null



select *
from ods.tb_dsod_nfe_reextracao 
WHERE data_extracao IS NULL AND chave_acesso_nota_fiscal IN (SELECT chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec)

select chave_acesso_nota_fiscal from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec

commit;
SELECT * FROM ods.tb_dsod_nfe_reextracao WHERE chave_acesso_nota_fiscal = 35110900608804000178550010001501442082911075

select *
from ods.tb_dsod_nfe_reextracao_intermediaria



--update ods.tb_dsod_nfe_reextracao set data_extracao = GETDATE() where chave_acesso_nota_fiscal < 35160899171171171115550011561149981195066938
--insert into ods.tb_dsod_nfe_reextracao(chave_acesso_nota_fiscal, ref_mes_emissao)values(35160899171171171115550011561149981195066938, 201608)

select *
from ods.tb_dsod_nfe_reextracao
WHERE data_extracao IS NOT NULL
 AND chave_acesso_nota_fiscal IN (SELECT chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec)

UPDATE ods.tb_dsod_nfe_reextracao SET data_extracao = GETDATE() WHERE data_extracao IS NULL AND chave_acesso_nota_fiscal IN (SELECT chave_acesso_nota_fiscal FROM ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec)

SELECT DISTINCT TOP 10 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal 
FROM [ods].[tb_dsod_nfe_reextracao]
WHERE data_extracao IS NULL
COMMIT;


delete from ods.tb_dsod_nfe_reextracao




commit;
select * from ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal = 35110801510736000172550000000067371100067374


commit;
select count(chave_acesso_nota_fiscal) from ods.tb_dsod_nfeuf_reextracao_ip_transmissor
where  data_incl_ods is null --90571
where data_incl_ods is not null --218214

select * from ods.tb_dsod_nfeuf_reextracao_ip_transmissor
where chave_acesso_nota_fiscal = 41180105236166000125550010000986421002415632


update ods.tb_dsod_nfeuf_reextracao_ip_transmissor set data_incl_ods = getdate()
where data_incl_ods is  null
commit;
select * from ods.tb_dsod_nfeuf_reextracao_ip_transmissor
where data_incl_ods is null


commit;
select count(distinct(chave_acesso_nota_fiscal)) from ods.tb_dsod_nfe_reextracao_ip_transmissor


select * from ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal = 35170501771935000215550030006481971311159433

select chave_acesso_nota_fiscal, count(1)
from ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal in
(
35141004337168000652550010066687401101588377,
35141004337168000652550010066687411101588382,
35141033200056000220550020016768441397437913,
35141033200056000220550020016768581571607020,
35141102549565000158550010000029411092000009,
35141167620377003130550010006628091006628094,
35141167620377003130550010006627961006627969,
35141106225746000180550030000250781999749216,
35141167620377003130550010006628131006628135,
35141167620377003130550010006628031006628031
)
group by chave_acesso_nota_fiscal

SELECT COUNT(1)
FROM ods.tb_dsod_nfe_reextracao_ip_transmissor
where chave_acesso_nota_fiscal in (SELECT chave_acesso_nota_fiscal
      FROM ods.tb_dsod_nfe_reextracao_ip_transmissor
      WHERE ((chave_acesso_nota_fiscal / 100000000000000000000000000000000000000) -350000) > 1410
      GROUP BY chave_acesso_nota_fiscal
      HAVING COUNT(1) > 1)--24.715.056


select count(1)
from ods.tb_dsod_nfe_reextracao_ip_transmissor
where  chave_acesso_nota_fiscal = 35141004337168000652550010066687401101588377


----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
-- TABELA IE DEST
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
select *
from ods.tb_dsod_nfe_reextracao
WHERE
-- data_extracao IS NOT NULL
-- data_extracao IS NULL
 chave_acesso_nota_fiscal = 35111159104422002446550030007083855622312544

commit;
select *
 from ods.tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr_reextracao 


commit;
select COUNT(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr_reextracao 


delete from ods.tb_dsod_nfe_reextracao

insert into ods.tb_dsod_nfe_reextracao(chave_acesso_nota_fiscal, data_incl_ods)
values (35160899171171171115550011561250011195066939, getdate())

commit;
select * from ods.tb_dsod_nfe_reextracao WHERE DATA_EXTRACAO IS NULL

update ods.tb_dsod_nfe_reextracao
set DATA_EXTRACAO = '2020-02-29'
where chave_acesso_nota_fiscal = 35160899171171171115550011561250011195066939


commit;
select * from ods.tb_dsod_nfe_reextracao
where chave_acesso_nota_fiscal = 35110300190373000687550040000042011463592635

insert into ods.tb_dsod_nfe_reextracao (chave_acesso_nota_fiscal, ref_mes_emissao, motivo_reextracao, data_incl_ods)
values(35110300190373000687550040000042011463592635, '201103', 'Chaves ausentes tabela protocolo',	'2019-05-09 10:16:50.790')
where chave_acesso_nota_fiscal = 35110300190373000687550040000042011463592635


select COUNT(1) from ods.tb_dsod_nfeuf_reextracao WHERE DATA_EXTRACAO IS NULL
--100200948
select TOP 1 * from ods.tb_dsod_nfe_reextracao  WHERE DATA_EXTRACAO IS NULL
--35160899171171171115550011561250011195066939				2019-05-16 14:07:41.290

select * from ods.tb_dsod_nfe_reextracao  WHERE DATA_EXTRACAO > '2019-01-01'

commit;
select COUNT(1) from ods.tb_dsod_nfe_reextracao
WHERE DATA_EXTRACAO > '2019-05-15'
--999843

and motivo_reextracao = 'num_id_dest, descr_email_dest'
and data_incl_ods is null

--update ods.tb_dsod_nfe_reextracao set data_incl_ods = '2018-12-10 09:47' WHERE motivo_reextracao = 'num_id_dest, descr_email_dest'

commit;
select * from ods.tb_dsod_nfe_reextracao
WHERE DATA_EXTRACAO is null

select * from ods.tb_dsod_nfeuf_reextracao
WHERE DATA_EXTRACAO is null


35160899171171171115550011561250011195066939

commit;
select COUNT(*) from ods.tb_dsod_nfe_reextracao
WHERE DATA_EXTRACAO is null
--840512

COUNT(1)
1840355


commit;
select count(*) from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao
select top 10 * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao
where cod_est_atend_solic <> '35'
where chave_acesso_nota_fiscal = '35160899171171171115550011561250011195066939'

SELECT DISTINCT TOP 10 CAST(chave_acesso_nota_fiscal AS varchar(44)) as chave_acesso_nota_fiscal FROM [ods].[tb_dsod_nfe_reextracao] WHERE data_extracao IS NULL 


CREATE OR REPLACE VARIABLE pKey_inicial_nfce_sinc INT = 2720107;


--delete from ods.tb_dsod_nfe_tmp_transmissor
--delete from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
--delete from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao
commit;
select * from ods.tb_dsod_nfe_tmp_transmissor
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao

commit;
select * from ods.tb_dsod_mdfe_tmp_eventos_gen
select * from ods.tb_dsod_mdfe_tmp_eventos_inc_dfe
select * from ods.tb_dsod_mdfe_tmp_eventos_inc_dfe_inf_doc

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_nfe_ref

select count(1) as tmp_evt_cte_cancelado  from ods.tb_dsod_nfe_tmp_evt_cte_cancelado_reextracao
select count(1) as tmp_doc_fiscal_evt_cancel  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cancel_reextracao
select count(1) as tmp_doc_fiscal_evt_averbacao_exportacao  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao_reextracao
select count(1) as tmp_doc_fiscal_evt_averbacao_exportacao_prod  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao_prod_reextracao
select count(1) as tmp_doc_fiscal_evt_cce  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cce_reextracao
select count(1) as tmp_doc_fiscal_evt_epec  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_epec_reextracao
select count(1) as tmp_doc_fiscal_evt_gen  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen_reextracao
select count(1) as tmp_doc_fiscal_evt_manif  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_manif_reextracao
select count(1) as tmp_doc_fiscal_evt_reg_passagem_brid  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid_reextracao
select count(1) as tmp_evt_canc_mdfe  from ods.tb_dsod_nfe_tmp_evt_canc_mdfe_reextracao
select count(1) as tmp_evt_canc_mdfe_det_mdfe  from ods.tb_dsod_nfe_tmp_evt_canc_mdfe_det_mdfe_reextracao
select count(1) as tmp_evt_cte_autorizado  from ods.tb_dsod_nfe_tmp_evt_cte_autorizado_reextracao
select count(1) as tmp_evt_inter_suframa  from ods.tb_dsod_nfe_tmp_evt_inter_suframa_reextracao
select count(1) as tmp_evt_mdfe  from ods.tb_dsod_nfe_tmp_evt_mdfe_reextracao
select count(1) as tmp_evt_mdfe_det_emit  from ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit_reextracao
select count(1) as tmp_evt_mdfe_det_mdfe  from ods.tb_dsod_nfe_tmp_evt_mdfe_det_mdfe_reextracao
select count(1) as tmp_evt_pedido_corindus  from ods.tb_dsod_nfe_tmp_evt_pedido_corindus_reextracao
select count(1) as tmp_evt_pedido_corindus_item  from ods.tb_dsod_nfe_tmp_evt_pedido_corindus_item_reextracao
select count(1) as tmp_evt_registro_passagem  from ods.tb_dsod_nfe_tmp_evt_registro_passagem_reextracao
select count(1) as tmp_evt_resp_corindus_item  from ods.tb_dsod_nfe_tmp_evt_resp_corindus_item_reextracao
select count(1) as tmp_evt_resp_pedido_corindus  from ods.tb_dsod_nfe_tmp_evt_resp_pedido_corindus_reextracao
select count(1) as tmp_evt_vistoria_Suframa  from ods.tb_dsod_nfe_tmp_evt_vistoria_Suframa_reextracao
select count(1) as tmp_visao_issqn_item  from ods.tb_dsod_nfe_tmp_visao_issqn_item_reextracao
select count(1) as tmp_transmissor  from ods.tb_dsod_nfe_tmp_transmissor_reextracao
select count(1) as tmp_partilha_icms  from ods.tb_dsod_nfe_tmp_partilha_icms_reextracao
select count(1) as tmp_nve  from ods.tb_dsod_nfe_tmp_nve_reextracao
select count(1) as tmp_inform_pagto  from ods.tb_dsod_nfe_tmp_inform_pagto_reextracao
select count(1) as tmp_forma_pagto  from ods.tb_dsod_nfe_tmp_forma_pagto_reextracao
select count(1) as tmp_doc_fiscal_transp_vol  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_vol_reextracao
select count(1) as tmp_doc_fiscal_transp_reb  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_reb_reextracao
select count(1) as tmp_doc_fiscal_transp_lac  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_lac_reextracao
select count(1) as tmp_doc_fiscal_transp  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_reextracao
select count(1) as tmp_doc_fiscal_total  from ods.tb_dsod_nfe_tmp_doc_fiscal_total_reextracao
select count(1) as tmp_doc_fiscal_repr  from ods.tb_dsod_nfe_tmp_doc_fiscal_repr_reextracao
select count(1) as tmp_doc_fiscal_ref_pap  from ods.tb_dsod_nfe_tmp_doc_fiscal_ref_pap_reextracao
select count(1) as tmp_doc_fiscal_ref_nfe  from ods.tb_dsod_nfe_tmp_doc_fiscal_ref_nfe_reextracao
select count(1) as tmp_doc_fiscal_prot_rec  from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao
select count(1) as tmp_doc_fiscal_prod_veicn  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_veicn_reextracao
select count(1) as tmp_doc_fiscal_prod_repr  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_repr_reextracao
select count(1) as tmp_doc_fiscal_prod_rastreab  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_rastreab_reextracao
select count(1) as tmp_doc_fiscal_prod_medic  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_medic_reextracao
select count(1) as tmp_doc_fiscal_prod_dia  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_dia_reextracao
select count(1) as tmp_doc_fiscal_prod_di  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_di_reextracao
select count(1) as tmp_doc_fiscal_prod_det_export  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_det_export_reextracao
select count(1) as tmp_doc_fiscal_prod_comb  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_comb_reextracao
select count(1) as tmp_doc_fiscal_prod_armto  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_armto_reextracao
select count(1) as tmp_doc_fiscal_prod  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_reextracao
select count(1) as tmp_doc_fiscal_icms_uf_dest  from ods.tb_dsod_nfe_tmp_doc_fiscal_icms_uf_dest_reextracao
select count(1) as tmp_doc_fiscal_emit_loc_ret  from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret_reextracao
select count(1) as tmp_doc_fiscal_dest_loc_entr  from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr_reextracao
select count(1) as tmp_doc_fiscal_compras  from ods.tb_dsod_nfe_tmp_doc_fiscal_compras_reextracao
select count(1) as tmp_doc_fiscal_cobr_dup  from ods.tb_dsod_nfe_tmp_doc_fiscal_cobr_dup_reextracao
select count(1) as tmp_doc_fiscal_cobr  from ods.tb_dsod_nfe_tmp_doc_fiscal_cobr_reextracao
select count(1) as tmp_doc_fiscal_cext  from ods.tb_dsod_nfe_tmp_doc_fiscal_cext_reextracao
select count(1) as tmp_doc_fiscal_Atual  from ods.tb_dsod_nfe_tmp_doc_fiscal_Atual_reextracao
select count(1) as tmp_doc_fiscal_Ant  from ods.tb_dsod_nfe_tmp_doc_fiscal_Ant_reextracao
select count(1) as tmp_doc_fiscal  from ods.tb_dsod_nfe_tmp_doc_fiscal_reextracao
select count(1) as tmp_doc_fisc_inf_adic_proces  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_proces_reextracao
select count(1) as tmp_doc_fisc_inf_adic_fisco  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_fisco_reextracao
select count(1) as tmp_doc_fisc_inf_adic_contrib  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_contrib_reextracao
select count(1) as tmp_doc_fisc_inf_adic  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_reextracao
select count(1) as tmp_comb_agreg_mes  from ods.tb_dsod_nfe_tmp_comb_agreg_mes_reextracao
select count(1) as tmp_cnpj_dest_inat  from ods.tb_dsod_nfe_tmp_cnpj_dest_inat_reextracao
select count(1) as tmp_cfop  from ods.tb_dsod_nfe_tmp_cfop_reextracao
select count(1) as tmp_autor_xml  from ods.tb_dsod_nfe_tmp_autor_xml_reextracao
select count(1) as tmp_aquisicao_cana_dia  from ods.tb_dsod_nfe_tmp_aquisicao_cana_dia_reextracao
select count(1) as tmp_aquisicao_cana_dedu  from ods.tb_dsod_nfe_tmp_aquisicao_cana_dedu_reextracao
select count(1) as tmp_aquisicao_cana  from ods.tb_dsod_nfe_tmp_aquisicao_cana_reextracao
select count(1) as tmp_doc_fiscal_evt_nfe_ref  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_nfe_ref_reextracao

select count(1) as tmp_evt_canc_reg_passagem  from ods.tb_dsod_nfe_tmp_evt_canc_reg_passagem_reextracao
select count(1) as tmp_evt_pedido_canc_corindus  from ods.tb_dsod_nfe_tmp_evt_pedido_canc_corindus_reextracao
select count(1) as tmp_evt_resp_pedido_canc_corindus  from ods.tb_dsod_nfe_tmp_evt_resp_pedido_canc_corindus_reextracao
select count(1) as tmp_doc_fiscal_evt_irreg_fiscal  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal_reextracao
select count(1) as tmp_doc_fiscal_inutilizacao  from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao_reextracao
select count(1) as tmp_doc_fisc_inf_fisco  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_fisco_reextracao
select count(1) as tmp_doc_fiscal_cancel  from ods.tb_dsod_nfe_tmp_doc_fiscal_cancel_reextracao
select count(1) as tmp_doc_fiscal_evt_irreg_fiscal_cancel  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal_cancel_reextracao





select count(1) as tb_dsod_nfe_tmp_doc_fiscal_cancel  from ods.tb_dsod_nfe_tmp_doc_fiscal_cancel
select count(1) as tb_dsod_nfe_tmp_evt_cte_cancelado  from ods.tb_dsod_nfe_tmp_evt_cte_cancelado
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal_cancel  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal_cancel
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_cancel  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cancel
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao_prod  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao_prod
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_cce  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cce
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_epec  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_epec
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_gen  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_irreg_fiscal
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_manif  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_manif
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_reg_passagem_brid
select count(1) as tb_dsod_nfe_tmp_evt_canc_mdfe  from ods.tb_dsod_nfe_tmp_evt_canc_mdfe
select count(1) as tb_dsod_nfe_tmp_evt_canc_mdfe_det_mdfe  from ods.tb_dsod_nfe_tmp_evt_canc_mdfe_det_mdfe
select count(1) as tb_dsod_nfe_tmp_evt_canc_reg_passagem  from ods.tb_dsod_nfe_tmp_evt_canc_reg_passagem
select count(1) as tb_dsod_nfe_tmp_evt_cte_autorizado  from ods.tb_dsod_nfe_tmp_evt_cte_autorizado
select count(1) as tb_dsod_nfe_tmp_evt_inter_suframa  from ods.tb_dsod_nfe_tmp_evt_inter_suframa
select count(1) as tb_dsod_nfe_tmp_evt_mdfe  from ods.tb_dsod_nfe_tmp_evt_mdfe
select count(1) as tb_dsod_nfe_tmp_evt_mdfe_det_emit  from ods.tb_dsod_nfe_tmp_evt_mdfe_det_emit
select count(1) as tb_dsod_nfe_tmp_evt_mdfe_det_mdfe  from ods.tb_dsod_nfe_tmp_evt_mdfe_det_mdfe
select count(1) as tb_dsod_nfe_tmp_evt_pedido_canc_corindus  from ods.tb_dsod_nfe_tmp_evt_pedido_canc_corindus
select count(1) as tb_dsod_nfe_tmp_evt_pedido_corindus  from ods.tb_dsod_nfe_tmp_evt_pedido_corindus
select count(1) as tb_dsod_nfe_tmp_evt_pedido_corindus_item  from ods.tb_dsod_nfe_tmp_evt_pedido_corindus_item
select count(1) as tb_dsod_nfe_tmp_evt_registro_passagem  from ods.tb_dsod_nfe_tmp_evt_registro_passagem
select count(1) as tb_dsod_nfe_tmp_evt_resp_corindus_item  from ods.tb_dsod_nfe_tmp_evt_resp_corindus_item
select count(1) as tb_dsod_nfe_tmp_evt_resp_pedido_canc_corindus  from ods.tb_dsod_nfe_tmp_evt_resp_pedido_canc_corindus
select count(1) as tb_dsod_nfe_tmp_evt_resp_pedido_corindus  from ods.tb_dsod_nfe_tmp_evt_resp_pedido_corindus
select count(1) as tb_dsod_nfe_tmp_evt_vistoria_Suframa  from ods.tb_dsod_nfe_tmp_evt_vistoria_Suframa
select count(1) as tb_dsod_nfe_tmp_visao_issqn_item  from ods.tb_dsod_nfe_tmp_visao_issqn_item
select count(1) as tb_dsod_nfe_tmp_transmissor  from ods.tb_dsod_nfe_tmp_transmissor
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia_03  from ods.tb_dsod_nfe_tmp_quebra_sequencia_03
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia_02  from ods.tb_dsod_nfe_tmp_quebra_sequencia_02
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia_00_0  from ods.tb_dsod_nfe_tmp_quebra_sequencia_00_0
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia_00  from ods.tb_dsod_nfe_tmp_quebra_sequencia_00
select count(1) as tb_dsod_nfe_tmp_prod_sum_ncm  from ods.tb_dsod_nfe_tmp_prod_sum_ncm
select count(1) as tb_dsod_nfe_tmp_partilha_icms  from ods.tb_dsod_nfe_tmp_partilha_icms
select count(1) as tb_dsod_nfe_tmp_nve  from ods.tb_dsod_nfe_tmp_nve
select count(1) as tb_dsod_nfe_tmp_inform_pagto  from ods.tb_dsod_nfe_tmp_inform_pagto
select count(1) as tb_dsod_nfe_tmp_forma_pagto  from ods.tb_dsod_nfe_tmp_forma_pagto
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_transp_vol  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_vol
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_transp_reb  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_reb
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_transp_lac  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_lac
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_transp  from ods.tb_dsod_nfe_tmp_doc_fiscal_transp
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_total  from ods.tb_dsod_nfe_tmp_doc_fiscal_total
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_repr  from ods.tb_dsod_nfe_tmp_doc_fiscal_repr
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_ref_pap  from ods.tb_dsod_nfe_tmp_doc_fiscal_ref_pap
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_ref_nfe  from ods.tb_dsod_nfe_tmp_doc_fiscal_ref_nfe
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prot_rec  from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec where data_extracao_arquivo > '2020-09-03'
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_veicn  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_veicn
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_repr  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_repr
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_rastreab  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_rastreab
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_medic  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_medic
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_dia  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_dia
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_di  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_di
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_det_export  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_det_export
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_comb  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_comb
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_armto  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_armto
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_20170330_BKP  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_20170330_BKP
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_icms_uf_dest  from ods.tb_dsod_nfe_tmp_doc_fiscal_icms_uf_dest
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret  from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr  from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_compras  from ods.tb_dsod_nfe_tmp_doc_fiscal_compras
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_cobr_dup  from ods.tb_dsod_nfe_tmp_doc_fiscal_cobr_dup
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_cobr  from ods.tb_dsod_nfe_tmp_doc_fiscal_cobr
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_cext  from ods.tb_dsod_nfe_tmp_doc_fiscal_cext
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_Atual  from ods.tb_dsod_nfe_tmp_doc_fiscal_Atual
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_Ant  from ods.tb_dsod_nfe_tmp_doc_fiscal_Ant
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_20170330_BKP  from ods.tb_dsod_nfe_tmp_doc_fiscal_20170330_BKP
select count(1) as tb_dsod_nfe_tmp_doc_fiscal  from ods.tb_dsod_nfe_tmp_doc_fiscal
select count(1) as tb_dsod_nfe_tmp_doc_fisc_inf_fisco  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_fisco
select count(1) as tb_dsod_nfe_tmp_doc_fisc_inf_adic_proces  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_proces
select count(1) as tb_dsod_nfe_tmp_doc_fisc_inf_adic_fisco  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_fisco
select count(1) as tb_dsod_nfe_tmp_doc_fisc_inf_adic_contrib  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_contrib
select count(1) as tb_dsod_nfe_tmp_doc_fisc_inf_adic  from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic
select count(1) as tb_dsod_nfe_tmp_comb_agreg_mes  from ods.tb_dsod_nfe_tmp_comb_agreg_mes
select count(1) as tb_dsod_nfe_tmp_cnpj_dest_inat  from ods.tb_dsod_nfe_tmp_cnpj_dest_inat
select count(1) as tb_dsod_nfe_tmp_cfop  from ods.tb_dsod_nfe_tmp_cfop
select count(1) as tb_dsod_nfe_tmp_autor_xml  from ods.tb_dsod_nfe_tmp_autor_xml
select count(1) as tb_dsod_nfe_tmp_aquisicao_cana_dia  from ods.tb_dsod_nfe_tmp_aquisicao_cana_dia
select count(1) as tb_dsod_nfe_tmp_aquisicao_cana_dedu  from ods.tb_dsod_nfe_tmp_aquisicao_cana_dedu
select count(1) as tb_dsod_nfe_tmp_aquisicao_cana  from ods.tb_dsod_nfe_tmp_aquisicao_cana
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_Ant_Inut_det  from ods.tb_dsod_nfe_tmp_doc_fiscal_Ant_Inut_det
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_inutilizacao  from ods.tb_dsod_nfe_tmp_doc_fiscal_inutilizacao
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_nfe_ref  from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_nfe_ref

select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_nfe_ref  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_nfe_ref
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_cancel  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_cancel
select count(1) as tb_dsod_nfeuf_tmp_evt_cte_cancelado  from ods.tb_dsod_nfeuf_tmp_evt_cte_cancelado
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal_cancel  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal_cancel
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao_prod  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao_prod
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_epec  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_epec
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_irreg_fiscal
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_reg_passagem_brid  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_reg_passagem_brid
select count(1) as tb_dsod_nfeuf_tmp_evt_canc_mdfe  from ods.tb_dsod_nfeuf_tmp_evt_canc_mdfe
select count(1) as tb_dsod_nfeuf_tmp_evt_canc_mdfe_det_mdfe  from ods.tb_dsod_nfeuf_tmp_evt_canc_mdfe_det_mdfe
select count(1) as tb_dsod_nfeuf_tmp_evt_canc_reg_passagem from ods.tb_dsod_nfeuf_tmp_evt_canc_reg_passagem
select count(1) as tb_dsod_nfeuf_tmp_evt_cte_autorizado  from ods.tb_dsod_nfeuf_tmp_evt_cte_autorizado
select count(1) as tb_dsod_nfeuf_tmp_evt_inter_suframa  from ods.tb_dsod_nfeuf_tmp_evt_inter_suframa
select count(1) as tb_dsod_nfeuf_tmp_evt_mdfe  from ods.tb_dsod_nfeuf_tmp_evt_mdfe
select count(1) as tb_dsod_nfeuf_tmp_evt_mdfe_det_emit  from ods.tb_dsod_nfeuf_tmp_evt_mdfe_det_emit
select count(1) as tb_dsod_nfeuf_tmp_evt_mdfe_det_mdfe  from ods.tb_dsod_nfeuf_tmp_evt_mdfe_det_mdfe
select count(1) as tb_dsod_nfeuf_tmp_evt_pedido_canc_corindus  from ods.tb_dsod_nfeuf_tmp_evt_pedido_canc_corindus
select count(1) as tb_dsod_nfeuf_tmp_evt_pedido_corindus  from ods.tb_dsod_nfeuf_tmp_evt_pedido_corindus
select count(1) as tb_dsod_nfeuf_tmp_evt_pedido_corindus_item  from ods.tb_dsod_nfeuf_tmp_evt_pedido_corindus_item
select count(1) as tb_dsod_nfeuf_tmp_evt_registro_passagem from ods.tb_dsod_nfeuf_tmp_evt_registro_passagem
select count(1) as tb_dsod_nfeuf_tmp_evt_resp_corindus_item  from ods.tb_dsod_nfeuf_tmp_evt_resp_corindus_item
select count(1) as tb_dsod_nfeuf_tmp_evt_resp_pedido_canc_corindus  from ods.tb_dsod_nfeuf_tmp_evt_resp_pedido_canc_corindus
select count(1) as tb_dsod_nfeuf_tmp_evt_resp_pedido_corindus  from ods.tb_dsod_nfeuf_tmp_evt_resp_pedido_corindus
select count(1) as tb_dsod_nfeuf_tmp_evt_vistoria_Suframa  from ods.tb_dsod_nfeuf_tmp_evt_vistoria_Suframa
select count(1) as tb_dsod_nfeuf_tmp_visao_issqn_item  from ods.tb_dsod_nfeuf_tmp_visao_issqn_item
select count(1) as tb_dsod_nfeuf_tmp_transmissor  from ods.tb_dsod_nfeuf_tmp_transmissor
select count(1) as tb_dsod_nfeuf_tmp_quebra_sequencia_03  from ods.tb_dsod_nfeuf_tmp_quebra_sequencia_03
select count(1) as tb_dsod_nfeuf_tmp_quebra_sequencia_02  from ods.tb_dsod_nfeuf_tmp_quebra_sequencia_02
select count(1) as tb_dsod_nfeuf_tmp_quebra_sequencia_00_0  from ods.tb_dsod_nfeuf_tmp_quebra_sequencia_00_0
select count(1) as tb_dsod_nfeuf_tmp_quebra_sequencia_00  from ods.tb_dsod_nfeuf_tmp_quebra_sequencia_00
select count(1) as tb_dsod_nfeuf_tmp_prod_sum_ncm  from ods.tb_dsod_nfeuf_tmp_prod_sum_ncm
select count(1) as tb_dsod_nfeuf_tmp_partilha_icms  from ods.tb_dsod_nfeuf_tmp_partilha_icms
select count(1) as tb_dsod_nfeuf_tmp_nve  from ods.tb_dsod_nfeuf_tmp_nve
select count(1) as tb_dsod_nfeuf_tmp_inform_pagto  from ods.tb_dsod_nfeuf_tmp_inform_pagto
select count(1) as tb_dsod_nfeuf_tmp_forma_pagto  from ods.tb_dsod_nfeuf_tmp_forma_pagto
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_transp_vol  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_vol
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_transp_reb  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_reb
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_transp_lac  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp_lac
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_transp  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_transp
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_total  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_total
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_resp_tecnico  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_resp_tecnico
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_repr  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_repr
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_ref_pap  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_ref_pap
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_ref_nfe  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_ref_nfe
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_veicn  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_veicn
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_repr  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_repr
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_rastreab  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_rastreab
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_medic  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_medic
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_dia  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_dia
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_di  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_di
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_det_export  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_det_export
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_comb  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_comb
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_armto  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_armto
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod_20170330_BKP  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod_20170330_BKP
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_prod  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_icms_uf_dest  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_icms_uf_dest
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_emit_loc_ret  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_emit_loc_ret
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_compras  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_compras
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_cobr_dup  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_cobr_dup
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_cobr  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_cobr
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_cext  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_cext
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_Atual  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_Atual
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_Ant  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_Ant
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_20170330_BKP  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_20170330_BKP
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal  from ods.tb_dsod_nfeuf_tmp_doc_fiscal
select count(1) as tb_dsod_nfeuf_tmp_doc_fisc_inf_fisco  from ods.tb_dsod_nfeuf_tmp_doc_fisc_inf_fisco
select count(1) as tb_dsod_nfeuf_tmp_doc_fisc_inf_adic_proces  from ods.tb_dsod_nfeuf_tmp_doc_fisc_inf_adic_proces
select count(1) as tb_dsod_nfeuf_tmp_doc_fisc_inf_adic_fisco  from ods.tb_dsod_nfeuf_tmp_doc_fisc_inf_adic_fisco
select count(1) as tb_dsod_nfeuf_tmp_doc_fisc_inf_adic_contrib  from ods.tb_dsod_nfeuf_tmp_doc_fisc_inf_adic_contrib
select count(1) as tb_dsod_nfeuf_tmp_doc_fisc_inf_adic  from ods.tb_dsod_nfeuf_tmp_doc_fisc_inf_adic
select count(1) as tb_dsod_nfeuf_tmp_comb_agreg_mes  from ods.tb_dsod_nfeuf_tmp_comb_agreg_mes
select count(1) as tb_dsod_nfeuf_tmp_cnpj_dest_inat  from ods.tb_dsod_nfeuf_tmp_cnpj_dest_inat
select count(1) as tb_dsod_nfeuf_tmp_cfop  from select * from ods.tb_dsod_nfeuf_tmp_cfop
select count(1) as tb_dsod_nfeuf_tmp_autor_xml  from ods.tb_dsod_nfeuf_tmp_autor_xml
select count(1) as tb_dsod_nfeuf_tmp_aquisicao_cana_dia  from ods.tb_dsod_nfeuf_tmp_aquisicao_cana_dia
select count(1) as tb_dsod_nfeuf_tmp_aquisicao_cana_dedu  from ods.tb_dsod_nfeuf_tmp_aquisicao_cana_dedu
select count(1) as tb_dsod_nfeuf_tmp_aquisicao_cana  from ods.tb_dsod_nfeuf_tmp_aquisicao_cana
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_Ant_Inut_det  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_Ant_Inut_det
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_inutilizacao  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_inutilizacao
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel_CORR  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel_CORR
select count(1) as tb_dsod_nfeuf_tmp_troca_drt  from ods.tb_dsod_nfeuf_tmp_troca_drt
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_00  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_00
select count(1) as tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr_reextracao  from ods.tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr_reextracao

select count(1) as tb_dsod_nfe_tmp_troca_drt  from ods.tb_dsod_nfe_tmp_troca_drt
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia_06  from ods.tb_dsod_nfe_tmp_quebra_sequencia_06
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia_04  from ods.tb_dsod_nfe_tmp_quebra_sequencia_04
select count(1) as tb_dsod_nfe_tmp_quebra_sequencia  from ods.tb_dsod_nfe_tmp_quebra_sequencia
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao  from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_prod_armto_bkp  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_armto_bkp
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr_reextracao  from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr_reextracao
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_00  from ods.tb_dsod_nfe_tmp_doc_fiscal_00
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_compr_entr_cte from          ods.tb_dsod_nfe_tmp_doc_fiscal_evt_compr_entr_cte
select count(1) as tb_dsod_nfe_tmp_doc_fiscal_evt_canc_compr_entr_cte from     ods.tb_dsod_nfe_tmp_doc_fiscal_evt_canc_compr_entr_cte

insert into ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel_reextracao(cod_amarracao_arquivo,num_versao_leiaute,num_prot_cancel,descr_just,data_extracao_arquivo,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria) (select cod_amarracao_arquivo,num_versao_leiaute,num_prot_cancel,descr_just,data_extracao_arquivo,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel)
insert into ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce_reextracao(cod_amarracao_arquivo,num_versao_leiaute,descr_correcao,data_extracao_arquivo,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria) (select cod_amarracao_arquivo,num_versao_leiaute,descr_correcao,data_extracao_arquivo,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce)
insert into ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen_reextracao(cod_amarracao_arquivo,id_evento,ind_tipo_ambiente,num_versao_leiaute,num_versao_aplicativo,cod_est_evento,num_ano,cod_receptor,cod_status,chave_acesso_nota_fiscal,data_evento,ind_tipo_evento,num_seq_evento,descr_email,num_protocolo,data_registro,data_extracao_arquivo,cod_orgao_pk,num_cnpj_cpf_dest,ind_tipo_dest,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria,num_ip_transmissor,num_porta_conexao,data_hora_conexao) (select cod_amarracao_arquivo,id_evento,ind_tipo_ambiente,num_versao_leiaute,num_versao_aplicativo,cod_est_evento,num_ano,cod_receptor,cod_status,chave_acesso_nota_fiscal,data_evento,ind_tipo_evento,num_seq_evento,descr_email,num_protocolo,data_registro,data_extracao_arquivo,cod_orgao_pk,num_cnpj_cpf_dest,ind_tipo_dest,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria,num_ip_transmissor,num_porta_conexao,data_hora_conexao from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen)
insert into ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif_reextracao(cod_amarracao_arquivo,cod_versao_manifest,descr_evento,descr_just,data_extracao_arquivo,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria) (select cod_amarracao_arquivo,cod_versao_manifest,descr_evento,descr_just,data_extracao_arquivo,id_autor,ind_tp_id_autor,ind_origem,cod_auditoria from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif)
insert into ods.tb_dsod_nfeuf_tmp_evt_registro_passagem_reextracao (cod_amarracao_arquivo,num_versao_leiaute,descr_evento,cod_orgao_autor,cod_posto_uf,nome_posto_uf,num_latitude_gps,num_longitude_gps,num_cpf_oper,nome_Oper,ind_trans_offline,data_Passagem,id_sentido_via,ind_retorno,uf_destino_evt,descr_Obs,chave_mdfe,chave_cte,num_placa_veiculo,uf_veiculo,num_placa_carreta,uf_carreta,num_placa_carreta2,uf_carreta2,ind_tp_Modal,descr_ident_transp,num_form_seg,uf_destino_ctg,ind_tp_emis,num_cnpj_dest,num_cpf_dest,ind_icms,ind_icms_st,dia_emissao_nfe,data_extracao,id_autor,ind_tp_id_autor,ind_origem,valor_total_nfe,cod_auditoria) (select cod_amarracao_arquivo,num_versao_leiaute,descr_evento,cod_orgao_autor,cod_posto_uf,nome_posto_uf,num_latitude_gps,num_longitude_gps,num_cpf_oper,nome_Oper,ind_trans_offline,data_Passagem,id_sentido_via,ind_retorno,uf_destino_evt,descr_Obs,chave_mdfe,chave_cte,num_placa_veiculo,uf_veiculo,num_placa_carreta,uf_carreta,num_placa_carreta2,uf_carreta2,ind_tp_Modal,descr_ident_transp,num_form_seg,uf_destino_ctg,ind_tp_emis,num_cnpj_dest,num_cpf_dest,ind_icms,ind_icms_st,dia_emissao_nfe,data_extracao,id_autor,ind_tp_id_autor,ind_origem,valor_total_nfe,cod_auditoria from ods.tb_dsod_nfeuf_tmp_evt_registro_passagem)

delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif
delete from ods.tb_dsod_nfeuf_tmp_evt_registro_passagem
commit;
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel_reextracao --576
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce_reextracao    --2781
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen_reextracao    --3363
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif_reextracao  --1
select count(1) from ods.tb_dsod_nfeuf_tmp_evt_registro_passagem_reextracao --5   



delete from ods.tb_dsod_nfeuf_tmp_evt_registro_passagem
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_manif
delete from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce

select * from ods.tb_dsod_nfe_tmp_troca_drt
select * from ods.tb_dsod_nfe_tmp_quebra_sequencia_06
select * from ods.tb_dsod_nfe_tmp_quebra_sequencia_04
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec_reextracao
select *  from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_armto_bkp
select *  from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr_reextracao
select *  from ods.tb_dsod_nfe_tmp_doc_fiscal_00
select * from ods.tb_dsod_nfeuf_tmp_troca_drt
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_00



commit;
select id_evento, cod_orgao_pk, num_protocolo, count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
group by id_evento, cod_orgao_pk, num_protocolo
having count(1) > 1
order by count(1) desc

select num_protocolo, count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
where id_evento = '4103003519060878254800057655002000001302160834186601'
group by num_protocolo
order by count(1) desc

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen
where id_evento = '4103003519060878254800057655002000001302160834186601'

-----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------

insert into [ods].[tb_dsod_nfe_reextracao](chave_acesso_nota_fiscal)
values(35161199171171171115550441563550341640030295),
values(35161299171171171115550441563650341640030292),
values(35161299171171171115550441563650341640030292),
values(35170599171171171115550011565952711712931126),
values(35170599171171171115550441565952751640030292),
values(35170599171171171115550441566152561640030290),
values(35170599171171171115550440010068981640030290),
values(35170599171171171115550440010068981640030290),
values(35170599171171171115550011566152601712931126),
values(35170999171171171115550011569053881712931121)

update [ods].[tb_dsod_nfe_reextracao] set data_extracao = null
delete from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec 
delete from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen

commit;
select * from [ods].[tb_dsod_nfe_reextracao] where data_extracao is  null
select * from [ods].[tb_dsod_nfe_reextracao]

select * from ods.tb_dsod_nfe_tmp_transmissor
select * from ods.tb_dsod_nfe_tmp_partilha_icms
select * from ods.tb_dsod_nfe_tmp_forma_pagto
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_transp_vol
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_transp
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_total
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_dia
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod_di
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_prod
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_icms_uf_dest
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_emit_loc_ret
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_dest_loc_entr
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_cobr_dup
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_cobr
select * from ods.tb_dsod_nfe_tmp_doc_fiscal
select * from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic_contrib
select * from ods.tb_dsod_nfe_tmp_doc_fisc_inf_adic
select * from ods.tb_dsod_nfe_tmp_autor_xml
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_resp_tecnico where data_extracao_arquivo > '2020-09-03'

commit;--610130 610131
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen where data_extracao_arquivo > '2020-09-28'
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_compr_entr_cte
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_canc_compr_entr_cte

select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cancel
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_averbacao_exportacao
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_cce
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen




update [ods].[tb_dsod_nfeuf_reextracao] set data_extracao = null
delete from ods.tb_dsod_nfe_tmp_doc_fiscal_prot_rec
delete from ods.tb_dsod_nfe_tmp_doc_fiscal_evt_gen

update [ods].[tb_dsod_nfeuf_reextracao] set chave_acesso_nota_fiscal = 43110601471899000193552780062989281001215257 where data_extracao is  null

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec where chave_acesso_nota_fiscal = 43110601471899000193552780062989281001215257
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen where chave_acesso_nota_fiscal = 43110601471899000193552780062989281001215257

commit;
select * from [ods].[tb_dsod_nfeuf_reextracao] where data_extracao is  null
select * from [ods].[tb_dsod_nfeuf_reextracao]
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prot_rec_reextracao
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_prod
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_emit_loc_ret
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_dest_loc_entr
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_cobr_dup
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_cobr
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal
select * from ods.tb_dsod_nfeuf_tmp_doc_fisc_inf_adic

select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cancel
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_averbacao_exportacao
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_cce
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_evt_gen

commit
select * from ods.tb_dsod_nfe_tmp_doc_fiscal_resp_tecnico
select * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_resp_tecnico
select top 10 * from ods.tb_dsod_nfe_tmp_doc_fiscal_resp_tecnico_reextracao order by data_extracao_arquivo desc
select top 10 * from ods.tb_dsod_nfeuf_tmp_doc_fiscal_resp_tecnico_reextracao order by data_extracao_arquivo desc
select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_resp_tecnico_reextracao  --26.900.731 --117.817.377 --111.495.738 --71.760.690 --174.083.310
select count(1) from ods.tb_dsod_nfeuf_tmp_doc_fiscal_resp_tecnico_reextracao  --2.582.223 --15.759.227 -- 14.459.198 --17.715.801  --20.790.658

select count(1) from ods.tb_dsod_nfe_tmp_doc_fiscal_resp_tecnico_reextracao where data_extracao_arquivo > '2020-04-23' --1.511.906


select count(1) as 'tb_dsod_cte_tmp_passagem' from ods.tb_dsod_cte_tmp_passagem
select count(1) as 'tb_dsod_cte_tmp_obsFisco' from ods.tb_dsod_cte_tmp_obsFisco
select count(1) as 'tb_dsod_cte_tmp_infdoc_iutransp' from ods.tb_dsod_cte_tmp_infdoc_iutransp 
select count(1) as 'tb_dsod_cte_tmp_infdoc_iutransp_lacunidtran' from ods.tb_dsod_cte_tmp_infdoc_iutransp_lacunidtran
select count(1) as 'tb_dsod_cte_tmp_infdoc_iutransp_iuc' from ods.tb_dsod_cte_tmp_infdoc_iutransp_iuc
select count(1) as 'tb_dsod_cte_tmp_infdoc_iutransp_iuc_lacuc' from ods.tb_dsod_cte_tmp_infdoc_iutransp_iuc_lacuc
select count(1) as 'tb_dsod_cte_tmp_infdoc_iuncarga' from ods.tb_dsod_cte_tmp_infdoc_iuncarga
select count(1) as 'tb_dsod_cte_tmp_infdoc_iuncarga_lacuc' from ods.tb_dsod_cte_tmp_infdoc_iuncarga_lacuc
select count(1) as 'tb_dsod_cte_tmp_rodov_oc' from ods.tb_dsod_cte_tmp_rodov_oc 
select count(1) as 'tb_dsod_cte_tmp_aereo' from ods.tb_dsod_cte_tmp_aereo
select count(1) as 'tb_dsod_cte_tmp_aereo_manu' from ods.tb_dsod_cte_tmp_aereo_manu
select count(1) as 'tb_dsod_cte_tmp_aereo_peri' from ods.tb_dsod_cte_tmp_aereo_peri
select count(1) as 'tb_dsod_cte_tmp_aquav' from ods.tb_dsod_cte_tmp_aquav
select count(1) as 'tb_dsod_cte_tmp_aquav_balsa' from ods.tb_dsod_cte_tmp_aquav_balsa
select count(1) as 'tb_dsod_cte_tmp_aquav_detcont' from ods.tb_dsod_cte_tmp_aquav_detcont 
select count(1) as 'tb_dsod_cte_tmp_aquav_detcont_lacre' from ods.tb_dsod_cte_tmp_aquav_detcont_lacre 
select count(1) as 'tb_dsod_cte_tmp_aquav_detcont_infnf' from ods.tb_dsod_cte_tmp_aquav_detcont_infnf  
select count(1) as 'tb_dsod_cte_tmp_aquav_detcont_infnfe' from ods.tb_dsod_cte_tmp_aquav_detcont_infnfe  
select count(1) as 'tb_dsod_cte_tmp_ferrov' from ods.tb_dsod_cte_tmp_ferrov
select count(1) as 'tb_dsod_cte_tmp_ferrov_envol' from ods.tb_dsod_cte_tmp_ferrov_envol
select count(1) as 'tb_dsod_cte_tmp_multimodal' from ods.tb_dsod_cte_tmp_multimodal 
select count(1) as 'tb_dsod_cte_tmp_transp_veic_novos' from ods.tb_dsod_cte_tmp_transp_veic_novos
select count(1) as 'tb_dsod_cte_tmp_fatura' from ods.tb_dsod_cte_tmp_fatura
select count(1) as 'tb_dsod_cte_tmp_dup' from ods.tb_dsod_cte_tmp_dup
select count(1) as 'tb_dsod_cte_tmp_globalizado' from ods.tb_dsod_cte_tmp_globalizado
select count(1) as 'tb_dsod_cte_tmp_autxml' from ods.tb_dsod_cte_tmp_autxml
select count(1) as 'tb_dsod_cte_tmp_responsavel_tecnico' from ods.tb_dsod_cte_tmp_responsavel_tecnico
select count(1) as 'tb_dsod_cte_tmp_cce' from ods.tb_dsod_cte_tmp_cce
select count(1) as 'tb_dsod_cte_tmp_cce_infCorrecao' from ods.tb_dsod_cte_tmp_cce_infCorrecao
select count(1) as 'tb_dsod_cte_tmp_epec' from ods.tb_dsod_cte_tmp_epec
select count(1) as 'tb_dsod_cte_tmp_evento_multimodal' from ods.tb_dsod_cte_tmp_evento_multimodal
select count(1) as 'tb_dsod_cte_tmp_evento_compl_cancelado' from ods.tb_dsod_cte_tmp_evento_compl_cancelado
select count(1) as 'tb_dsod_cte_tmp_evento_liberacao_canc' from ods.tb_dsod_cte_tmp_evento_liberacao_canc
select count(1) as 'tb_dsod_cte_tmp_evento_liberacao_EPEC' from ods.tb_dsod_cte_tmp_evento_liberacao_EPEC
select count(1) as 'tb_dsod_cte_tmp_evento_registro_passagem' from ods.tb_dsod_cte_tmp_evento_registro_passagem
select count(1) as 'tb_dsod_cte_tmp_evento_canc_registro_passagem' from ods.tb_dsod_cte_tmp_evento_canc_registro_passagem
select count(1) as 'tb_dsod_cte_tmp_evento_prestacao_desacordo' from ods.tb_dsod_cte_tmp_evento_prestacao_desacordo

commit;
select count(1) as 'tb_dsod_cte_tmp_prot' from ods.tb_dsod_cte_tmp_prot
select count(1) as 'tb_dsod_cte_tmp_ide' from ods.tb_dsod_cte_tmp_ide
select count(1) as 'tb_dsod_cte_tmp_obsCont' from ods.tb_dsod_cte_tmp_obsCont
select count(1) as 'tb_dsod_cte_tmp_emit' from ods.tb_dsod_cte_tmp_emit
select count(1) as 'tb_dsod_cte_tmp_remet' from ods.tb_dsod_cte_tmp_remet
select count(1) as 'tb_dsod_cte_tmp_exped' from ods.tb_dsod_cte_tmp_exped
select count(1) as 'tb_dsod_cte_tmp_receb' from ods.tb_dsod_cte_tmp_receb
select count(1) as 'tb_dsod_cte_tmp_dest' from ods.tb_dsod_cte_tmp_dest
select count(1) as 'tb_dsod_cte_tmp_comp_vprest' from ods.tb_dsod_cte_tmp_comp_vprest
select count(1) as 'tb_dsod_cte_tmp_impostos' from ods.tb_dsod_cte_tmp_impostos
select count(1) as 'tb_dsod_cte_tmp_inf_carga_transp' from ods.tb_dsod_cte_tmp_inf_carga_transp
select count(1) as 'tb_dsod_cte_tmp_inf_qtd_carga' from ods.tb_dsod_cte_tmp_inf_qtd_carga
select count(1) as 'tb_dsod_cte_tmp_infdoc' from ods.tb_dsod_cte_tmp_infdoc
select count(1) as 'tb_dsod_cte_tmp_emit_docant' from ods.tb_dsod_cte_tmp_emit_docant
select count(1) as 'tb_dsod_cte_tmp_docant_pap' from ods.tb_dsod_cte_tmp_docant_pap
select count(1) as 'tb_dsod_cte_tmp_docant_eletr' from ods.tb_dsod_cte_tmp_docant_eletr
select count(1) as 'tb_dsod_cte_tmp_rodov' from ods.tb_dsod_cte_tmp_rodov
select count(1) as 'tb_dsod_cte_tmp_subst' from ods.tb_dsod_cte_tmp_subst
select count(1) as 'tb_dsod_cte_tmp_servvinc' from ods.tb_dsod_cte_tmp_servvinc
select count(1) as 'tb_dsod_cte_tmp_compl' from ods.tb_dsod_cte_tmp_compl
select count(1) as 'tb_dsod_cte_tmp_anul' from ods.tb_dsod_cte_tmp_anul
select count(1) as 'tb_dsod_cte_tmp_evento_generico' from ods.tb_dsod_cte_tmp_evento_generico
select count(1) as 'tb_dsod_cte_tmp_evento_canc' from ods.tb_dsod_cte_tmp_evento_canc
select count(1) as 'tb_dsod_cte_tmp_evento_substituido' from ods.tb_dsod_cte_tmp_evento_substituido
select count(1) as 'tb_dsod_cte_tmp_evento_anulado' from ods.tb_dsod_cte_tmp_evento_anulado
select count(1) as 'tb_dsod_cte_tmp_mdfe_autorizado' from ods.tb_dsod_cte_tmp_mdfe_autorizado
select count(1) as 'tb_dsod_cte_tmp_mdfe_cancelado' from ods.tb_dsod_cte_tmp_mdfe_cancelado
select count(1) as 'tb_dsod_cte_tmp_evento_autoriz_redesp' from ods.tb_dsod_cte_tmp_evento_autoriz_redesp
select count(1) as 'tb_dsod_cte_tmp_evento_autoriz_redesp_inter' from ods.tb_dsod_cte_tmp_evento_autoriz_redesp_inter
select count(1) as 'tb_dsod_cte_tmp_evento_autoriz_subcontrata' from ods.tb_dsod_cte_tmp_evento_autoriz_subcontrata
select count(1) as 'tb_dsod_cte_tmp_evento_marcacao_multimodal' from ods.tb_dsod_cte_tmp_evento_marcacao_multimodal
select count(1) as 'tb_dsod_cte_tmp_evento_registro_brid' from ods.tb_dsod_cte_tmp_evento_registro_brid
select count(1) as 'tb_dsod_cte_tmp_evento_compl_autorizado' from ods.tb_dsod_cte_tmp_evento_compl_autorizado
select count(1) as 'tb_dsod_cte_tmp_evento_comprov_entrega' from ods.tb_dsod_cte_tmp_evento_comprov_entrega
select count(1) as 'tb_dsod_cte_tmp_evento_comprov_entrega_inf_entrega' from ods.tb_dsod_cte_tmp_evento_comprov_entrega_inf_entrega
select count(1) as 'tb_dsod_cte_tmp_evento_canc_comprov_entrega' from ods.tb_dsod_cte_tmp_evento_canc_comprov_entrega

commit;
select count(1) as 'tb_dsod_mdfe_tmp_protocolo' from ods.tb_dsod_mdfe_tmp_protocolo
select count(1) as 'tb_dsod_mdfe_tmp_ide' from ods.tb_dsod_mdfe_tmp_ide
select count(1) as 'tb_dsod_mdfe_tmp_mun_carregamento' from ods.tb_dsod_mdfe_tmp_mun_carregamento
select count(1) as 'tb_dsod_mdfe_tmp_inf_percurso' from ods.tb_dsod_mdfe_tmp_inf_percurso
select count(1) as 'tb_dsod_mdfe_tmp_infdoc' from ods.tb_dsod_mdfe_tmp_infdoc
select count(1) as 'tb_dsod_mdfe_tmp_infdoc_doc' from ods.tb_dsod_mdfe_tmp_infdoc_doc
select count(1) as 'tb_dsod_mdfe_tmp_infdoc_doc_peri' from ods.tb_dsod_mdfe_tmp_infdoc_doc_peri
select count(1) as 'tb_dsod_mdfe_tmp_infdoc_doc_unidade' from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade
select count(1) as 'tb_dsod_mdfe_tmp_infdoc_doc_unidade_lacre' from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade_lacre
select count(1) as 'tb_dsod_mdfe_tmp_infdoc_doc_unidade_carga' from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade_carga
select count(1) as 'tb_dsod_mdfe_tmp_infdoc_doc_unidade_carga_lacre' from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade_carga_lacre
select count(1) as 'tb_dsod_mdfe_tmp_seguro_carga' from ods.tb_dsod_mdfe_tmp_seguro_carga
select count(1) as 'tb_dsod_mdfe_tmp_averbacao' from ods.tb_dsod_mdfe_tmp_averbacao
select count(1) as 'tb_dsod_mdfe_tmp_total' from ods.tb_dsod_mdfe_tmp_total
select count(1) as 'tb_dsod_mdfe_tmp_lacres' from ods.tb_dsod_mdfe_tmp_lacres
select count(1) as 'tb_dsod_mdfe_tmp_autorizado_xml' from ods.tb_dsod_mdfe_tmp_autorizado_xml
select count(1) as 'tb_dsod_mdfe_tmp_rodov' from ods.tb_dsod_mdfe_tmp_rodov
select count(1) as 'tb_dsod_mdfe_tmp_rodov_inf_ciot' from ods.tb_dsod_mdfe_tmp_rodov_inf_ciot
select count(1) as 'tb_dsod_mdfe_tmp_rodov_inf_pag' from ods.tb_dsod_mdfe_tmp_rodov_inf_pag
select count(1) as 'tb_dsod_mdfe_tmp_rodov_componentes' from ods.tb_dsod_mdfe_tmp_rodov_componentes
select count(1) as 'tb_dsod_mdfe_tmp_rodov_inf_prazo' from ods.tb_dsod_mdfe_tmp_rodov_inf_prazo
select count(1) as 'tb_dsod_mdfe_tmp_rodov_contratante' from ods.tb_dsod_mdfe_tmp_rodov_contratante
select count(1) as 'tb_dsod_mdfe_tmp_rodov_condutor' from ods.tb_dsod_mdfe_tmp_rodov_condutor
select count(1) as 'tb_dsod_mdfe_tmp_rodov_veic_reboque' from ods.tb_dsod_mdfe_tmp_rodov_veic_reboque
select count(1) as 'tb_dsod_mdfe_tmp_rodov_valepedagio' from ods.tb_dsod_mdfe_tmp_rodov_valepedagio
select count(1) as 'tb_dsod_mdfe_tmp_rodov_lacres' from ods.tb_dsod_mdfe_tmp_rodov_lacres
select count(1) as 'tb_dsod_mdfe_tmp_aereo' from ods.tb_dsod_mdfe_tmp_aereo
select count(1) as 'tb_dsod_mdfe_tmp_ferrov' from ods.tb_dsod_mdfe_tmp_ferrov
select count(1) as 'tb_dsod_mdfe_tmp_ferrov_vagao' from ods.tb_dsod_mdfe_tmp_ferrov_vagao
select count(1) as 'tb_dsod_mdfe_tmp_aquav' from ods.tb_dsod_mdfe_tmp_aquav
select count(1) as 'tb_dsod_mdfe_tmp_aquav_terminal_carreg' from ods.tb_dsod_mdfe_tmp_aquav_terminal_carreg
select count(1) as 'tb_dsod_mdfe_tmp_aquav_terminal_descarreg' from ods.tb_dsod_mdfe_tmp_aquav_terminal_descarreg
select count(1) as 'tb_dsod_mdfe_tmp_aquav_embarq' from ods.tb_dsod_mdfe_tmp_aquav_embarq
select count(1) as 'tb_dsod_mdfe_tmp_aquav_infunid_carga_vazia' from ods.tb_dsod_mdfe_tmp_aquav_infunid_carga_vazia
select count(1) as 'tb_dsod_mdfe_tmp_aquav_infunid_transp_vazia' from ods.tb_dsod_mdfe_tmp_aquav_infunid_transp_vazia

select * from ods.tb_dsod_mdfe_tmp_protocolo
select * from ods.tb_dsod_mdfe_tmp_ide
select * from ods.tb_dsod_mdfe_tmp_mun_carregamento
select * from ods.tb_dsod_mdfe_tmp_inf_percurso
select * from ods.tb_dsod_mdfe_tmp_infdoc
select * from ods.tb_dsod_mdfe_tmp_infdoc_doc
select * from ods.tb_dsod_mdfe_tmp_infdoc_doc_peri
select * from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade
select * from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade_lacre
select * from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade_carga
select * from ods.tb_dsod_mdfe_tmp_infdoc_doc_unidade_carga_lacre
select * from ods.tb_dsod_mdfe_tmp_seguro_carga
select * from ods.tb_dsod_mdfe_tmp_averbacao
select * from ods.tb_dsod_mdfe_tmp_total
select * from ods.tb_dsod_mdfe_tmp_lacres
select * from ods.tb_dsod_mdfe_tmp_autorizado_xml
select * from ods.tb_dsod_mdfe_tmp_rodov
select * from ods.tb_dsod_mdfe_tmp_rodov_inf_ciot
select * from ods.tb_dsod_mdfe_tmp_rodov_inf_pag
select * from ods.tb_dsod_mdfe_tmp_rodov_componentes
select * from ods.tb_dsod_mdfe_tmp_rodov_inf_prazo
select * from ods.tb_dsod_mdfe_tmp_rodov_contratante
select * from ods.tb_dsod_mdfe_tmp_rodov_condutor
select * from ods.tb_dsod_mdfe_tmp_rodov_veic_reboque
select * from ods.tb_dsod_mdfe_tmp_rodov_valepedagio
select * from ods.tb_dsod_mdfe_tmp_rodov_lacres
select * from ods.tb_dsod_mdfe_tmp_aereo
select * from ods.tb_dsod_mdfe_tmp_ferrov
select * from ods.tb_dsod_mdfe_tmp_ferrov_vagao
select * from ods.tb_dsod_mdfe_tmp_aquav
select * from ods.tb_dsod_mdfe_tmp_aquav_terminal_carreg
select * from ods.tb_dsod_mdfe_tmp_aquav_terminal_descarreg
select * from ods.tb_dsod_mdfe_tmp_aquav_embarq
select * from ods.tb_dsod_mdfe_tmp_aquav_infunid_carga_vazia
select * from ods.tb_dsod_mdfe_tmp_aquav_infunid_transp_vazia


commit;
select count(1) as 'tb_dsod_cteos_tmp_prot' from ods.tb_dsod_cteos_tmp_prot
select count(1) as 'tb_dsod_cteos_tmp_ide' from ods.tb_dsod_cteos_tmp_ide
select count(1) as 'tb_dsod_cteos_tmp_infpercurso' from ods.tb_dsod_cteos_tmp_infpercurso
select count(1) as 'tb_dsod_cteos_tmp_obscont' from ods.tb_dsod_cteos_tmp_obscont
select count(1) as 'tb_dsod_cteos_tmp_obsfisco' from ods.tb_dsod_cteos_tmp_obsfisco
select count(1) as 'tb_dsod_cteos_tmp_emitente' from ods.tb_dsod_cteos_tmp_emitente
select count(1) as 'tb_dsod_cteos_tmp_tomador' from ods.tb_dsod_cteos_tmp_tomador
select count(1) as 'tb_dsod_cteos_tmp_componente_val_prest' from ods.tb_dsod_cteos_tmp_componente_val_prest
select count(1) as 'tb_dsod_cteos_tmp_impostos' from ods.tb_dsod_cteos_tmp_impostos
select count(1) as 'tb_dsod_cteos_tmp_inf_servico' from ods.tb_dsod_cteos_tmp_inf_servico
select count(1) as 'tb_dsod_cteos_tmp_infdocref' from ods.tb_dsod_cteos_tmp_infdocref
select count(1) as 'tb_dsod_cteos_tmp_seguro_carga' from ods.tb_dsod_cteos_tmp_seguro_carga 
select count(1) as 'tb_dsod_cteos_tmp_rodov' from ods.tb_dsod_cteos_tmp_rodov
select count(1) as 'tb_dsod_cteos_tmp_fatura' from ods.tb_dsod_cteos_tmp_fatura
select count(1) as 'tb_dsod_cteos_tmp_duplicata' from ods.tb_dsod_cteos_tmp_duplicata
select count(1) as 'tb_dsod_cteos_tmp_substituicao' from ods.tb_dsod_cteos_tmp_substituicao
select count(1) as 'tb_dsod_cteos_tmp_complemento' from ods.tb_dsod_cteos_tmp_complemento
select count(1) as 'tb_dsod_cteos_tmp_anulacao' from ods.tb_dsod_cteos_tmp_anulacao
select count(1) as 'tb_dsod_cteos_tmp_autxml' from ods.tb_dsod_cteos_tmp_autxml
select count(1) as 'tb_dsod_cteos_tmp_responsavel_tecnico' from ods.tb_dsod_cteos_tmp_responsavel_tecnico
select count(1) as 'tb_dsod_cteos_tmp_evento_generico' from ods.tb_dsod_cteos_tmp_evento_generico --1
select count(1) as 'tb_dsod_cteos_tmp_cce' from ods.tb_dsod_cteos_tmp_cce
select count(1) as 'tb_dsod_cteos_tmp_cce_inf_Correcao' from ods.tb_dsod_cteos_tmp_cce_inf_Correcao
select count(1) as 'tb_dsod_cteos_tmp_evento_canc' from ods.tb_dsod_cteos_tmp_evento_canc
select count(1) as 'tb_dsod_cteos_tmp_evento_compl_autorizado' from ods.tb_dsod_cteos_tmp_evento_compl_autorizado
select count(1) as 'tb_dsod_cteos_tmp_evento_compl_cancelado' from ods.tb_dsod_cteos_tmp_evento_compl_cancelado
select count(1) as 'tb_dsod_cteos_tmp_evento_substituido' from ods.tb_dsod_cteos_tmp_evento_substituido
select count(1) as 'tb_dsod_cteos_tmp_evento_anulado' from ods.tb_dsod_cteos_tmp_evento_anulado
select count(1) as 'tb_dsod_cteos_tmp_evento_liberacao_canc' from ods.tb_dsod_cteos_tmp_evento_liberacao_canc
select count(1) as 'tb_dsod_cteos_tmp_evento_prestacao_desacordo' from ods.tb_dsod_cteos_tmp_evento_prestacao_desacordo
select count(1) as 'tb_dsod_cteos_tmp_evento_inf_gtv' from ods.tb_dsod_cteos_tmp_evento_inf_gtv --1
select count(1) as 'tb_dsod_cteos_tmp_evento_inf_gtv_inf_especie' from ods.tb_dsod_cteos_tmp_evento_inf_gtv_inf_especie --1

select data_extracao as 'tb_dsod_cteos_tmp_prot' from ods.tb_dsod_cteos_tmp_prot
select data_extracao as 'tb_dsod_cteos_tmp_ide' from ods.tb_dsod_cteos_tmp_ide
select data_extracao as 'tb_dsod_cteos_tmp_infpercurso' from ods.tb_dsod_cteos_tmp_infpercurso
select data_extracao as 'tb_dsod_cteos_tmp_obscont' from ods.tb_dsod_cteos_tmp_obscont
select data_extracao as 'tb_dsod_cteos_tmp_obsfisco' from ods.tb_dsod_cteos_tmp_obsfisco
select data_extracao as 'tb_dsod_cteos_tmp_emitente' from ods.tb_dsod_cteos_tmp_emitente
select data_extracao as 'tb_dsod_cteos_tmp_tomador' from ods.tb_dsod_cteos_tmp_tomador
select data_extracao as 'tb_dsod_cteos_tmp_componente_val_prest' from ods.tb_dsod_cteos_tmp_componente_val_prest
select data_extracao as 'tb_dsod_cteos_tmp_impostos' from ods.tb_dsod_cteos_tmp_impostos
select data_extracao as 'tb_dsod_cteos_tmp_inf_servico' from ods.tb_dsod_cteos_tmp_inf_servico
select data_extracao as 'tb_dsod_cteos_tmp_infdocref' from ods.tb_dsod_cteos_tmp_infdocref
select data_extracao as 'tb_dsod_cteos_tmp_seguro_carga' from ods.tb_dsod_cteos_tmp_seguro_carga 
select data_extracao as 'tb_dsod_cteos_tmp_rodov' from ods.tb_dsod_cteos_tmp_rodov
select data_extracao as 'tb_dsod_cteos_tmp_fatura' from ods.tb_dsod_cteos_tmp_fatura
select data_extracao as 'tb_dsod_cteos_tmp_duplicata' from ods.tb_dsod_cteos_tmp_duplicata
select data_extracao as 'tb_dsod_cteos_tmp_substituicao' from ods.tb_dsod_cteos_tmp_substituicao
select data_extracao as 'tb_dsod_cteos_tmp_complemento' from ods.tb_dsod_cteos_tmp_complemento
select data_extracao as 'tb_dsod_cteos_tmp_anulacao' from ods.tb_dsod_cteos_tmp_anulacao
select data_extracao as 'tb_dsod_cteos_tmp_autxml' from ods.tb_dsod_cteos_tmp_autxml
select data_extracao as 'tb_dsod_cteos_tmp_responsavel_tecnico' from ods.tb_dsod_cteos_tmp_responsavel_tecnico
select data_extracao as 'tb_dsod_cteos_tmp_evento_generico' from ods.tb_dsod_cteos_tmp_evento_generico
select data_extracao as 'tb_dsod_cteos_tmp_cce' from ods.tb_dsod_cteos_tmp_cce
select data_extracao as 'tb_dsod_cteos_tmp_cce_inf_Correcao' from ods.tb_dsod_cteos_tmp_cce_inf_Correcao
select data_extracao as 'tb_dsod_cteos_tmp_evento_canc' from ods.tb_dsod_cteos_tmp_evento_canc
select data_extracao as 'tb_dsod_cteos_tmp_evento_compl_autorizado' from ods.tb_dsod_cteos_tmp_evento_compl_autorizado
select data_extracao as 'tb_dsod_cteos_tmp_evento_compl_cancelado' from ods.tb_dsod_cteos_tmp_evento_compl_cancelado
select data_extracao as 'tb_dsod_cteos_tmp_evento_substituido' from ods.tb_dsod_cteos_tmp_evento_substituido
select data_extracao as 'tb_dsod_cteos_tmp_evento_anulado' from ods.tb_dsod_cteos_tmp_evento_anulado
select data_extracao as 'tb_dsod_cteos_tmp_evento_liberacao_canc' from ods.tb_dsod_cteos_tmp_evento_liberacao_canc
select data_extracao as 'tb_dsod_cteos_tmp_evento_prestacao_desacordo' from ods.tb_dsod_cteos_tmp_evento_prestacao_desacordo
select data_extracao as 'tb_dsod_cteos_tmp_evento_inf_gtv' from ods.tb_dsod_cteos_tmp_evento_inf_gtv
select data_extracao as 'tb_dsod_cteos_tmp_evento_inf_gtv_inf_especie' from ods.tb_dsod_cteos_tmp_evento_inf_gtv_inf_especie

