USE [NFCe_Out_Constraint]
GO

/****** Object:  Trigger [NFCeOut].[TR_ContribuintesHabilitados_AfterDelete]    Script Date: 16/07/2014 14:30:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [NFCeOut].[TR_ContribuintesHabilitados_AfterDelete]
    ON [NFCeOut].[ContribuintesHabilitados]
    FOR DELETE
    AS
    BEGIN
        SET NOCOUNT ON
        INSERT INTO [NFCeOut].[ContribuintesHabilitados_LOG]
        (
            [pKey],
            [tipoCredContribuinte],
            [tipoEmissaoContribuinte],
            [CNPJ],
            [IE],
            [Empresa],           
            [timestampReg],
            [UF],
            [credVoluntarioHabilitado],
            [valorNFeIlimitado],
            [ignorarCadesp],
            [dataCredenciamento],
            [tipoRegistro],            
            [dtAlteracaoReg])
        SELECT 
            D.[pKey],
            D.[tipoCredContribuinte],
            D.[tipoEmissaoContribuinte],
            D.[CNPJ],
            D.[IE],
            D.[Empresa],           
            D.[timestampReg],
            D.[UF],
            D.[credVoluntarioHabilitado],
            D.[valorNFeIlimitado], 
            D.[ignorarCadesp],
            D.[dataCredenciamento],
            'E', 
            GETDATE()
        FROM DELETED D    
    END

GO


