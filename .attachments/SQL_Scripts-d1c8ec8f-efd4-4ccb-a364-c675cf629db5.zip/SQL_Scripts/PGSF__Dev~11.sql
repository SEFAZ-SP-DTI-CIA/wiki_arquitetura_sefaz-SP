select *
from drt


select * 
from nf
where id_drt=13

select *
from equipe
where id_nf = 264
and 

select *
from tb_relato_situacao rs
join fiscal fi
on rs.nr_fiscal = fi.num_fiscal
where id_equipe = 83
and   nr_mes = 5
and   nr_ano = 2016
and   in_ativo=1
and   id_situacao_relato = 25
