-- identificando uma equipe para teste...

select * from TB_Boletim_Correcao
where nr_ano = 2015
and nr_mes = 11
and nr_fiscal in
(29492,
322055,
5610,
31206,
31413,
44559)

--ID_BC = 8199,8200,8201,8202,8203,8204,8205

select distinct eq.id_equipe, eq.nom_equipe, fi.num_fiscal, fi.nom_fiscal
from fiscal fi
join equipe_membro eqm
on fi.num_fiscal = eqm.num_fiscal
join equipe eq
on eq.id_equipe = eqm.id_equipe
where  eq.id_equipe = 173
and eqm.dtc_fim_membro is null
and eqm.dtc_inicio_membro < '01/11/2015'
order by fi.nom_fiscal

--teste2: identificando equipes em que fiscal atuou em 2 equipes no per�odo
-- usando per�odo 2015-11, equipe DRTC-I 11
select * 
from equipe eq
join drt dr
on eq.id_drt = dr.id_drt
where dr.nom_drt = 'DRTC-I - S�O PAULO'
and nom_equipe = '12'
--id_equipe = 134

select distinct eq.id_equipe, eq.nom_equipe, fi.num_fiscal, fi.nom_fiscal, eqm.dtc_fim_membro
from fiscal fi
join equipe_membro eqm
on fi.num_fiscal = eqm.num_fiscal
join equipe eq
on eq.id_equipe = eqm.id_equipe
where  
eq.id_equipe = 134
--or eq.id_equipe = 173)
and eqm.dtc_inicio_membro < '30/11/2015'
and 
(eqm.dtc_fim_membro is null 
OR eqm.dtc_fim_membro > '01/11/2015')
order by fi.nom_fiscal
--AFR FRANK SAI YUNG CHEUNG (95828) pertence a duas equipes (134 e 173)

select * from TB_Boletim_Correcao
where nr_ano = 2015
and nr_mes = 11
and nr_fiscal = 333351
in
(17921,
87509,
333351,
95828,
19395,
60978,
21559,
22126,
336730)
--n�o h� BC (em dev) para esses AFRs

-- devolvi o relato de DENIS SCHAEFER para gerar BC
-- alterei o relato, enviei, aprovei, e homologuei

-- o relato de DOMINIQUE CHRISTINE MIRANDA MARQUEZINI n�o foi enviado
-- investigando...

select eq.nom_equipe, dr.nom_drt, re.nr_mes, re.nr_ano--, re.DT_ALTERACAO, re.id_situacao_relato, 
from tb_relato_situacao re
join equipe eq
on eq.id_equipe = re.ID_EQUIPE
join drt dr
on dr.id_drt = eq.ID_DRT
where re.nr_ano = 2015
and re.nr_mes = 11
and eq.id_equipe = 134
and re.

-- Avelino lembrou que houve UPDATE manual que prejudicou a consist�ncia da base DEV
-- mudando para base TEMP...


select * from TB_Boletim_Correcao
where nr_ano = 2015
and nr_mes = 11
and nr_fiscal in
(86463,
87145,
250226,
19486,
19401,
19401,
95828,
19190,
24470
)
--660651 660650 660649 660647 660646 660646 660644 660643 660642
--BCs: 12428 12429 12430 12432 12433 12434 12435 12437

select *
from tb_relato_situacao
where 
in_ativo = 1
and id_equipe = 134
and nr_ano = 2015
and nr_mes = 11
and nr_fiscal = 333351

select * 
from tb_relato_situacao
where in_ativo = 1
and id_relato_situacao in
(628544,
628545,
628547,
628549,
628550,
628551,
628552,
628553,
628554,
628555,
660495,
660496,
660497,
660498,
660499,
660500,
660501,
660502,
660503,
660504,
660536)

select * from equipe_membro where num_fiscal = 333351
--155 e 134

select * 
from equipe_membro eqm
join fiscal fi
using (num_fiscal)
where fi.nom_fiscal = 'ARLETE LOPES GARDENGHI'
and (eqm.dtc_fim_membro is null or eqm.dtc_fim_membro > '01/11/2015')
and eqm.dtc_inicio_membro < '30/11/2015'
order by fi.nom_fiscal
-- DOMINIQUE CHRISTINE MIRANDA MARQUEZINI	333351 equipes 134 e 155
-- FRANK SAI YUNG CHEUNG 95828 equipes 134 e 173
-- ANDRE FERNANDO RODRIGUES 47470 equipes 123 e 1124

select * from equipe where id_equipe = 123
--id 155 equipe 53 DRTC-I
--id 173 equipe 12 DRTC-I
--id 123 equipe 12 DRT-2
--id 1124 equipe 3.1 DRT-2

select dom.ds_situacao_relato, rs.id_relato_situacao, rs.nr_fiscal, rs.in_bc, rs.in_ativo, bc.id_bc, bc.nr_bc, bc.id_relato_situacao_homol
from tb_boletim_correcao bc, tb_dom_situacao_relato dom
join tb_relato_situacao rs
on dom.id_situacao_relato = rs.id_situacao_relato
join fiscal fi
on rs.nr_fiscal = fi.num_fiscal
join equipe_membro eq
on fi.num_fiscal = eq.num_fiscal
where rs.nr_mes = 11
and rs.nr_ano = 2015
and eq.id_equipe = 134
and rs.in_ativo = 1
and rs.in_bc = 1
and bc.nr_fiscal = fi.num_fiscal
and bc.nr_ano = 2015
and bc.nr_mes = 11
and rs.id_situacao_relato < 90
order by rs.nr_fiscal, bc.nr_bc
-- 13389 13392 13393 13388 13397 13396 13390 13395
-- 13399 13401 13402 13403 13404 13398 13407 13406 13400 13405
-- 13409 13409 13411 13419 13419 13412 13414 13413 13415 13415 13410 13416 13420 13418 13417 
-- 13413 13415 13415 13410 13416 13420 13418 13417

--660651 660650 660649 660647 660646 660646 660644 660643 660642

--13379 13381 13382 13383 13384 13378 13387 13386 13380 12431 13385 

SELECT  RS.NR_ANO,
        RS.NR_MES,
        RS.ID_EQUIPE,                
        RS.NR_FISCAL,
        RS.QT_DIAS_RELATADOS,
        RS.ID_SITUACAO_RELATO,
        RS.NR_FISCAL_RESP,
        RS.ID_EQUIPE_DEAT,
        RS.IN_BC
FROM TB_BOLETIM_CORRECAO BC, TB_RELATO_SITUACAO RS
WHERE BC.NR_FISCAL = RS.NR_FISCAL AND 
      BC.NR_MES = RS.NR_MES AND 
      BC.NR_ANO = RS.NR_ANO AND 
      BC.ID_BC = 13370 AND
      IN_ATIVO = 1;