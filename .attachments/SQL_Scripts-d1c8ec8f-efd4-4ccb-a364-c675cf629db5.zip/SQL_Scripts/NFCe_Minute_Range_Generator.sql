declare @dtIni datetime, @dtFim datetime
set @dtIni = '2016-03-21 00:00:00.000'
set @dtFim = '2016-03-22 00:00:00.000'

select dateadd(minute, number, @dtIni) as minuto into #minutos
from 
  (select distinct number from master.dbo.spt_values
   where name is null) n
where dateadd(minute, number, @dtIni) < @dtFim

select minuto, sum(case when l.pKey is null then 0 else 1 end) conta
from
#minutos m
left join NFCe_In.NFCeIn.Lote l (NOLOCK)
on l.recebimento >= minuto
and l.recebimento < DATEADD(MINUTE,1,minuto)
group by minuto

select minuto, sum(case when l.pKey is null then 0 else 1 end) conta
from
#minutos m
left join NFCe_In.NFCeIn.LoteSinc l (NOLOCK)
on l.processamento >= minuto
and l.processamento < DATEADD(MINUTE,1,minuto)
group by minuto

select minuto, sum(case when p.pKey is null then 0 else 1 end) conta
from
#minutos m
left join NFCe_Out.NFCeOut.Protocolo p (NOLOCK)
on p.timestampReg >= minuto
and p.timestampReg < DATEADD(MINUTE,1,minuto)
group by minuto

select minuto, count(1)
from
#minutos m
left join NFCe_Out.NFCeOut.Protocolo p (NOLOCK)
on p.timestampReg >= minuto
and p.timestampReg < DATEADD(MINUTE,1,minuto)
group by minuto

select cast(p.timestampReg as smalldatetime), count(1)
from NFCe_Out.NFCeOut.Protocolo p (NOLOCK)
where p.timestampReg > '2016-03-21 00:00:00.000'
 and  p.timestampReg < '2016-03-22 00:00:00.000'
group by cast(p.timestampReg as smalldatetime)


DECLARE @startdate smalldatetime, @enddate smalldatetime
SET @StartDate = CAST('2016-03-21' as smalldatetime);
SET @EndDate = CAST('2016-03-22' as smalldatetime);
;with cte as
(
select @startdate DateValue
union all
select DATEADD (mi,1,DateValue)
from cte 
where DATEADD (mi,1,DateValue) < @enddate
)
select cast(a.DateValue as datetime) as minuto, COUNT(b.pKey) AS conta
from cte a
LEFT outer join NFCe_Out.NFCeOut.Protocolo b 
on a.DateValue = cast(b.timestampReg as smalldatetime)
group by a.DateValue
order by a.DateValue
OPTION (MAXRECURSION 0, maxdop 8)
