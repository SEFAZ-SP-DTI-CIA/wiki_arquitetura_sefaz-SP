USE NFe_Out_UFs
GO

    CREATE TABLE #ProtocoloEvento
    (
        [pKey] [bigint] NOT NULL,
		--[nsu] [bigint] NOT NULL,
        [idEvento] [varchar](67) NOT NULL,
        [tpAmb] [tinyint] NOT NULL,
        [versao] [varchar](4) NOT NULL,
        [verAplic] [varchar](20) NOT NULL,
        [cOrgao] [tinyint] NOT NULL,
        [ano] [varchar](2) NOT NULL,
        [idReceptor] [tinyint] NOT NULL,
        [cStat] [int] NOT NULL,
        [chNFe] [varchar](44) NOT NULL,
        [tpEvento] [varchar](6) NOT NULL,
        [nSeqEvento] [tinyint] NOT NULL,
        [CNPJDest_CPFDest] [varchar](20) NOT NULL,
        [email] [varchar](60) NULL,
        [nroProtocolo] [bigint] NOT NULL,
        [evento] [nvarchar](max) NULL,
        [timestampReg] [datetimeoffset](7) NOT NULL,
        [tipoIdDest] [tinyint] NOT NULL,
        PRIMARY KEY(pKey, timestampReg)
    )


--select top 5000 *  from [NFeUFs].[DFeRecebimento] (NOLOCK) where id > 2121500000
--SELECT TOP 5000 * FROM [NFeUFs].[DFeRecebimento](NOLOCK) WHERE ID > 510368780

DECLARE @idIni BIGINT = 2121505000
DECLARE @idFim BIGINT = 2121510000


--INSERT INTO #ProtocoloEvento(pKey, nsu, idEvento, tpAmb, versao, verAplic, cOrgao, ano, idReceptor, cStat, chNFe, tpEvento, nSeqEvento, CNPJDest_CPFDest, email, nroProtocolo, evento, timestampReg, tipoIdDest)
INSERT INTO #ProtocoloEvento(pKey, idEvento, tpAmb, versao, verAplic, cOrgao, ano, idReceptor, cStat, chNFe, tpEvento, nSeqEvento, CNPJDest_CPFDest, email, nroProtocolo, evento, timestampReg, tipoIdDest)
--SELECT pKey, ie.nsu, idEvento, tpAmb, versao, verAplic, cOrgao, ano, idReceptor, cStat, chNFe, tpEvento, nSeqEvento, idDest, email, nroProtocolo, evento, timestampReg, tipoIdDest
SELECT pKey, idEvento, tpAmb, versao, verAplic, cOrgao, ano, idReceptor, cStat, chNFe, tpEvento, nSeqEvento, idDest, email, nroProtocolo, evento, timestampReg, tipoIdDest
FROM [NFeUFs].[DFeRecebimento] AS dr
INNER JOIN NFeEventos.IntegraEvento AS ie
ON dr.id BETWEEN @idIni AND @idFim
AND dr.tpDocumento = 2
AND dr.nsu = ie.nsu
INNER JOIN NFeEventos.Evento AS e
ON ie.pkeyEvento = e.pKey

return

DECLARE @minTimestampEvento DATETIME
SELECT @minTimestampEvento = MIN(timestampReg) FROM #ProtocoloEvento

SELECT pKey, idEvento, tpAmb, versao, verAplic, ano, idReceptor, cStat, chNFe, tpEvento, nSeqEvento, CNPJDest_CPFDest, email, nroProtocolo, timestampReg, tipoIdDest, dt.ipTransmissor, dt.portaTransmissor, dt.timestampConexao
, evento
--, xmlEvento
FROM #ProtocoloEvento AS p
--INNER JOIN [NFeEventos].[IntegraEvento] AS ie
--ON p.pKey = ie.pkeyEvento
--and ie.timestampRecebimento >= @minTimestampEvento
LEFT JOIN [dbo].[DadosTransmissao_AN] as dt
ON p.nsu = dt.nsu

drop table #ProtocoloEvento
