select *
from pgsf.tb_relato_situacao
where id_relato_situacao in (974331,
974332,
974333,
974334,
974335,
974336,
974337,
974338,
974339,
974340
)

select *
from pgsf.tb_relato_situacao
where 
id_equipe = 207
and in_ativo = 1
and nr_mes = 7
and NR_ANO = 2015
--16227	1	87169	2015	7	841	1350	31	841	1350	31	1	1	Assistente de Inspetor	974331
--16228	1	5530	2015	7	9708	0	31	9077	0	31	1	1	Assistente de Inspetor	974332
--16229	1	29789	2015	7	8571	0	31	8513	0	31	0	1	Assistente de Inspetor	974333
--16230	1	85227	2015	7	2339	1350	31	2311	1350	31	0	1	Assistente de Inspetor	974334
--16231	1	30561	2015	7	7068	0	27	7015	0	27	0	1	Assistente de Inspetor	974335
--16232	1	171296	2015	7	2444	1350	31	2413	1350	31	0	1	Assistente de Inspetor	974336
--16233	1	31190	2015	7	165	1710	24	165	1710	24	0	1	Assistente de Inspetor	974337
--16234	1	32429	2015	7	3790	1350	31	3763	1350	31	0	1	Assistente de Inspetor	974338
--16235	1	21985	2015	7	406	1350	31	406	1350	31	0	1	Assistente de Inspetor	974339
--16236	1	33355	2015	7	9837	90	31	9782	90	31	0	1	Assistente de Inspetor	974340


and (ID_SITUACAO_RELATO = 79 OR ID_SITUACAO_RELATO = 80)
--1072968	2015	7	207	5530  	21	80	18/01/17	RH	33264	1			1	0
--1072969	2015	7	207	29789 	21	80	18/01/17	RH	33264	1			1	0
--1072970	2015	7	207	85227 	10	80	18/01/17	RH	33264	1			1	0
--1072971	2015	7	207	30561 	17	80	18/01/17	RH	33264	1			1	0
--1072974	2015	7	207	32429 	10	80	18/01/17	RH	33264	1			1	0
--1072976	2015	7	207	33355   20	80	18/01/17	RH	33264	1			1	0
--1136774	2015	7	207	171296	11	79	27/01/17	RH	33264	1		Diverg�ncia no total de dias �teis.	1	0

select *
from pgsf.tb_boletim_correcao BC
where
BC.NR_FISCAL in (5530,
29789,
85227,
30561,
32429,
33355,
171296,
87169,
31190,
21985
)
and BC.NR_MES = 7
and BC.NR_ANO = 2015



select *
from pgsf.TB_BOLETIM_CORRECAO
where nr_fiscal in (5530,29789,85227,30561,32429,33355)
and nr_mes = 7
and nr_ano = 2015
--id_bc nr_bc nr_fiscal nr_ano nr_mes qn_pontos_antes qn_quotas_antes qn_dias_fdt_antes qn_pontos_apos qn_quotas_apos   qn_dias_fdt_apos in_motivo_aiim  in_motivo_pontuacao  ds_funcao_responsavel_homol id_relato_situacao_homol
--16228	1	    5530	    2015	 7	    9708          	0   	          31	              9077	         0	              31	              1	                   1	            Assistente de Inspetor	    974332
--16229	1	    29789	    2015	 7	    8571	          0	              31	              8513	         0	              31	              0	                   1	            Assistente de Inspetor	    974333
--16230	1	    85227	    2015	 7	    2339	          1350	          31	              2311	         1350	            31	              0	                   1	            Assistente de Inspetor	    974334
--16231	1	    30561	    2015	 7	    7068	          0	              27	              7015	         0	              27	              0	                   1	            Assistente de Inspetor	    974335
--16234	1	    32429	    2015	 7	    3790	          1350	          31	              3763	         1350	            31	              0	                   1	            Assistente de Inspetor	    974338
--16236	1	    33355	    2015	 7	    9837	          90	            31	              9782	         90	              31	              0	                   1	            Assistente de Inspetor	    974340

id_relato_situacao = 1136774
--id_relato_s ano  mes eqp  fiscal dias id_sit_rel dt_alter  id_usuario num_fisc_resp in_ativo ds_obs
--1136774	    2015	7	 207	171296	11	79	       27/01/17 	RH	      33264 	      1		     Diverg�ncia no total de dias �teis.	1	0


select *
from pgsf.tb_log_atual_devol_rh
where id_relato_situacao in (1072968,
1072969,
1072970,
1072971,
1072974,
1072976,
1136774);


update TB_RELATO_SITUACAO
set in_ativo = 1
WHERE ID_RELATO_SITUACAO = 1136774

SELECT *
FROM TB_RELATO_SITUACAO
WHERE ID_RELATO_SITUACAO = 1136774

update TB_RELATO_SITUACAO
set in_ati
WHERE id_relato_situacao in (1072968,
1072969,
1072970,
1072971,
1072974,
1072976,
1136774,
1130940,
1130941,
1130942
)



 SELECT *
    FROM 
      pgsf.TB_RELATO_SITUACAO RS
      ,pgsf.TB_BOLETIM_CORRECAO BC
    WHERE
      RS.IN_ATIVO = 1 AND
      RS.ID_SITUACAO_RELATO = 80 AND
      207 = RS.ID_EQUIPE AND
      7 = RS.NR_MES AND
      2015 = RS.NR_ANO AND
      RS.NR_FISCAL = BC.NR_FISCAL AND
      RS.NR_MES = BC.NR_MES AND
      RS.NR_ANO = BC.NR_ANO;
      

 SELECT 
        RS.ID_RELATO_SITUACAO,
        RS.NR_ANO,
        RS.NR_MES,
        RS.ID_EQUIPE,
        RS.NR_FISCAL,
        RS.QT_DIAS_RELATADOS,
        RS.ID_SITUACAO_RELATO,
        RS.DT_ALTERACAO,
        RS.ID_USUARIO,
        RS.NR_FISCAL_RESP,
        RS.IN_ATIVO,        
        RS.ID_EQUIPE_DEAT,
        RS.DS_OBSERVACAO,
        RS.IN_BC,
        BC.ID_BC
    FROM (
      SELECT DISTINCT ID_EQUIPE, ID_EQUIPE_DEAT, NR_MES, NR_ANO
      FROM pgsf.TB_RELATO_SITUACAO
      WHERE ID_SITUACAO_RELATO = 79 AND
            IN_ATIVO = 1)
      RSD,
      pgsf.TB_RELATO_SITUACAO RS,
      pgsf.TB_BOLETIM_CORRECAO BC
    WHERE
      RS.IN_ATIVO = 1 AND
      RS.ID_SITUACAO_RELATO = 80 AND
      (RSD.ID_EQUIPE = RS.ID_EQUIPE OR RSD.ID_EQUIPE_DEAT = RS.ID_EQUIPE_DEAT) AND
      RSD.NR_MES = RS.NR_MES AND
      RSD.NR_ANO = RS.NR_ANO AND
      RS.NR_FISCAL = BC.NR_FISCAL AND
      RS.NR_MES = BC.NR_MES AND
      RS.NR_ANO = BC.NR_ANO;