select * from
(select USUARIO, TO_CHAR(DT_ACAO, 'DD-MM-YY HH24:MI'), DS_ACAO
from pgsf.tb_log_acesso
join pgsf.tb_dom_acao
using(id_acao)
order by dt_acao desc)
where rownum < 51
