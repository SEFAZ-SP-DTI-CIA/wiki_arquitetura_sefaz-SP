#!/usr/bin/perl

my $openssl;
if(defined $ENV{OPENSSL}) {
	$openssl = $ENV{OPENSSL};
} else {
	$openssl = "openssl";
	$ENV{OPENSSL} = $openssl;
}

# PARA A RAIZ ICP-BRASIL DE TESTE
$SSLEAY_CONFIG_RAIZ="-config ./sefaz/config/conf_acraiz.cfg";
$COM_REQ_RAIZ="$openssl req $SSLEAY_CONFIG_RAIZ";
$COM_CA_RAIZ="$openssl ca $SSLEAY_CONFIG_RAIZ -noemailDN";

# PARA A INTERMEDIARIA SEFAZ-SP DE TESTE
$SSLEAY_CONFIG_SEFAZSP="-config ./sefaz/config/conf_acsefazsp.cfg";
$COM_REQ_SEFAZSP="$openssl req $SSLEAY_CONFIG_SEFAZSP";
$COM_CA_SEFAZSP="$openssl ca $SSLEAY_CONFIG_SEFAZSP -noemailDN";

# PARA A ENTIDADE FINAL
$SSLEAY_CONFIG="-config ./sefaz/config/conf_cert_ecnpj.cfg";
$COM_REQ="$openssl req $SSLEAY_CONFIG";
$COM_CA="$openssl ca $SSLEAY_CONFIG -noemailDN";


# PARA SERVER CERT
$SSLEAY_CONFIG_SERVERCERT="-config ./sefaz/config/conf_servercert.cfg";
$COM_REQ_SERVERCERT="$openssl req $SSLEAY_CONFIG_SERVERCERT";
$COM_CA_SERVERCERT="$openssl ca $SSLEAY_CONFIG_SERVERCERT -noemailDN";


#OUTROS COMANDOS
$COM_PKCS12="$openssl pkcs12";
$DAYS="-days 365";	# 1 year
$CASEFAZDAYS="-days 1095";	# 3 years
$CARAIZDAYS="-days 1825";	# 5 years


# DIRETORIO
$CATOP="./sefaz";
$CATOP_RAIZ="./sefaz/raiz";
$CATOP_INTERMEDIARIA="./sefaz/intermediaria";
$CATOP_CERTIFICADO="./sefaz/certificados";
$CATOP_SERVERCERT="./sefaz/servercert";

$CAKEY_RAIZ="cakey_raiz.pem";
$CAREQ_RAIZ="careq_raiz.pem";
$CACERT_RAIZ="cacert_raiz.pem";



$RET = 0;

foreach (@ARGV) {
	if (/^-newca$/) {
		# if explicitly asked for or it doesn't exist then setup the
		# directory structure that Eric likes to manage things 
	    $NEW="1";
	    if ( "$NEW" || ! -f "${CATOP}/serial" ) {
		
		# cria a hierarquia de diretorio
		mkdir $CATOP_RAIZ;
		mkdir "${CATOP_RAIZ}/certs";
		mkdir "${CATOP_RAIZ}/crl";
		mkdir "${CATOP_RAIZ}/newcerts";
		mkdir "${CATOP_RAIZ}/private";
		open OUT, ">${CATOP_RAIZ}/index.txt";
		close OUT;
		open OUT, ">${CATOP_RAIZ}/crlnumber";
		print OUT "01\n";
		close OUT;
	    }
		
		# Cria o novo CA
		print "Criando o novo CA ...\n";
		system ("$COM_REQ_RAIZ -new -keyout ${CATOP_RAIZ}/private/$CAKEY_RAIZ -out ${CATOP_RAIZ}/$CAREQ_RAIZ");
		system ("$COM_CA_RAIZ -create_serial " .
		"-out ${CATOP_RAIZ}/certs/$CACERT_RAIZ $CARAIZDAYS -batch " . 
		"-keyfile ${CATOP_RAIZ}/private/$CAKEY_RAIZ -selfsign " .
		"-extensions v3_ca " .
		"-infiles ${CATOP_RAIZ}/$CAREQ_RAIZ ");
		$RET=$?;
	}
	
	elsif (/^-newsefazsp$/) {
		
		# cria a hierarquia de diretorio
		mkdir $CATOP_INTERMEDIARIA;
		mkdir "${CATOP_INTERMEDIARIA}/certs";
		mkdir "${CATOP_INTERMEDIARIA}/crl";
		mkdir "${CATOP_INTERMEDIARIA}/newcerts";
		mkdir "${CATOP_INTERMEDIARIA}/private";
		open OUT, ">${CATOP_INTERMEDIARIA}/index.txt";
		close OUT;
		open OUT, ">${CATOP_INTERMEDIARIA}/crlnumber";
		print OUT "01\n";
		close OUT;
		
		# Cria o nova intermediaria
		print "Criando a intermediaria...\n";
	
		#Cria o certificate request
		system ("$COM_REQ_SEFAZSP -new  -keyout ${CATOP_INTERMEDIARIA}/private/sefazsp_key.pem  -out ${CATOP_INTERMEDIARIA}/sefazsp_req.pem  $CASEFAZDAYS");
		
		#Assina
		system ("$COM_CA_SEFAZSP -policy policy_anything  -out ${CATOP_INTERMEDIARIA}/certs/sefazsp_cert.pem  -keyfile ${CATOP_RAIZ}/private/$CAKEY_RAIZ -cert ${CATOP_RAIZ}/certs/$CACERT_RAIZ  -infiles ${CATOP_INTERMEDIARIA}/sefazsp_req.pem");
	}

	elsif (/^-newcert$/) {
	
		# cria a hierarquia de diretorio
		mkdir $CATOP_CERTIFICADO;
		mkdir "${CATOP_CERTIFICADO}/certs";
		mkdir "${CATOP_CERTIFICADO}/crl";
		mkdir "${CATOP_CERTIFICADO}/newcerts";
		mkdir "${CATOP_CERTIFICADO}/private";
		mkdir "${CATOP_CERTIFICADO}/p12";
		open OUT, ">${CATOP_CERTIFICADO}/index.txt";
		close OUT;
		open OUT, ">${CATOP_CERTIFICADO}/crlnumber";
		print OUT "01\n";
		close OUT;
	
		my $cname = $ARGV[1];
	    $cname = "newcert" unless defined $cname;
	
		#Cria o certificate request
		system ("$COM_REQ -new  -keyout ${CATOP_CERTIFICADO}/private/${cname}.pem  -out ${CATOP_CERTIFICADO}/${cname}.pem  $DAYS");
		
		#Assina
		system ("$COM_CA -policy policy_anything  -out ${CATOP_CERTIFICADO}/certs/${cname}.pem  -keyfile ${CATOP_INTERMEDIARIA}/private/sefazsp_key.pem  -cert ${CATOP_INTERMEDIARIA}/certs/sefazsp_cert.pem  -infiles ${CATOP_CERTIFICADO}/${cname}.pem");
		
		#gera o pkcs12
		system ("$COM_PKCS12 -in ${CATOP_CERTIFICADO}/certs/${cname}.pem  -inkey ${CATOP_CERTIFICADO}/private/${cname}.pem " .
			"-certfile ${CATOP_INTERMEDIARIA}/certs/sefazsp_cert.pem -out ${CATOP_CERTIFICADO}/p12/${cname}.p12 " .
			"-export -name \"$cname\" ");
			#"-export -name \"$cname\"");
	}
	
	elsif (/^-newlcr$/) {
		#gera lcr da raiz
		system ("$COM_CA_RAIZ -gencrl -crldays 1825 -md sha1 -out ${CATOP_RAIZ}/crl/crl_raiz.crl -cert ${CATOP_RAIZ}/certs/cacert_raiz.pem");
		
		#gera lcr da sefaz
		system ("$COM_CA_SEFAZSP -gencrl -crldays 1095 -md sha1 -out ${CATOP_INTERMEDIARIA}/crl/sefazsp_crl.crl -cert ${CATOP_INTERMEDIARIA}/certs/sefazsp_cert.pem");
		
		#gera lcr da entidade final
		system ("$COM_CA -gencrl -crldays 365 -md sha1 -out ${CATOP_CERTIFICADO}/crl/certificado_crl.crl -cert ${CATOP_CERTIFICADO}/certs/newcert.pem");
	}
	
	
	
	elsif (/^-newservercert$/) {
		# if explicitly asked for or it doesn't exist then setup the
		# directory structure that Eric likes to manage things 
	    $NEW="1";
	    if ( "$NEW" || ! -f "${CATOP}/serial" ) {
		
		# cria a hierarquia de diretorio
		mkdir $CATOP_SERVERCERT;
		mkdir "${CATOP_SERVERCERT}/certs";
		mkdir "${CATOP_SERVERCERT}/crl";
		mkdir "${CATOP_SERVERCERT}/newcerts";
		mkdir "${CATOP_SERVERCERT}/private";
		mkdir "${CATOP_SERVERCERT}/p12";
		open OUT, ">${CATOP_SERVERCERT}/index.txt";
		close OUT;
		open OUT, ">${CATOP_SERVERCERT}/crlnumber";
		print OUT "01\n";
		close OUT;
	    }
		
		my $cname = "newcertserver";
		
		# Cria o novo CA Server
		print "Criando o novo CA ...\n";
		system ("$COM_REQ_SERVERCERT -new -keyout ${CATOP_SERVERCERT}/private/caserverkey_raiz.pem -out ${CATOP_SERVERCERT}/caserverreq_raiz.pem");
		system ("$COM_CA_SERVERCERT -create_serial " .
		"-out ${CATOP_SERVERCERT}/certs/caservercert_raiz.pem $CARAIZDAYS -batch " . 
		"-keyfile ${CATOP_SERVERCERT}/private/caserverkey_raiz.pem -selfsign " .
		"-extensions v3_ca " .
		"-infiles ${CATOP_SERVERCERT}/caserverreq_raiz.pem ");
		$RET=$?;
		
		#gera o pkcs12
		system ("$COM_PKCS12 -in ${CATOP_SERVERCERT}/caserverreq_raiz.pem -inkey ${CATOP_SERVERCERT}/private/caserverkey_raiz.pem " .
			" -out ${CATOP_SERVERCERT}/p12/caservercert_raiz.p12 " .
			"-export -name \"$cname\" ");
	}
}

exit $RET;

sub cp_pem {
my ($infile, $outfile, $bound) = @_;
open IN, $infile;
open OUT, ">$outfile";
my $flag = 0;
while (<IN>) {
	$flag = 1 if (/^-----BEGIN.*$bound/) ;
	print OUT $_ if ($flag);
	if (/^-----END.*$bound/) {
		close IN;
		close OUT;
		return;
	}
}
}

